-- =============================================================================
-- ReciboFácil — schema.sql
-- Banco de dados relacional do sistema de emissão de recibos.
--
-- SGBD ......: MariaDB 10.4.13   (somente recursos compatíveis com 10.4)
-- Engine ....: InnoDB            (transações, chaves estrangeiras, bloqueio de linha)
-- Charset ...: utf8mb4 / utf8mb4_unicode_ci
--
-- Este script é idempotente: pode ser executado mais de uma vez sem erro
-- (CREATE ... IF NOT EXISTS). Ele NÃO apaga dados existentes.
--
-- Mapa de relacionamentos
--   emitentes (1) ──< (N) recibos >── (N) ──(1) clientes
--   recibos   (1) ──< (N) itens_recibo        (CASCADE)
--   recibos   (1) ──< (N) pagamentos >── (N) ──(1) formas_pagamento
--   emitentes (1) ──< (N) contadores_recibo   (numeração por emitente/ano)
--   historico_operacoes  -> referência lógica (entidade + entidade_id)
--   configuracoes        -> parâmetros chave/valor, sem relacionamentos
-- =============================================================================

CREATE DATABASE IF NOT EXISTS recibofacil
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE recibofacil;

SET NAMES utf8mb4;


-- -----------------------------------------------------------------------------
-- 1. emitentes
-- Pessoa ou empresa responsável pela emissão dos recibos.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS emitentes (
    id              INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    nome            VARCHAR(150)     NOT NULL COMMENT 'Nome ou razão social',
    tipo_pessoa     CHAR(1)          NOT NULL COMMENT 'F = física, J = jurídica',
    documento       VARCHAR(14)      NOT NULL COMMENT 'CPF (11) ou CNPJ (14), somente dígitos',
    telefone        VARCHAR(20)      NULL,
    email           VARCHAR(120)     NULL,
    logradouro      VARCHAR(150)     NULL,
    numero          VARCHAR(10)      NULL,
    complemento     VARCHAR(60)      NULL,
    bairro          VARCHAR(80)      NULL,
    cidade          VARCHAR(80)      NULL,
    uf              CHAR(2)          NULL,
    cep             CHAR(8)          NULL COMMENT 'Somente dígitos',
    ativo           TINYINT(1)       NOT NULL DEFAULT 1,
    criado_em       DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em   DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP
                                     ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_emitentes_documento (documento),
    KEY idx_emitentes_nome (nome),
    CONSTRAINT ck_emitentes_tipo  CHECK (tipo_pessoa IN ('F', 'J')),
    CONSTRAINT ck_emitentes_ativo CHECK (ativo IN (0, 1)),
    CONSTRAINT ck_emitentes_doc   CHECK (
        (tipo_pessoa = 'F' AND CHAR_LENGTH(documento) = 11) OR
        (tipo_pessoa = 'J' AND CHAR_LENGTH(documento) = 14)
    )
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci
  COMMENT = 'Quem emite os recibos';


-- -----------------------------------------------------------------------------
-- 2. clientes
-- Cadastro de clientes. Nunca é apagado: usa exclusão lógica (ativo = 0).
-- Alterar um cliente NÃO altera recibos já emitidos (ver cópia em recibos).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS clientes (
    id              INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    nome            VARCHAR(150)     NOT NULL,
    tipo_pessoa     CHAR(1)          NOT NULL COMMENT 'F = física, J = jurídica',
    documento       VARCHAR(14)      NOT NULL COMMENT 'CPF (11) ou CNPJ (14), somente dígitos',
    telefone        VARCHAR(20)      NULL,
    email           VARCHAR(120)     NULL,
    logradouro      VARCHAR(150)     NULL,
    numero          VARCHAR(10)      NULL,
    complemento     VARCHAR(60)      NULL,
    bairro          VARCHAR(80)      NULL,
    cidade          VARCHAR(80)      NULL,
    uf              CHAR(2)          NULL,
    cep             CHAR(8)          NULL COMMENT 'Somente dígitos',
    ativo           TINYINT(1)       NOT NULL DEFAULT 1 COMMENT '1 = ativo, 0 = desativado',
    criado_em       DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em   DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP
                                     ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_clientes_documento (documento),
    KEY idx_clientes_nome (nome),
    KEY idx_clientes_ativo_nome (ativo, nome),
    CONSTRAINT ck_clientes_tipo  CHECK (tipo_pessoa IN ('F', 'J')),
    CONSTRAINT ck_clientes_ativo CHECK (ativo IN (0, 1)),
    CONSTRAINT ck_clientes_doc   CHECK (
        (tipo_pessoa = 'F' AND CHAR_LENGTH(documento) = 11) OR
        (tipo_pessoa = 'J' AND CHAR_LENGTH(documento) = 14)
    )
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci
  COMMENT = 'Clientes (exclusão lógica)';


-- -----------------------------------------------------------------------------
-- 3. formas_pagamento
-- Formas de pagamento disponíveis (Dinheiro, PIX, ...).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS formas_pagamento (
    id              INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    descricao       VARCHAR(50)      NOT NULL,
    ativo           TINYINT(1)       NOT NULL DEFAULT 1,
    criado_em       DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_formas_pagamento_descricao (descricao),
    CONSTRAINT ck_formas_pagamento_ativo CHECK (ativo IN (0, 1))
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci
  COMMENT = 'Formas de pagamento';


-- -----------------------------------------------------------------------------
-- 4. contadores_recibo
-- Controle da numeração sequencial por emitente e ano.
-- A emissão faz SELECT ... FOR UPDATE nesta linha dentro da transação,
-- serializando emissões simultâneas e impedindo números duplicados ou
-- buracos na sequência (um ROLLBACK desfaz também o incremento).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contadores_recibo (
    emitente_id     INT UNSIGNED     NOT NULL,
    ano             SMALLINT UNSIGNED NOT NULL,
    ultimo_numero   INT UNSIGNED     NOT NULL DEFAULT 0,
    atualizado_em   DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP
                                     ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (emitente_id, ano),
    CONSTRAINT fk_contadores_emitente
        FOREIGN KEY (emitente_id) REFERENCES emitentes (id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci
  COMMENT = 'Numeração sequencial de recibos por emitente/ano';


-- -----------------------------------------------------------------------------
-- 5. recibos
-- Cabeçalho do recibo. Guarda uma CÓPIA (snapshot) dos dados do cliente e do
-- emitente no momento da emissão: editar ou desativar o cadastro depois não
-- altera o recibo histórico nem a sua reimpressão em PDF.
-- cliente_id / emitente_id continuam existindo para relatórios e filtros.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS recibos (
    id                      BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
    emitente_id             INT UNSIGNED     NOT NULL,
    ano                     SMALLINT UNSIGNED NOT NULL COMMENT 'Ano da numeração',
    numero                  INT UNSIGNED     NOT NULL COMMENT 'Sequencial dentro de emitente/ano',
    cliente_id              INT UNSIGNED     NOT NULL,
    data_emissao            DATE             NOT NULL,

    -- Valores financeiros
    subtotal                DECIMAL(12,2)    NOT NULL DEFAULT 0.00,
    desconto                DECIMAL(12,2)    NOT NULL DEFAULT 0.00,
    total                   DECIMAL(12,2)    NOT NULL DEFAULT 0.00,

    observacoes             TEXT             NULL,
    situacao                VARCHAR(10)      NOT NULL DEFAULT 'EMITIDO'
                                             COMMENT 'EMITIDO ou CANCELADO',
    motivo_cancelamento     VARCHAR(255)     NULL,
    cancelado_em            DATETIME         NULL,

    -- Snapshot do cliente na data da emissão
    cliente_nome            VARCHAR(150)     NOT NULL,
    cliente_tipo_pessoa     CHAR(1)          NOT NULL,
    cliente_documento       VARCHAR(14)      NOT NULL,
    cliente_telefone        VARCHAR(20)      NULL,
    cliente_endereco        VARCHAR(300)     NULL,

    -- Snapshot do emitente na data da emissão
    emitente_nome           VARCHAR(150)     NOT NULL,
    emitente_tipo_pessoa    CHAR(1)          NOT NULL,
    emitente_documento      VARCHAR(14)      NOT NULL,
    emitente_telefone       VARCHAR(20)      NULL,
    emitente_endereco       VARCHAR(300)     NULL,

    criado_em               DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id),

    -- Garantia final contra numeração duplicada
    UNIQUE KEY uk_recibos_numero (emitente_id, ano, numero),

    -- Histórico por cliente em ordem de data
    KEY idx_recibos_cliente_data (cliente_id, data_emissao),
    -- Consultas por período e dashboard
    KEY idx_recibos_data (data_emissao),
    -- Recibos cancelados / emitidos por período
    KEY idx_recibos_situacao_data (situacao, data_emissao),
    -- Pesquisa pelo nome do cliente gravado no recibo
    KEY idx_recibos_cliente_nome (cliente_nome),

    CONSTRAINT fk_recibos_emitente
        FOREIGN KEY (emitente_id) REFERENCES emitentes (id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_recibos_cliente
        FOREIGN KEY (cliente_id) REFERENCES clientes (id)
        ON UPDATE CASCADE ON DELETE RESTRICT,

    CONSTRAINT ck_recibos_numero     CHECK (numero > 0),
    CONSTRAINT ck_recibos_valores    CHECK (subtotal >= 0 AND desconto >= 0 AND total >= 0),
    CONSTRAINT ck_recibos_desconto   CHECK (desconto <= subtotal),
    CONSTRAINT ck_recibos_total      CHECK (total = subtotal - desconto),
    CONSTRAINT ck_recibos_situacao   CHECK (situacao IN ('EMITIDO', 'CANCELADO')),
    CONSTRAINT ck_recibos_cancelamento CHECK (
        (situacao = 'EMITIDO'   AND cancelado_em IS NULL) OR
        (situacao = 'CANCELADO' AND cancelado_em IS NOT NULL)
    )
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci
  COMMENT = 'Recibos emitidos (nunca apagados; cancelamento lógico)';


-- -----------------------------------------------------------------------------
-- 6. itens_recibo
-- Serviços vinculados a cada recibo.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS itens_recibo (
    id                  BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
    recibo_id           BIGINT UNSIGNED  NOT NULL,
    ordem               SMALLINT UNSIGNED NOT NULL COMMENT 'Posição do item no recibo',
    descricao           VARCHAR(255)     NOT NULL,
    quantidade          DECIMAL(10,3)    NOT NULL DEFAULT 1.000,
    valor_unitario      DECIMAL(12,2)    NOT NULL,
    subtotal            DECIMAL(12,2)    NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_itens_recibo_ordem (recibo_id, ordem),
    CONSTRAINT fk_itens_recibo_recibo
        FOREIGN KEY (recibo_id) REFERENCES recibos (id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT ck_itens_quantidade CHECK (quantidade > 0),
    CONSTRAINT ck_itens_valor      CHECK (valor_unitario >= 0),
    CONSTRAINT ck_itens_subtotal   CHECK (subtotal >= 0)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci
  COMMENT = 'Serviços de cada recibo';


-- -----------------------------------------------------------------------------
-- 7. pagamentos
-- Pagamentos vinculados aos recibos (permite pagamento parcial/parcelado).
-- Recebido = SUM(pagamentos.valor); pendente = total - recebido (calculados
-- por consulta, sem coluna redundante que poderia ficar inconsistente).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pagamentos (
    id                  BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
    recibo_id           BIGINT UNSIGNED  NOT NULL,
    forma_pagamento_id  INT UNSIGNED     NOT NULL,
    valor               DECIMAL(12,2)    NOT NULL,
    data_pagamento      DATE             NOT NULL,
    observacoes         VARCHAR(255)     NULL,
    criado_em           DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_pagamentos_recibo (recibo_id),
    KEY idx_pagamentos_forma_data (forma_pagamento_id, data_pagamento),
    KEY idx_pagamentos_data (data_pagamento),
    CONSTRAINT fk_pagamentos_recibo
        FOREIGN KEY (recibo_id) REFERENCES recibos (id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_pagamentos_forma
        FOREIGN KEY (forma_pagamento_id) REFERENCES formas_pagamento (id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT ck_pagamentos_valor CHECK (valor > 0)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci
  COMMENT = 'Pagamentos dos recibos';


-- -----------------------------------------------------------------------------
-- 8. configuracoes
-- Parâmetros gerais do sistema (chave/valor).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS configuracoes (
    chave           VARCHAR(60)      NOT NULL,
    valor           VARCHAR(500)     NULL,
    descricao       VARCHAR(255)     NULL,
    atualizado_em   DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP
                                     ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (chave)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci
  COMMENT = 'Parâmetros gerais do sistema';


-- -----------------------------------------------------------------------------
-- 9. historico_operacoes
-- Auditoria: emissão, cancelamento, alterações cadastrais etc.
-- Referência lógica (sem FK) para aceitar qualquer entidade e sobreviver a
-- futuras reorganizações. dados_* guardam texto (JSON serializado pelo app).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS historico_operacoes (
    id                  BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
    entidade            VARCHAR(30)      NOT NULL COMMENT 'cliente, recibo, emitente, pagamento...',
    entidade_id         BIGINT UNSIGNED  NULL,
    operacao            VARCHAR(30)      NOT NULL COMMENT 'EMISSAO, CANCELAMENTO, CADASTRO, ALTERACAO, DESATIVACAO...',
    descricao           VARCHAR(255)     NULL,
    dados_anteriores    LONGTEXT         NULL,
    dados_novos         LONGTEXT         NULL,
    criado_em           DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_historico_entidade (entidade, entidade_id),
    KEY idx_historico_operacao_data (operacao, criado_em),
    KEY idx_historico_data (criado_em)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci
  COMMENT = 'Auditoria de operações importantes';


-- -----------------------------------------------------------------------------
-- VIEW de apoio: recibos com valores recebidos e pendentes.
-- Facilita consultas no HeidiSQL e relatórios no sistema.
-- Recibos cancelados não possuem valor pendente.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_recibos_resumo AS
SELECT
    r.id,
    CONCAT(r.ano, '/', LPAD(r.numero, 6, '0'))        AS numero_formatado,
    r.emitente_id,
    r.ano,
    r.numero,
    r.cliente_id,
    r.cliente_nome,
    r.cliente_documento,
    r.data_emissao,
    r.subtotal,
    r.desconto,
    r.total,
    r.situacao,
    COALESCE(p.recebido, 0.00)                         AS recebido,
    CASE WHEN r.situacao = 'CANCELADO'
         THEN 0.00
         ELSE r.total - COALESCE(p.recebido, 0.00)
    END                                                AS pendente
FROM recibos r
LEFT JOIN (
    SELECT recibo_id, SUM(valor) AS recebido
    FROM pagamentos
    GROUP BY recibo_id
) p ON p.recibo_id = r.id;
