-- =============================================================================
-- ReciboFácil — consultas.sql
-- Consultas prontas para o HeidiSQL e referência para os repositórios do sistema.
-- Ajuste as variáveis abaixo e execute cada consulta separadamente (F9 / seleção).
-- =============================================================================

USE recibofacil;

SET @inicio  = '2026-01-01';
SET @fim     = '2026-12-31';
SET @numero  = 1;
SET @ano     = 2026;
SET @recibo  = 1;
SET @cliente = 1;


-- 1. Listar recibos com nome e documento do cliente ---------------------------
SELECT  r.id,
        CONCAT(r.ano, '/', LPAD(r.numero, 6, '0')) AS numero_recibo,
        r.data_emissao,
        c.nome       AS cliente_atual,
        r.cliente_nome AS cliente_na_emissao,
        r.cliente_documento,
        r.total,
        r.situacao
FROM    recibos r
JOIN    clientes c ON c.id = r.cliente_id
ORDER BY r.data_emissao DESC, r.id DESC;


-- 2. Consultar recibos por período --------------------------------------------
SELECT  id, numero_formatado, cliente_nome, data_emissao, total, situacao
FROM    vw_recibos_resumo
WHERE   data_emissao BETWEEN @inicio AND @fim
ORDER BY data_emissao, numero;


-- 3. Pesquisar pelo número do recibo ------------------------------------------
SELECT  *
FROM    vw_recibos_resumo
WHERE   ano = @ano AND numero = @numero;


-- 4. Consultar todos os itens de um recibo ------------------------------------
SELECT  i.ordem, i.descricao, i.quantidade, i.valor_unitario, i.subtotal
FROM    itens_recibo i
WHERE   i.recibo_id = @recibo
ORDER BY i.ordem;


-- 5. Listar clientes e quantidade de recibos emitidos -------------------------
SELECT  c.id,
        c.nome,
        c.documento,
        c.ativo,
        COUNT(r.id)                  AS qtd_recibos,
        COALESCE(SUM(CASE WHEN r.situacao = 'EMITIDO' THEN r.total END), 0) AS total_emitido
FROM    clientes c
LEFT JOIN recibos r ON r.cliente_id = c.id
GROUP BY c.id, c.nome, c.documento, c.ativo
ORDER BY c.nome;


-- 6. Total emitido por mês (somente recibos não cancelados) -------------------
SELECT  DATE_FORMAT(data_emissao, '%Y-%m') AS mes,
        COUNT(*)                           AS qtd_recibos,
        SUM(total)                         AS total_emitido
FROM    recibos
WHERE   situacao = 'EMITIDO'
GROUP BY DATE_FORMAT(data_emissao, '%Y-%m')
ORDER BY mes DESC;


-- 7. Valores recebidos e pendentes --------------------------------------------
-- 7a. Por recibo
SELECT  id, numero_formatado, cliente_nome, total, recebido, pendente
FROM    vw_recibos_resumo
WHERE   situacao = 'EMITIDO'
ORDER BY data_emissao DESC;

-- 7b. Totais gerais
SELECT  SUM(total)    AS total_emitido,
        SUM(recebido) AS total_recebido,
        SUM(pendente) AS total_pendente
FROM    vw_recibos_resumo
WHERE   situacao = 'EMITIDO';


-- 8. Relatórios --------------------------------------------------------------
-- 8a. Por cliente e período
SELECT  r.cliente_id,
        r.cliente_nome,
        COUNT(*)      AS qtd_recibos,
        SUM(r.total)  AS total_emitido
FROM    recibos r
WHERE   r.situacao = 'EMITIDO'
  AND   r.data_emissao BETWEEN @inicio AND @fim
GROUP BY r.cliente_id, r.cliente_nome
ORDER BY total_emitido DESC;

-- 8b. Por forma de pagamento e período
SELECT  f.descricao             AS forma_pagamento,
        COUNT(p.id)             AS qtd_pagamentos,
        SUM(p.valor)            AS total_recebido
FROM    pagamentos p
JOIN    formas_pagamento f ON f.id = p.forma_pagamento_id
JOIN    recibos r          ON r.id = p.recibo_id
WHERE   r.situacao = 'EMITIDO'
  AND   p.data_pagamento BETWEEN @inicio AND @fim
GROUP BY f.id, f.descricao
ORDER BY total_recebido DESC;

-- 8c. Por cliente específico
SELECT  numero_formatado, data_emissao, total, recebido, pendente, situacao
FROM    vw_recibos_resumo
WHERE   cliente_id = @cliente
ORDER BY data_emissao DESC;


-- 9. Últimos recibos emitidos ---------------------------------------------------
SELECT  id, numero_formatado, cliente_nome, data_emissao, total
FROM    vw_recibos_resumo
WHERE   situacao = 'EMITIDO'
ORDER BY id DESC
LIMIT 10;


-- 10. Recibos cancelados -------------------------------------------------------
SELECT  CONCAT(ano, '/', LPAD(numero, 6, '0')) AS numero_recibo,
        cliente_nome,
        total,
        cancelado_em,
        motivo_cancelamento
FROM    recibos
WHERE   situacao = 'CANCELADO'
ORDER BY cancelado_em DESC;


-- 11. (Extra) Auditoria de um recibo ------------------------------------------
SELECT  criado_em, operacao, descricao
FROM    historico_operacoes
WHERE   entidade = 'recibo' AND entidade_id = @recibo
ORDER BY criado_em;
