-- =============================================================================
-- ReciboFácil — seed.sql
-- Dados iniciais para inicialização e testes.
-- Idempotente: pode ser executado várias vezes sem duplicar registros.
-- Execute DEPOIS do schema.sql.
-- =============================================================================

USE recibofacil;

SET NAMES utf8mb4;

-- -----------------------------------------------------------------------------
-- Formas de pagamento (necessárias para registrar pagamentos)
-- -----------------------------------------------------------------------------
INSERT INTO formas_pagamento (descricao) VALUES
    ('Dinheiro'),
    ('PIX'),
    ('Cartão de Crédito'),
    ('Cartão de Débito'),
    ('Transferência Bancária'),
    ('Boleto'),
    ('Cheque')
ON DUPLICATE KEY UPDATE descricao = VALUES(descricao);

-- -----------------------------------------------------------------------------
-- Configurações gerais
-- -----------------------------------------------------------------------------
INSERT INTO configuracoes (chave, valor, descricao) VALUES
    ('rodape_recibo',
     'Recibo emitido eletronicamente pelo sistema ReciboFácil.',
     'Texto exibido no rodapé do PDF'),
    ('pasta_pdf',
     'output/pdfs',
     'Pasta onde os PDFs dos recibos são salvos'),
    ('moeda',
     'BRL',
     'Moeda utilizada nos valores'),
    ('itens_por_pagina',
     '20',
     'Quantidade de registros por página nas listagens')
ON DUPLICATE KEY UPDATE chave = chave;

-- -----------------------------------------------------------------------------
-- Emitente padrão (EXEMPLO — altere os dados na tela de configurações).
-- CNPJ fictício, porém com dígitos verificadores válidos.
-- Sem um emitente cadastrado não é possível emitir recibos.
-- -----------------------------------------------------------------------------
INSERT INTO emitentes
    (nome, tipo_pessoa, documento, telefone, email,
     logradouro, numero, bairro, cidade, uf, cep)
VALUES
    ('Empresa Exemplo Serviços LTDA', 'J', '11222333000181', '1733334444',
     'contato@exemplo.com.br',
     'Rua das Flores', '100', 'Centro', 'Bebedouro', 'SP', '14700000')
ON DUPLICATE KEY UPDATE nome = nome;

-- -----------------------------------------------------------------------------
-- Clientes de teste (CPFs fictícios com dígitos verificadores válidos).
-- Podem ser removidos após os testes iniciais (desativando-os pelo sistema).
-- -----------------------------------------------------------------------------
INSERT INTO clientes
    (nome, tipo_pessoa, documento, telefone, email,
     logradouro, numero, bairro, cidade, uf, cep)
VALUES
    ('Maria Aparecida da Silva', 'F', '52998224725', '17999990001',
     'maria@exemplo.com',
     'Av. Brasil', '250', 'Jardim América', 'Bebedouro', 'SP', '14701000'),
    ('João Pedro Oliveira', 'F', '11144477735', '17999990002',
     'joao@exemplo.com',
     'Rua Quinze de Novembro', '45', 'Centro', 'Bebedouro', 'SP', '14700100')
ON DUPLICATE KEY UPDATE nome = nome;
