"""Prepara o banco de dados do ReciboFácil no MariaDB.

Uso (a partir da raiz do projeto, com o ambiente virtual ativo):

    python database/setup_db.py              # schema + seed + usuário da aplicação + verificação
    python database/setup_db.py --sem-seed   # não carrega o seed.sql
    python database/setup_db.py --verificar  # apenas verifica a estrutura existente

O script é idempotente: pode ser executado mais de uma vez sem apagar dados.
Usa o usuário administrador (DB_ADMIN_USER) somente aqui; o sistema em si
conecta com o usuário dedicado (DB_USER), que recebe permissões apenas
sobre o banco do ReciboFácil.
"""

from __future__ import annotations

import argparse
import getpass
import sys
from pathlib import Path

import pymysql
from pymysql.cursors import Cursor

# Permite executar "python database/setup_db.py" a partir da raiz do projeto.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config.settings import DATABASE_DIR, DatabaseSettings, load_database_settings  # noqa: E402

DB_NAME_PADRAO = "recibofacil"
SENHA_PLACEHOLDER = "troque_esta_senha"

TABELAS_ESPERADAS = [
    "clientes",
    "configuracoes",
    "contadores_recibo",
    "emitentes",
    "formas_pagamento",
    "historico_operacoes",
    "itens_recibo",
    "pagamentos",
    "recibos",
]
VIEWS_ESPERADAS = ["vw_recibos_resumo"]


# --------------------------------------------------------------------------
# Leitura e execução de scripts SQL
# --------------------------------------------------------------------------
def dividir_sql(script: str) -> list[str]:
    """Divide um script SQL em comandos, respeitando textos entre aspas e comentários."""
    comandos: list[str] = []
    atual: list[str] = []
    i, n = 0, len(script)
    aspas: str | None = None  # caractere de aspas aberto, se houver

    while i < n:
        c = script[i]
        prox = script[i + 1] if i + 1 < n else ""

        if aspas:
            atual.append(c)
            if c == "\\" and aspas != "`" and i + 1 < n:
                atual.append(prox)
                i += 2
                continue
            if c == aspas:
                aspas = None
            i += 1
            continue

        # Comentário de linha: "-- " ou "#"
        if (c == "-" and prox == "-" and script[i + 2 : i + 3] in (" ", "\t", "\n", "\r", "")) or c == "#":
            while i < n and script[i] != "\n":
                i += 1
            continue

        # Comentário de bloco: /* ... */
        if c == "/" and prox == "*":
            fim = script.find("*/", i + 2)
            i = n if fim == -1 else fim + 2
            continue

        if c in ("'", '"', "`"):
            aspas = c
            atual.append(c)
        elif c == ";":
            comando = "".join(atual).strip()
            if comando:
                comandos.append(comando)
            atual = []
        else:
            atual.append(c)
        i += 1

    resto = "".join(atual).strip()
    if resto:
        comandos.append(resto)
    return comandos


def executar_arquivo(cursor: Cursor, caminho: Path) -> int:
    """Executa todos os comandos de um arquivo .sql e devolve a quantidade executada."""
    if not caminho.is_file():
        raise FileNotFoundError(f"Arquivo SQL não encontrado: {caminho}")
    comandos = dividir_sql(caminho.read_text(encoding="utf-8"))
    for comando in comandos:
        try:
            cursor.execute(comando)
        except pymysql.MySQLError as exc:
            resumo = " ".join(comando.split())[:120]
            raise RuntimeError(f"Erro em {caminho.name}: {exc}\n  Comando: {resumo}...") from exc
    return len(comandos)


# --------------------------------------------------------------------------
# Conexão e usuário da aplicação
# --------------------------------------------------------------------------
def conectar_admin(cfg: DatabaseSettings) -> pymysql.connections.Connection:
    senha = cfg.admin_password or getpass.getpass(
        f"Senha do administrador do MariaDB ({cfg.admin_user}@{cfg.host}): "
    )
    try:
        return pymysql.connect(
            host=cfg.host,
            port=cfg.port,
            user=cfg.admin_user,
            password=senha,
            charset="utf8mb4",
            autocommit=True,
        )
    except pymysql.err.OperationalError as exc:
        raise SystemExit(
            f"Não foi possível conectar ao MariaDB em {cfg.host}:{cfg.port} como "
            f"'{cfg.admin_user}'.\n  Detalhe: {exc}\n"
            "  Verifique se o serviço MariaDB está iniciado e se usuário/senha estão corretos."
        )


def criar_usuario_aplicacao(cursor: Cursor, cfg: DatabaseSettings) -> None:
    """Cria (ou atualiza a senha de) o usuário da aplicação, com acesso só ao banco do sistema."""
    for host in ("localhost", "127.0.0.1"):
        cursor.execute("CREATE USER IF NOT EXISTS %s@%s IDENTIFIED BY %s", (cfg.user, host, cfg.password))
        cursor.execute("ALTER USER %s@%s IDENTIFIED BY %s", (cfg.user, host, cfg.password))
        # O nome do banco é validado em main(); identificadores não aceitam parâmetros.
        cursor.execute(
            f"GRANT SELECT, INSERT, UPDATE, DELETE ON `{cfg.name}`.* TO %s@%s", (cfg.user, host)
        )
    cursor.execute("FLUSH PRIVILEGES")


# --------------------------------------------------------------------------
# Verificação da estrutura
# --------------------------------------------------------------------------
def verificar(cursor: Cursor, cfg: DatabaseSettings) -> bool:
    """Confere tabelas, engine, collation, chaves estrangeiras e restrições."""
    ok = True

    def aviso(mensagem: str) -> None:
        nonlocal ok
        ok = False
        print(f"  [FALHA] {mensagem}")

    cursor.execute("SELECT VERSION()")
    print(f"  Servidor: {cursor.fetchone()[0]}")

    cursor.execute(
        "SELECT TABLE_NAME, ENGINE, TABLE_COLLATION FROM information_schema.TABLES "
        "WHERE TABLE_SCHEMA = %s AND TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME",
        (cfg.name,),
    )
    tabelas = {linha[0]: (linha[1], linha[2]) for linha in cursor.fetchall()}
    for nome in TABELAS_ESPERADAS:
        if nome not in tabelas:
            aviso(f"tabela ausente: {nome}")
            continue
        engine, collation = tabelas[nome]
        if engine != "InnoDB":
            aviso(f"{nome}: engine {engine} (esperado InnoDB)")
        if not str(collation).startswith("utf8mb4"):
            aviso(f"{nome}: collation {collation} (esperado utf8mb4)")
    print(f"  Tabelas encontradas: {len(tabelas)} (esperadas: {len(TABELAS_ESPERADAS)})")

    cursor.execute(
        "SELECT TABLE_NAME FROM information_schema.VIEWS WHERE TABLE_SCHEMA = %s", (cfg.name,)
    )
    views = {linha[0] for linha in cursor.fetchall()}
    for nome in VIEWS_ESPERADAS:
        if nome not in views:
            aviso(f"view ausente: {nome}")

    cursor.execute(
        "SELECT COUNT(*) FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = %s",
        (cfg.name,),
    )
    print(f"  Chaves estrangeiras: {cursor.fetchone()[0]}")

    cursor.execute(
        "SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS "
        "WHERE CONSTRAINT_SCHEMA = %s AND CONSTRAINT_TYPE = 'CHECK'",
        (cfg.name,),
    )
    print(f"  Restrições CHECK: {cursor.fetchone()[0]}")

    cursor.execute(
        "SELECT COUNT(*) FROM information_schema.STATISTICS "
        "WHERE TABLE_SCHEMA = %s AND INDEX_NAME <> 'PRIMARY' AND SEQ_IN_INDEX = 1",
        (cfg.name,),
    )
    print(f"  Índices (além das chaves primárias): {cursor.fetchone()[0]}")

    return ok


# --------------------------------------------------------------------------
# Programa principal
# --------------------------------------------------------------------------
def main() -> int:
    parser = argparse.ArgumentParser(description="Prepara o banco de dados do ReciboFácil.")
    parser.add_argument("--sem-seed", action="store_true", help="não carrega o seed.sql")
    parser.add_argument("--verificar", action="store_true", help="apenas verifica a estrutura existente")
    args = parser.parse_args()

    cfg = load_database_settings()

    if cfg.name != DB_NAME_PADRAO:
        print(
            f"DB_NAME={cfg.name!r}: o schema.sql cria o banco '{DB_NAME_PADRAO}'. "
            f"Use DB_NAME={DB_NAME_PADRAO} no .env."
        )
        return 1

    if not args.verificar and (not cfg.password or cfg.password == SENHA_PLACEHOLDER):
        print("Defina uma senha própria em DB_PASSWORD no arquivo .env (não use o valor de exemplo).")
        return 1

    conexao = conectar_admin(cfg)
    try:
        with conexao.cursor() as cursor:
            if not args.verificar:
                print("1/4 Criando banco e tabelas (schema.sql)...")
                total = executar_arquivo(cursor, DATABASE_DIR / "schema.sql")
                print(f"    {total} comandos executados.")

                if args.sem_seed:
                    print("2/4 Seed ignorado (--sem-seed).")
                else:
                    print("2/4 Carregando dados iniciais (seed.sql)...")
                    total = executar_arquivo(cursor, DATABASE_DIR / "seed.sql")
                    print(f"    {total} comandos executados.")

                print(f"3/4 Configurando o usuário da aplicação ({cfg.user})...")
                criar_usuario_aplicacao(cursor, cfg)

                print("4/4 Verificando a estrutura...")
            else:
                print("Verificando a estrutura...")

            try:
                cursor.execute(f"USE `{cfg.name}`")
            except pymysql.err.OperationalError:
                print(f"O banco '{cfg.name}' ainda não existe. Execute: python database/setup_db.py")
                return 2
            sucesso = verificar(cursor, cfg)
    finally:
        conexao.close()

    print("\nBanco de dados pronto." if sucesso else "\nA verificação encontrou problemas (veja acima).")
    return 0 if sucesso else 2


if __name__ == "__main__":
    sys.exit(main())
