# ReciboFácil — Modelo de dados

Banco `recibofacil` · MariaDB 10.4.13 · InnoDB · `utf8mb4` / `utf8mb4_unicode_ci`

## Diagrama de relacionamentos

```mermaid
erDiagram
    EMITENTES ||--o{ RECIBOS : emite
    CLIENTES  ||--o{ RECIBOS : recebe
    RECIBOS   ||--|{ ITENS_RECIBO : contem
    RECIBOS   ||--o{ PAGAMENTOS : "e pago por"
    FORMAS_PAGAMENTO ||--o{ PAGAMENTOS : classifica
    EMITENTES ||--o{ CONTADORES_RECIBO : numera

    EMITENTES { int id PK  varchar nome  char tipo_pessoa  varchar documento UK  tinyint ativo }
    CLIENTES  { int id PK  varchar nome  char tipo_pessoa  varchar documento UK  tinyint ativo }
    RECIBOS {
        bigint id PK
        int emitente_id FK
        smallint ano
        int numero
        int cliente_id FK
        date data_emissao
        decimal subtotal
        decimal desconto
        decimal total
        varchar situacao
        varchar cliente_nome "cópia na emissão"
        varchar emitente_nome "cópia na emissão"
    }
    ITENS_RECIBO { bigint id PK  bigint recibo_id FK  smallint ordem  varchar descricao  decimal quantidade  decimal valor_unitario  decimal subtotal }
    PAGAMENTOS { bigint id PK  bigint recibo_id FK  int forma_pagamento_id FK  decimal valor  date data_pagamento }
    FORMAS_PAGAMENTO { int id PK  varchar descricao UK  tinyint ativo }
    CONTADORES_RECIBO { int emitente_id PK  smallint ano PK  int ultimo_numero }
    CONFIGURACOES { varchar chave PK  varchar valor }
    HISTORICO_OPERACOES { bigint id PK  varchar entidade  bigint entidade_id  varchar operacao  longtext dados_anteriores  longtext dados_novos }
```

Versão em texto:

```
 clientes (1) ───────< recibos >─────── (1) emitentes ───< contadores_recibo
                          │
              ┌───────────┴─────────────┐
        itens_recibo (N)          pagamentos (N) >─── (1) formas_pagamento

 historico_operacoes  → referência lógica (entidade + entidade_id)
 configuracoes        → parâmetros chave/valor
```

## Tabelas

| Tabela | Finalidade | Chaves e índices principais |
|---|---|---|
| `clientes` | Cadastro de clientes (exclusão lógica por `ativo`) | PK `id`; único `documento`; índices `nome` e `(ativo, nome)` |
| `emitentes` | Quem emite os recibos | PK `id`; único `documento`; índice `nome` |
| `formas_pagamento` | Dinheiro, PIX, cartões... | PK `id`; único `descricao` |
| `contadores_recibo` | Numeração por emitente e ano | PK composta `(emitente_id, ano)` |
| `recibos` | Cabeçalho do recibo, com cópia dos dados do cliente e do emitente | PK `id`; **único `(emitente_id, ano, numero)`**; `(cliente_id, data_emissao)`; `data_emissao`; `(situacao, data_emissao)`; `cliente_nome` |
| `itens_recibo` | Serviços de cada recibo | PK `id`; único `(recibo_id, ordem)` |
| `pagamentos` | Pagamentos (parciais ou totais) | PK `id`; `recibo_id`; `(forma_pagamento_id, data_pagamento)`; `data_pagamento` |
| `configuracoes` | Parâmetros gerais | PK `chave` |
| `historico_operacoes` | Auditoria (emissão, cancelamento, alterações) | PK `id`; `(entidade, entidade_id)`; `(operacao, criado_em)`; `criado_em` |

View de apoio: **`vw_recibos_resumo`** — recibos com `recebido` e `pendente` calculados (cancelados têm pendente zero).

## Regras de exclusão (chaves estrangeiras)

| Relacionamento | Regra | Motivo |
|---|---|---|
| `recibos → clientes` | `RESTRICT` | cliente com recibos não pode ser apagado (só desativado) |
| `recibos → emitentes` | `RESTRICT` | idem |
| `itens_recibo → recibos` | `CASCADE` | itens não existem sem o recibo |
| `pagamentos → recibos` | `RESTRICT` | pagamentos não são apagados em cascata |
| `pagamentos → formas_pagamento` | `RESTRICT` | forma usada não pode ser removida (só desativada) |
| `contadores_recibo → emitentes` | `RESTRICT` | preserva a sequência |

## Decisões de modelagem

1. **Histórico preservado:** o recibo guarda uma cópia (nome, documento, telefone, endereço) do cliente e do emitente no momento da emissão. Editar ou desativar o cadastro depois não altera o recibo nem o PDF reimpresso. O vínculo `cliente_id` continua existindo para relatórios.
2. **Numeração segura:** `SELECT ... FOR UPDATE` na linha de `contadores_recibo`, dentro da mesma transação que grava o recibo. Emissões simultâneas ficam em fila; um `ROLLBACK` desfaz também o número (sem buracos). O índice único `(emitente_id, ano, numero)` é a segunda barreira.
3. **Valores monetários** em `DECIMAL(12,2)`; quantidades em `DECIMAL(10,3)`. No Python, sempre `Decimal`.
4. **Restrições `CHECK`** (ativas no MariaDB 10.4): valores não negativos, quantidade > 0, `desconto <= subtotal`, `total = subtotal − desconto`, tamanho do documento coerente com o tipo de pessoa, situação e dados de cancelamento consistentes.
5. **Recebido e pendente** são calculados por consulta (`total − SUM(pagamentos)`), nunca gravados — não há como ficarem inconsistentes.
6. **Exclusão lógica:** clientes são desativados e recibos são cancelados; nada importante é apagado.
7. **CNPJ alfanumérico:** a coluna `documento` (`VARCHAR(14)`) aceita o novo formato do CNPJ com letras.

## Consultas prontas

O arquivo [`database/consultas.sql`](../database/consultas.sql) traz, para uso no HeidiSQL: recibos com cliente e documento, por período, por número, itens de um recibo, clientes com quantidade de recibos, total por mês, recebido e pendente, relatórios por cliente / período / forma de pagamento, últimos recibos e recibos cancelados.
