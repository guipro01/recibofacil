"""Testes da geração de PDF."""

from datetime import date
from decimal import Decimal

import pymupdf  # apenas para ler o PDF gerado nos testes
import pytest

from app.models.recibo import ItemRecibo
from app.repositories.configuracao_repository import ConfiguracaoRepository
from app.services.configuracao_service import CHAVE_PASTA_PDF, CHAVE_RODAPE
from app.services.recibo_service import NovoPagamento, NovoRecibo
from tests.conftest import gerar_cpf


def _texto(caminho) -> str:
    with pymupdf.open(caminho) as pdf:
        return "\n".join(pagina.get_text() for pagina in pdf)


def _emitir(ambiente, itens=None, **extras):
    s = ambiente.servicos
    itens = itens or [ItemRecibo(descricao="Consultoria técnica", quantidade=Decimal("2.5"), valor_unitario=Decimal("350"))]
    return s.recibos.emitir(NovoRecibo(cliente_id=ambiente.cliente.id, emitente_id=ambiente.emitente.id, itens=itens, **extras))


@pytest.fixture()
def pasta_pdf(ambiente, tmp_path):
    """Aponta os PDFs para uma pasta temporária e restaura as configurações no final (sem deixar auditoria)."""
    c = ambiente.servicos.configuracoes
    repo = ConfiguracaoRepository()
    original = (c.rodape_recibo(), c.pasta_pdf_texto())

    def gravar(rodape: str, pasta: str) -> None:
        with ambiente.servicos.db.transaction() as cur:
            repo.definir(cur, CHAVE_RODAPE, rodape)
            repo.definir(cur, CHAVE_PASTA_PDF, pasta)

    gravar("Rodapé de teste do PDF", str(tmp_path))
    yield tmp_path
    gravar(*original)


def test_pdf_a4_com_conteudo_correto(ambiente, pasta_pdf):
    recibo = _emitir(
        ambiente, desconto=Decimal("75"), observacoes="Pagamento do mês & ajustes <teste>",
        pagamento=NovoPagamento(forma_pagamento_id=2, valor=Decimal("300"), data_pagamento=date.today()),
    )
    caminho = ambiente.servicos.pdf.gerar(recibo.id)
    assert caminho.parent == pasta_pdf and caminho.name == f"Recibo_{recibo.ano}-000001.pdf"
    with pymupdf.open(caminho) as pdf:
        assert pdf.page_count == 1 and round(pdf[0].rect.width) == 595 and round(pdf[0].rect.height) == 842  # A4
    texto = _texto(caminho)
    for esperado in [
        f"Nº {recibo.numero_formatado}", "Emitente de Teste LTDA", "Cliente de Teste", "Consultoria técnica",
        "R$ 875,00", "R$ 800,00", "oitocentos reais", "- R$ 75,00", "Pagamento do mês & ajustes <teste>",
        "Recebido: R$ 300,00", "Pendente: R$ 500,00", "Rodapé de teste do PDF", "Recebemos de",
    ]:
        assert esperado in texto, esperado
    assert "CANCELADO" not in texto


def test_pdf_de_recibo_cancelado_tem_aviso(ambiente, pasta_pdf):
    recibo = _emitir(ambiente)
    ambiente.servicos.recibos.cancelar(recibo.id, "Emitido em duplicidade")
    texto = _texto(ambiente.servicos.pdf.gerar(recibo.id))
    assert "RECIBO CANCELADO" in texto and "Emitido em duplicidade" in texto


def test_pdf_com_muitos_itens_usa_varias_paginas(ambiente, pasta_pdf):
    itens = [ItemRecibo(descricao=f"Serviço número {i} com descrição razoavelmente longa para ocupar espaço", quantidade=Decimal("1"), valor_unitario=Decimal("10")) for i in range(80)]
    recibo = _emitir(ambiente, itens=itens)
    caminho = ambiente.servicos.pdf.gerar(recibo.id)
    with pymupdf.open(caminho) as pdf:
        assert pdf.page_count >= 2
    texto = _texto(caminho)
    assert "Serviço número 79" in texto and "R$ 800,00" in texto


def test_pdf_usa_dados_gravados_no_recibo_e_nao_o_cadastro_atual(ambiente, pasta_pdf):
    s = ambiente.servicos
    recibo = _emitir(ambiente)
    cliente = s.clientes.obter(ambiente.cliente.id)
    cliente.nome = "Nome Alterado Depois"
    s.clientes.atualizar(cliente)
    texto = _texto(s.pdf.gerar(recibo.id))
    assert "Cliente de Teste" in texto and "Nome Alterado Depois" not in texto


def test_regeracao_com_arquivo_bloqueado_grava_copia(ambiente, pasta_pdf, monkeypatch):
    """No Windows o PDF aberto no visualizador não pode ser sobrescrito: grava uma cópia nova."""
    from app.services import pdf_service

    recibo = _emitir(ambiente)
    original = pdf_service.gerar_pdf_recibo
    chamadas = []

    def falha_na_primeira(detalhes, rodape, destino):
        chamadas.append(destino)
        if len(chamadas) == 1:
            raise PermissionError("arquivo em uso")
        return original(detalhes, rodape, destino)

    monkeypatch.setattr(pdf_service, "gerar_pdf_recibo", falha_na_primeira)
    caminho = ambiente.servicos.pdf.gerar(recibo.id)
    assert caminho != chamadas[0] and caminho.exists()
