"""Testes dos validadores e utilitários de texto (não precisam do banco)."""

from datetime import date
from decimal import Decimal

import pytest

from app.models.cliente import Cliente
from app.models.recibo import ItemRecibo
from app.utils.extenso import valor_por_extenso
from app.utils.formatadores import (
    formatar_quantidade,
    mascara_cep,
    mascara_data,
    mascara_documento,
    mascara_telefone,
    normalizar_documento,
)
from app.validators import recibo as validador
from app.validators.documento import identificar_documento, validar_cnpj, validar_cpf
from app.validators.pessoa import validar_e_normalizar_pessoa
from tests.conftest import gerar_cnpj, gerar_cpf


@pytest.mark.parametrize("cpf", ["529.982.247-25", "11144477735", "390.533.447-05"])
def test_cpf_valido(cpf):
    assert validar_cpf(cpf)


@pytest.mark.parametrize("cpf", ["", "123", "111.111.111-11", "529.982.247-26", "5299822472x", "000.000.000-00"])
def test_cpf_invalido(cpf):
    assert not validar_cpf(cpf)


@pytest.mark.parametrize("cnpj", ["11.222.333/0001-81", "12.ABC.345/01DE-35", "12abc34501de35"])
def test_cnpj_valido_inclusive_alfanumerico(cnpj):
    assert validar_cnpj(cnpj)


@pytest.mark.parametrize("cnpj", ["", "11.222.333/0001-82", "00.000.000/0000-00", "12.ABC.345/01DE-36", "12.ABC.345/01DE-3A"])
def test_cnpj_invalido(cnpj):
    assert not validar_cnpj(cnpj)


def test_geradores_de_teste_produzem_documentos_validos():
    for _ in range(50):
        assert validar_cpf(gerar_cpf())
        assert validar_cnpj(gerar_cnpj())


def test_identificar_documento():
    assert identificar_documento("529.982.247-25") == ("F", "52998224725")
    assert identificar_documento("11.222.333/0001-81") == ("J", "11222333000181")
    for texto, trecho in [("", "Informe"), ("123", "11 dígitos"), ("111.111.111-11", "CPF inválido"), ("11.222.333/0001-82", "CNPJ inválido")]:
        with pytest.raises(ValueError, match=trecho):
            identificar_documento(texto)


def test_normalizar_documento():
    assert normalizar_documento(" 12.abc.345/01de-35 ") == "12ABC34501DE35"


def test_pessoa_valida_e_normalizada():
    c = Cliente(nome="  Ana   Maria  ", tipo_pessoa="J", documento="529.982.247-25", telefone="(17) 99999-0001",
                email=" ana@exemplo.com ", cep="14700-000", uf="sp", cidade="  ", logradouro="")
    assert validar_e_normalizar_pessoa(c) == []
    assert (c.nome, c.tipo_pessoa, c.documento) == ("Ana Maria", "F", "52998224725")  # tipo vem do documento
    assert (c.telefone, c.cep, c.uf, c.email) == ("17999990001", "14700000", "SP", "ana@exemplo.com")
    assert c.cidade is None and c.logradouro is None


def test_pessoa_acumula_todos_os_erros():
    c = Cliente(nome=" ", tipo_pessoa="F", documento="123", telefone="123", email="sem-arroba", cep="1", uf="XX")
    erros = validar_e_normalizar_pessoa(c)
    textos = " | ".join(erros)
    for esperado in ["Informe o nome", "11 dígitos", "Telefone inválido", "E-mail inválido", "CEP inválido", "UF inválida"]:
        assert esperado in textos
    assert len(erros) == 6


def test_pessoa_limites_de_tamanho():
    c = Cliente(nome="A" * 151, tipo_pessoa="F", documento="52998224725", numero="1" * 11)
    erros = validar_e_normalizar_pessoa(c)
    assert any("Nome" in e and "150" in e for e in erros)
    assert any("Número" in e and "10" in e for e in erros)


def item(desc="Serviço", qtd="1", valor="10"):
    return ItemRecibo(descricao=desc, quantidade=Decimal(qtd), valor_unitario=Decimal(valor))


def test_validacao_de_itens():
    assert validador.validar_itens([item()]) == []
    assert "pelo menos um serviço" in validador.validar_itens([])[0]
    erros = " | ".join(validador.validar_itens([item(desc=" ", qtd="0", valor="0")]))
    assert "descrição" in erros and "quantidade" in erros and "valor unitário" in erros
    assert any("255" in e for e in validador.validar_itens([item(desc="x" * 256)]))


def test_validacao_de_totais_e_datas():
    assert validador.validar_totais(Decimal("100"), Decimal("10")) == []
    assert "negativo" in validador.validar_totais(Decimal("100"), Decimal("-1"))[0]
    assert "maior que o subtotal" in validador.validar_totais(Decimal("100"), Decimal("150"))[0]
    assert "maior que zero" in validador.validar_totais(Decimal("100"), Decimal("100"))[0]
    hoje = date(2026, 6, 15)
    assert validador.validar_data_emissao(hoje, hoje) == []
    assert "futura" in validador.validar_data_emissao(date(2026, 6, 16), hoje)[0]
    assert validador.validar_data_emissao(date(1999, 1, 1), hoje)
    assert "pendente" in validador.validar_pagamento(Decimal("50"), hoje, hoje, Decimal("40"))[0]
    assert validador.validar_pagamento(Decimal("0"), hoje, hoje, Decimal("40"))


@pytest.mark.parametrize(
    "valor, esperado",
    [
        ("0", "zero real"), ("0.01", "um centavo"), ("1", "um real"), ("2.50", "dois reais e cinquenta centavos"),
        ("100", "cem reais"), ("101", "cento e um reais"), ("1000", "mil reais"), ("1001", "mil e um reais"),
        ("1100", "mil e cem reais"), ("1101", "mil cento e um reais"), ("2500", "dois mil e quinhentos reais"),
        ("21000", "vinte e um mil reais"), ("1000000", "um milhão de reais"), ("2000000", "dois milhões de reais"),
        ("1200000", "um milhão e duzentos mil reais"),
        ("1234567.89", "um milhão duzentos e trinta e quatro mil quinhentos e sessenta e sete reais e oitenta e nove centavos"),
        ("915", "novecentos e quinze reais"), ("3.01", "três reais e um centavo"),
    ],
)
def test_valor_por_extenso(valor, esperado):
    assert valor_por_extenso(valor) == esperado


def test_extenso_rejeita_negativo():
    with pytest.raises(ValueError):
        valor_por_extenso("-1")


def test_mascaras():
    assert mascara_documento("52998224725") == "529.982.247-25"
    assert mascara_documento("529982") == "529.982"
    assert mascara_documento("11222333000181") == "11.222.333/0001-81"
    assert mascara_documento("12abc34501de35") == "12.ABC.345/01DE-35"
    assert mascara_telefone("1799999000") == "(17) 9999-9000"
    assert mascara_telefone("17999990001") == "(17) 99999-0001"
    assert mascara_cep("14700000") == "14700-000"
    assert mascara_data("18112026") == "18/11/2026"
    assert mascara_data("1811") == "18/11"


def test_formatar_quantidade():
    assert formatar_quantidade(Decimal("2.000")) == "2"
    assert formatar_quantidade(Decimal("1.500")) == "1,5"
    assert formatar_quantidade(Decimal("0.125")) == "0,125"
    assert formatar_quantidade(Decimal("10")) == "10"
