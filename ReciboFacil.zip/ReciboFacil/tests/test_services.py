"""Testes das regras de negócio (serviços). Cada teste usa emitente e cliente próprios e limpa tudo no final."""

from __future__ import annotations

import threading
from datetime import date, timedelta
from decimal import Decimal

import pytest

from app.core.exceptions import RegraNegocioError, RegistroNaoEncontradoError, ValidacaoError
from app.models.cliente import Cliente
from app.models.filtros import FiltroRecibos
from app.models.recibo import ItemRecibo
from app.services.recibo_service import NovoPagamento, NovoRecibo
from tests.conftest import gerar_cpf

HOJE = date.today()


def item(desc="Serviço", qtd="2", valor="50.00"):
    return ItemRecibo(descricao=desc, quantidade=Decimal(qtd), valor_unitario=Decimal(valor))


def novo(ambiente, **extras) -> NovoRecibo:
    base = dict(cliente_id=ambiente.cliente.id, emitente_id=ambiente.emitente.id, itens=[item()])
    base.update(extras)
    return NovoRecibo(**base)


def id_forma(ambiente, descricao="PIX") -> int:
    return next(f.id for f in ambiente.servicos.configuracoes.listar_formas() if f.descricao == descricao)


# ------------------------------------------------------------------ clientes
def test_cadastro_de_cliente_valida_e_normaliza(ambiente):
    s = ambiente.servicos
    cliente = s.clientes.cadastrar(Cliente(nome=" João  da Silva ", tipo_pessoa="J", documento=gerar_cpf(), telefone="(17) 3333-4444"))
    ambiente.ids_extras.setdefault("cliente", []).append(cliente.id)
    lido = s.clientes.obter(cliente.id)
    assert lido.nome == "João da Silva" and lido.tipo_pessoa == "F" and lido.telefone == "1733334444" and lido.ativo


def test_cliente_invalido_nao_e_gravado(ambiente):
    s = ambiente.servicos
    antes = s.clientes.pesquisar(situacao="todos").total
    with pytest.raises(ValidacaoError) as erro:
        s.clientes.cadastrar(Cliente(nome="", tipo_pessoa="F", documento="111.111.111-11"))
    assert len(erro.value.erros) == 2
    assert s.clientes.pesquisar(situacao="todos").total == antes


def test_documento_duplicado_e_recusado_com_mensagem(ambiente):
    s = ambiente.servicos
    with pytest.raises(ValidacaoError, match="Já existe um cliente com este CPF/CNPJ"):
        s.clientes.cadastrar(Cliente(nome="Outro Nome", tipo_pessoa="F", documento=ambiente.cliente.documento))


def test_atualizar_cliente_registra_somente_o_que_mudou(ambiente, db):
    s = ambiente.servicos
    cliente = s.clientes.obter(ambiente.cliente.id)
    cliente.nome, cliente.cidade = "Nome Atualizado", "Bebedouro"
    s.clientes.atualizar(cliente)
    with db.cursor() as cur:
        cur.execute("SELECT dados_anteriores, dados_novos FROM historico_operacoes "
                    "WHERE entidade='cliente' AND entidade_id=%s AND operacao='ALTERACAO'", (cliente.id,))
        linha = cur.fetchone()
    assert '"nome": "Cliente de Teste"' in linha["dados_anteriores"]
    assert '"nome": "Nome Atualizado"' in linha["dados_novos"] and "telefone" not in linha["dados_novos"]


def test_nao_permite_documento_de_outro_cliente(ambiente):
    s = ambiente.servicos
    outro = s.clientes.cadastrar(Cliente(nome="Outro Cliente", tipo_pessoa="F", documento=gerar_cpf()))
    ambiente.ids_extras.setdefault("cliente", []).append(outro.id)
    outro.documento = ambiente.cliente.documento
    with pytest.raises(ValidacaoError, match="outro cliente"):
        s.clientes.atualizar(outro)


def test_desativar_e_reativar_cliente(ambiente):
    s = ambiente.servicos
    s.clientes.desativar(ambiente.cliente.id)
    assert not s.clientes.obter(ambiente.cliente.id).ativo
    assert ambiente.cliente.id not in [c.id for c in s.clientes.pesquisar_ativos("Cliente de Teste")]
    with pytest.raises(ValidacaoError, match="desativado"):
        s.recibos.emitir(novo(ambiente))
    s.clientes.reativar(ambiente.cliente.id)
    assert s.recibos.emitir(novo(ambiente)).numero == 1


def test_cliente_inexistente(ambiente):
    with pytest.raises(RegistroNaoEncontradoError):
        ambiente.servicos.clientes.obter(999999999)
    with pytest.raises(RegistroNaoEncontradoError):
        ambiente.servicos.clientes.desativar(999999999)


# ------------------------------------------------------------------- recibos
def test_emissao_completa(ambiente):
    s = ambiente.servicos
    recibo = s.recibos.emitir(novo(
        ambiente, itens=[item("Consultoria", "1.5", "100"), item("Deslocamento", "1", "33.33")],
        desconto=Decimal("10"), observacoes="  Obrigado!  ",
        pagamento=NovoPagamento(forma_pagamento_id=id_forma(ambiente), valor=Decimal("100"), data_pagamento=HOJE)))
    assert recibo.numero_formatado == f"{HOJE.year}/000001"

    d = s.recibos.obter_detalhes(recibo.id)
    assert (d.recibo.subtotal, d.recibo.desconto, d.recibo.total) == (Decimal("183.33"), Decimal("10.00"), Decimal("173.33"))
    assert d.recebido == Decimal("100.00") and d.pendente == Decimal("73.33")
    assert d.recibo.observacoes == "Obrigado!" and len(d.recibo.itens) == 2 and len(d.pagamentos) == 1
    assert d.recibo.emitente_nome == "Emitente de Teste LTDA" and d.recibo.cliente_nome == "Cliente de Teste"


def test_numeracao_sequencial(ambiente):
    s = ambiente.servicos
    assert [s.recibos.emitir(novo(ambiente)).numero for _ in range(3)] == [1, 2, 3]


def test_validacoes_da_emissao_nao_gravam_nada(ambiente):
    s = ambiente.servicos
    casos = [
        (dict(itens=[]), "pelo menos um serviço"),
        (dict(itens=[item(valor="0")]), "valor unitário"),
        (dict(itens=[item(qtd="0")]), "quantidade"),
        (dict(desconto=Decimal("-5")), "negativo"),
        (dict(desconto=Decimal("999")), "maior que o subtotal"),
        (dict(desconto=Decimal("100")), "maior que zero"),
        (dict(data_emissao=HOJE + timedelta(days=1)), "futura"),
        (dict(observacoes="x" * 1001), "1000"),
        (dict(cliente_id=999999999), "cliente cadastrado"),
        (dict(pagamento=NovoPagamento(forma_pagamento_id=1, valor=Decimal("500"), data_pagamento=HOJE)), "pendente"),
        (dict(pagamento=NovoPagamento(forma_pagamento_id=999999, valor=Decimal("10"), data_pagamento=HOJE)), "Forma de pagamento"),
    ]
    for extras, trecho in casos:
        with pytest.raises(ValidacaoError, match=trecho):
            s.recibos.emitir(novo(ambiente, **extras))
    assert s.recibos.pesquisar(FiltroRecibos(cliente_id=ambiente.cliente.id)).total == 0
    assert s.recibos.emitir(novo(ambiente)).numero == 1  # nenhuma falha consumiu número


def test_emissao_retroativa_usa_o_ano_da_data(ambiente):
    s = ambiente.servicos
    r = s.recibos.emitir(novo(ambiente, data_emissao=date(2025, 12, 30)))
    assert r.numero_formatado == "2025/000001"


def test_editar_cliente_depois_nao_muda_o_recibo(ambiente):
    s = ambiente.servicos
    recibo = s.recibos.emitir(novo(ambiente))
    cliente = s.clientes.obter(ambiente.cliente.id)
    cliente.nome, cliente.logradouro = "Nome Totalmente Novo", "Avenida Nova"
    s.clientes.atualizar(cliente)
    s.clientes.desativar(cliente.id)
    lido = s.recibos.obter_detalhes(recibo.id).recibo
    assert lido.cliente_nome == "Cliente de Teste" and "Rua Teste" in lido.cliente_endereco


def test_pagamentos_parciais_e_limite_do_pendente(ambiente):
    s = ambiente.servicos
    recibo = s.recibos.emitir(novo(ambiente))  # 100,00
    s.recibos.registrar_pagamento(recibo.id, NovoPagamento(forma_pagamento_id=id_forma(ambiente), valor=Decimal("60"), data_pagamento=HOJE))
    with pytest.raises(ValidacaoError, match="pendente"):
        s.recibos.registrar_pagamento(recibo.id, NovoPagamento(forma_pagamento_id=id_forma(ambiente), valor=Decimal("50"), data_pagamento=HOJE))
    s.recibos.registrar_pagamento(recibo.id, NovoPagamento(forma_pagamento_id=id_forma(ambiente, "Dinheiro"), valor=Decimal("40"), data_pagamento=HOJE))
    d = s.recibos.obter_detalhes(recibo.id)
    assert d.recebido == Decimal("100.00") and d.pendente == Decimal("0.00")
    with pytest.raises(ValidacaoError):  # nada pendente
        s.recibos.registrar_pagamento(recibo.id, NovoPagamento(forma_pagamento_id=id_forma(ambiente), valor=Decimal("1"), data_pagamento=HOJE))


def test_pagamento_com_data_futura_ou_valor_zero(ambiente):
    s = ambiente.servicos
    recibo = s.recibos.emitir(novo(ambiente))
    for valor, data, trecho in [(Decimal("10"), HOJE + timedelta(days=2), "futura"), (Decimal("0"), HOJE, "maior que zero")]:
        with pytest.raises(ValidacaoError, match=trecho):
            s.recibos.registrar_pagamento(recibo.id, NovoPagamento(forma_pagamento_id=id_forma(ambiente), valor=valor, data_pagamento=data))


def test_cancelamento(ambiente):
    s = ambiente.servicos
    recibo = s.recibos.emitir(novo(ambiente))
    with pytest.raises(ValidacaoError, match="motivo"):
        s.recibos.cancelar(recibo.id, "  ab ")
    s.recibos.cancelar(recibo.id, "Emitido por engano")
    d = s.recibos.obter_detalhes(recibo.id)
    assert d.recibo.cancelado and d.recibo.motivo_cancelamento == "Emitido por engano" and d.pendente == Decimal("0.00")
    with pytest.raises(RegraNegocioError, match="já está cancelado"):
        s.recibos.cancelar(recibo.id, "Outra vez")
    with pytest.raises(RegraNegocioError, match="cancelado"):
        s.recibos.registrar_pagamento(recibo.id, NovoPagamento(forma_pagamento_id=id_forma(ambiente), valor=Decimal("10"), data_pagamento=HOJE))
    assert s.recibos.emitir(novo(ambiente)).numero == 2  # o número cancelado não é reutilizado
    with pytest.raises(RegistroNaoEncontradoError):
        s.recibos.cancelar(999999999, "Motivo válido")


def test_pesquisa_e_paginacao(ambiente):
    s = ambiente.servicos
    for i in range(5):
        s.recibos.emitir(novo(ambiente, data_emissao=HOJE - timedelta(days=i)))
    filtro = FiltroRecibos(cliente_id=ambiente.cliente.id)
    p1 = s.recibos.pesquisar(filtro, pagina=1, por_pagina=2)
    p3 = s.recibos.pesquisar(filtro, pagina=3, por_pagina=2)
    assert (p1.total, p1.total_paginas, len(p1.itens), len(p3.itens)) == (5, 3, 2, 1)
    assert [r.numero for r in p1.itens] == [1, 2]  # mais recentes primeiro (o nº 1 tem a data de hoje)
    assert s.recibos.pesquisar(FiltroRecibos(cliente_id=ambiente.cliente.id, numero=3, ano=HOJE.year)).itens[0].numero == 3


def test_historico_de_auditoria_do_recibo(ambiente):
    s = ambiente.servicos
    recibo = s.recibos.emitir(novo(ambiente))
    s.recibos.registrar_pagamento(recibo.id, NovoPagamento(forma_pagamento_id=id_forma(ambiente), valor=Decimal("10"), data_pagamento=HOJE))
    s.recibos.cancelar(recibo.id, "Cancelado em teste")
    operacoes = [h["operacao"] for h in s.recibos.historico_do_recibo(recibo.id)]
    assert operacoes == ["CANCELAMENTO", "PAGAMENTO", "EMISSAO"]


def test_dashboard(ambiente):
    s = ambiente.servicos
    antes = s.dashboard.carregar()
    s.recibos.emitir(novo(ambiente))  # 100,00 hoje
    cancelado = s.recibos.emitir(novo(ambiente))
    s.recibos.cancelar(cancelado.id, "Cancelado em teste")
    depois = s.dashboard.carregar()
    assert depois.total_recibos - antes.total_recibos == 1
    assert depois.valor_emitido - antes.valor_emitido == Decimal("100.00")
    assert depois.valor_pendente - antes.valor_pendente == Decimal("100.00")
    assert depois.recibos_cancelados - antes.recibos_cancelados == 1
    assert len(depois.por_mes) == 6 and depois.por_mes[-1][0] == f"{HOJE.year}-{HOJE.month:02d}"
    assert depois.ultimos[0].cliente_nome == "Cliente de Teste"


def test_emissoes_simultaneas_pelo_servico(ambiente):
    """10 emissões em paralelo: números 1..10, sem repetição e sem falhas."""
    s = ambiente.servicos
    erros: list[Exception] = []

    def emitir() -> None:
        try:
            s.recibos.emitir(novo(ambiente))
        except Exception as exc:  # noqa: BLE001 - o teste precisa registrar qualquer falha
            erros.append(exc)

    threads = [threading.Thread(target=emitir) for _ in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert not erros, erros
    numeros = sorted(r.numero for r in s.recibos.pesquisar(FiltroRecibos(cliente_id=ambiente.cliente.id), por_pagina=50).itens)
    assert numeros == list(range(1, 11))


# ------------------------------------------------------------ configurações
def test_formas_de_pagamento(ambiente):
    c = ambiente.servicos.configuracoes
    with pytest.raises(ValidacaoError):
        c.cadastrar_forma(" a ")
    with pytest.raises(Exception, match="descrição"):
        c.cadastrar_forma("PIX")  # duplicada
    nome = f"Forma {gerar_cpf()}"
    forma = c.cadastrar_forma(nome)
    try:
        c.alterar_situacao_forma(forma.id, False)
        assert forma.id not in [f.id for f in c.listar_formas(True)]
        c.alterar_situacao_forma(forma.id, True)
        assert forma.id in [f.id for f in c.listar_formas(True)]
    finally:
        with ambiente.servicos.db.transaction() as cur:
            cur.execute("DELETE FROM historico_operacoes WHERE entidade = 'forma_pagamento' AND entidade_id = %s", (forma.id,))
            cur.execute("DELETE FROM formas_pagamento WHERE id = %s", (forma.id,))


def test_salvar_configuracoes_valida_pasta_e_rodape(ambiente, tmp_path):
    c = ambiente.servicos.configuracoes
    original = (c.rodape_recibo(), c.pasta_pdf_texto())
    with ambiente.servicos.db.cursor() as cur:
        cur.execute("SELECT COALESCE(MAX(id), 0) AS ultimo FROM historico_operacoes")
        ultimo_id = cur.fetchone()["ultimo"]
    try:
        with pytest.raises(ValidacaoError):
            c.salvar("x" * 301, "")
        c.salvar("Rodapé de teste", str(tmp_path / "pdfs"))
        assert c.rodape_recibo() == "Rodapé de teste" and c.pasta_pdf() == tmp_path / "pdfs" and (tmp_path / "pdfs").is_dir()
    finally:
        c.salvar(*original)
        with ambiente.servicos.db.transaction() as cur:  # remove a auditoria criada por este teste
            cur.execute("DELETE FROM historico_operacoes WHERE entidade = 'configuracao' AND id > %s", (ultimo_id,))
