"""Fixtures e auxiliares compartilhados pelos testes (exigem o banco criado pelo setup_db.py)."""

from __future__ import annotations

import random
import uuid
from dataclasses import dataclass, field

import pytest

from app.bootstrap import Servicos, criar_servicos
from app.core.connection import Database
from app.models.cliente import Cliente
from app.models.emitente import Emitente


def documento_unico(tamanho: int) -> str:
    """Documento numérico único, apenas para testes de estrutura (não é CPF/CNPJ válido)."""
    return str(uuid.uuid4().int)[:tamanho].zfill(tamanho)


def gerar_cpf() -> str:
    """CPF válido e aleatório (somente dígitos)."""
    base = [random.randint(0, 9) for _ in range(9)]
    while len(set(base)) == 1:
        base = [random.randint(0, 9) for _ in range(9)]
    digitos = list(base)
    for tamanho in (9, 10):
        soma = sum(digitos[i] * (tamanho + 1 - i) for i in range(tamanho))
        digitos.append((soma * 10 % 11) % 10)
    return "".join(map(str, digitos))


def gerar_cnpj() -> str:
    """CNPJ válido e aleatório (somente dígitos)."""
    base = [random.randint(0, 9) for _ in range(8)] + [0, 0, 0, 1]
    digitos = list(base)
    for pesos in ([5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2], [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]):
        soma = sum(d * p for d, p in zip(digitos, pesos))
        resto = soma % 11
        digitos.append(0 if resto < 2 else 11 - resto)
    return "".join(map(str, digitos))


@pytest.fixture(scope="session")
def db() -> Database:
    return Database()


@pytest.fixture()
def cur(db):
    """Cursor dentro de uma transação que é DESFEITA no final: nada fica gravado."""
    conexao = db.conectar()
    cursor = conexao.cursor()
    yield cursor
    cursor.close()
    conexao.rollback()
    conexao.close()


@dataclass
class Ambiente:
    """Emitente e cliente exclusivos de um teste, com limpeza completa ao final."""

    servicos: Servicos
    emitente: Emitente
    cliente: Cliente
    ids_extras: dict[str, list[int]] = field(default_factory=dict)


@pytest.fixture()
def ambiente(db):
    """Cria emitente e cliente próprios (não toca no emitente real) e remove tudo no final."""
    servicos = criar_servicos(db)
    emitente = servicos.emitentes.salvar(
        Emitente(nome="Emitente de Teste LTDA", tipo_pessoa="J", documento=gerar_cnpj(), cidade="Bebedouro", uf="SP")
    )
    cliente = servicos.clientes.cadastrar(
        Cliente(nome="Cliente de Teste", tipo_pessoa="F", documento=gerar_cpf(), logradouro="Rua Teste", numero="10")
    )
    ambiente = Ambiente(servicos=servicos, emitente=emitente, cliente=cliente)
    yield ambiente

    with db.transaction() as cur:
        cur.execute("SELECT id FROM recibos WHERE emitente_id = %s", (emitente.id,))
        recibos = [linha["id"] for linha in cur.fetchall()]
        for recibo_id in recibos:
            cur.execute("DELETE FROM pagamentos WHERE recibo_id = %s", (recibo_id,))
            cur.execute("DELETE FROM historico_operacoes WHERE entidade = 'recibo' AND entidade_id = %s", (recibo_id,))
        cur.execute("DELETE FROM recibos WHERE emitente_id = %s", (emitente.id,))
        cur.execute("DELETE FROM contadores_recibo WHERE emitente_id = %s", (emitente.id,))
        for entidade, ids in (("cliente", [cliente.id, *ambiente.ids_extras.get("cliente", [])]), ("emitente", [emitente.id])):
            for entidade_id in ids:
                cur.execute("DELETE FROM historico_operacoes WHERE entidade = %s AND entidade_id = %s", (entidade, entidade_id))
        for cliente_id in [cliente.id, *ambiente.ids_extras.get("cliente", [])]:
            cur.execute("DELETE FROM clientes WHERE id = %s", (cliente_id,))
        cur.execute("DELETE FROM emitentes WHERE id = %s", (emitente.id,))
