"""Testes dos repositórios (Etapa 2). Usam transações desfeitas, exceto o teste de concorrência."""

from __future__ import annotations

import threading
from datetime import date
from decimal import Decimal

import pytest

from app.core.connection import Database
from app.models.cliente import Cliente
from app.models.emitente import Emitente
from app.models.filtros import FiltroRecibos
from app.models.forma_pagamento import FormaPagamento
from app.models.recibo import ItemRecibo, Pagamento, Recibo
from app.repositories.cliente_repository import ClienteRepository
from app.repositories.configuracao_repository import ConfiguracaoRepository
from app.repositories.emitente_repository import EmitenteRepository
from app.repositories.forma_pagamento_repository import FormaPagamentoRepository
from app.repositories.historico_repository import HistoricoRepository
from app.repositories.pagamento_repository import PagamentoRepository
from app.repositories.recibo_repository import ReciboRepository
from app.repositories.relatorio_repository import RelatorioRepository
from tests.conftest import documento_unico

clientes = ClienteRepository()
emitentes = EmitenteRepository()
recibos = ReciboRepository()
pagamentos = PagamentoRepository()
formas = FormaPagamentoRepository()
historico = HistoricoRepository()
configuracoes = ConfiguracaoRepository()
relatorios = RelatorioRepository()


# --------------------------------------------------------------------------
# Auxiliares
# --------------------------------------------------------------------------
def novo_cliente(cur, nome="Cliente Teste", **extras) -> Cliente:
    cliente = Cliente(nome=nome, tipo_pessoa="F", documento=documento_unico(11), **extras)
    clientes.inserir(cur, cliente)
    return cliente


def novo_emitente(cur) -> Emitente:
    emitente = Emitente(nome="Emitente Teste", tipo_pessoa="J", documento=documento_unico(14))
    emitentes.inserir(cur, emitente)
    return emitente


def emitir(cur, emitente: Emitente, cliente: Cliente, itens=None, desconto="0", data=None, ano=2026) -> Recibo:
    """Reproduz o fluxo de emissão que o serviço fará na Etapa 4."""
    recibo = Recibo(
        emitente_id=emitente.id,
        cliente_id=cliente.id,
        data_emissao=data or date(2026, 3, 10),
        ano=ano,
        desconto=Decimal(desconto),
        itens=itens or [ItemRecibo(descricao="Serviço", quantidade=Decimal("2"), valor_unitario=Decimal("50"))],
        cliente_nome=cliente.nome,
        cliente_tipo_pessoa=cliente.tipo_pessoa,
        cliente_documento=cliente.documento,
        cliente_endereco=cliente.endereco_formatado,
        emitente_nome=emitente.nome,
        emitente_tipo_pessoa=emitente.tipo_pessoa,
        emitente_documento=emitente.documento,
    )
    recibo.recalcular_totais()
    recibo.numero = recibos.proximo_numero(cur, emitente.id, ano)
    recibos.inserir(cur, recibo)
    recibos.inserir_itens(cur, recibo.id, recibo.itens)
    return recibo


# --------------------------------------------------------------------------
# Clientes
# --------------------------------------------------------------------------
def test_cliente_inserir_obter_atualizar(cur):
    cliente = novo_cliente(cur, telefone="17999990000", logradouro="Rua A", numero="10", cidade="Bebedouro", uf="SP")
    lido = clientes.obter(cur, cliente.id)
    assert lido.nome == "Cliente Teste" and lido.ativo is True
    assert lido.endereco_formatado == "Rua A, 10 - Bebedouro/SP"
    assert lido.criado_em is not None

    lido.nome = "Nome Alterado"
    lido.email = ""  # vazio vira NULL
    assert clientes.atualizar(cur, lido) is True
    assert clientes.obter(cur, cliente.id).nome == "Nome Alterado"
    assert clientes.obter(cur, cliente.id).email is None


def test_cliente_atualizar_com_dados_iguais_continua_encontrado(cur):
    cliente = novo_cliente(cur)
    assert clientes.atualizar(cur, clientes.obter(cur, cliente.id)) is True  # nada mudou, mas existe


def test_cliente_inexistente(cur):
    assert clientes.obter(cur, 999999999) is None
    assert clientes.definir_ativo(cur, 999999999, False) is False


def test_cliente_desativar_e_filtrar(cur):
    cliente = novo_cliente(cur, nome="Zé Filtro Ativo")
    assert clientes.definir_ativo(cur, cliente.id, False) is True
    assert clientes.obter(cur, cliente.id).ativo is False

    ativos = clientes.pesquisar(cur, "Zé Filtro", ativo=True)
    inativos = clientes.pesquisar(cur, "Zé Filtro", ativo=False)
    assert cliente.id not in [c.id for c in ativos]
    assert cliente.id in [c.id for c in inativos]


def test_cliente_pesquisa_por_nome_e_documento(cur):
    cliente = novo_cliente(cur, nome="Maria Pesquisável Xyz")
    assert cliente.id in [c.id for c in clientes.pesquisar(cur, "pesquisável xyz")]  # sem diferenciar maiúsculas
    parte_doc = cliente.documento[2:9]
    assert cliente.id in [c.id for c in clientes.pesquisar(cur, parte_doc)]
    mascarado = f"{cliente.documento[:3]}.{cliente.documento[3:6]}"  # com pontuação digitada
    assert cliente.id in [c.id for c in clientes.pesquisar(cur, mascarado)]
    assert clientes.contar(cur, "pesquisável xyz") == 1


def test_pesquisa_trata_curingas_como_texto(cur):
    com = novo_cliente(cur, nome="Desconto 50% Curinga")
    sem = novo_cliente(cur, nome="Desconto 500 Curinga")
    ids = [c.id for c in clientes.pesquisar(cur, "50% Curinga")]
    assert com.id in ids and sem.id not in ids


def test_pesquisa_com_aspas_nao_quebra_sql(cur):
    novo_cliente(cur, nome="O'Brien Aspas")
    assert len(clientes.pesquisar(cur, "O'Brien")) == 1
    assert clientes.pesquisar(cur, "'; DROP TABLE clientes; --") == []
    assert clientes.contar(cur) >= 1  # a tabela continua existindo


def test_cliente_paginacao(cur):
    for i in range(5):
        novo_cliente(cur, nome=f"Paginado {i}")
    primeira = clientes.pesquisar(cur, "Paginado", limite=3, deslocamento=0)
    segunda = clientes.pesquisar(cur, "Paginado", limite=3, deslocamento=3)
    assert [c.nome for c in primeira] == ["Paginado 0", "Paginado 1", "Paginado 2"]
    assert [c.nome for c in segunda] == ["Paginado 3", "Paginado 4"]


# --------------------------------------------------------------------------
# Emitente, formas de pagamento, configurações, histórico
# --------------------------------------------------------------------------
def test_emitente_padrao_existe_no_seed(cur):
    assert emitentes.obter_padrao(cur) is not None


def test_formas_de_pagamento(cur):
    descricoes = [f.descricao for f in formas.listar(cur)]
    assert "PIX" in descricoes and "Dinheiro" in descricoes
    nova = FormaPagamento(descricao=f"Forma {documento_unico(8)}")
    formas.inserir(cur, nova)
    formas.definir_ativo(cur, nova.id, False)
    assert nova.id not in [f.id for f in formas.listar(cur, somente_ativas=True)]
    assert nova.id in [f.id for f in formas.listar(cur, somente_ativas=False)]


def test_configuracoes_upsert(cur):
    chave = f"teste_{documento_unico(10)}"
    assert configuracoes.obter(cur, chave, "padrao") == "padrao"
    configuracoes.definir(cur, chave, "um", "descrição original")
    configuracoes.definir(cur, chave, "dois")  # mantém a descrição
    assert configuracoes.obter(cur, chave) == "dois"
    cur.execute("SELECT descricao FROM configuracoes WHERE chave = %s", (chave,))
    assert cur.fetchone()["descricao"] == "descrição original"


def test_historico_registra_json_utf8(cur):
    cliente = novo_cliente(cur)
    historico.registrar(
        cur, "cliente", cliente.id, "ALTERACAO", "Nome alterado",
        dados_anteriores={"nome": "José"}, dados_novos={"nome": "João", "criado": date(2026, 1, 2)},
    )
    linhas = historico.listar_por_entidade(cur, "cliente", cliente.id)
    assert len(linhas) == 1
    assert '"nome": "José"' in linhas[0]["dados_anteriores"]  # acentos preservados
    assert "2026-01-02" in linhas[0]["dados_novos"]


# --------------------------------------------------------------------------
# Recibos
# --------------------------------------------------------------------------
def test_numeracao_sequencial_por_emitente_e_ano(cur):
    a, b = novo_emitente(cur), novo_emitente(cur)
    assert [recibos.proximo_numero(cur, a.id, 2026) for _ in range(3)] == [1, 2, 3]
    assert recibos.proximo_numero(cur, a.id, 2027) == 1  # novo ano reinicia
    assert recibos.proximo_numero(cur, b.id, 2026) == 1  # outro emitente tem sequência própria


def test_emitir_e_consultar_recibo_completo(cur):
    emitente, cliente = novo_emitente(cur), novo_cliente(cur, logradouro="Rua B", numero="5")
    itens = [
        ItemRecibo(descricao="Consultoria", quantidade=Decimal("1.5"), valor_unitario=Decimal("100.00")),
        ItemRecibo(descricao="Deslocamento", quantidade=Decimal("1"), valor_unitario=Decimal("33.33")),
    ]
    recibo = emitir(cur, emitente, cliente, itens=itens, desconto="10.00")

    lido = recibos.obter_com_itens(cur, recibo.id)
    assert lido.numero == 1 and lido.numero_formatado == "2026/000001"
    assert lido.subtotal == Decimal("183.33") and lido.desconto == Decimal("10.00")
    assert lido.total == Decimal("173.33")
    assert isinstance(lido.total, Decimal)
    assert [i.descricao for i in lido.itens] == ["Consultoria", "Deslocamento"]
    assert [i.ordem for i in lido.itens] == [1, 2]
    assert lido.itens[0].quantidade == Decimal("1.500") and lido.itens[0].subtotal == Decimal("150.00")
    assert recibos.obter_por_numero(cur, emitente.id, 2026, 1).id == recibo.id


def test_editar_cliente_nao_altera_recibo_emitido(cur):
    emitente, cliente = novo_emitente(cur), novo_cliente(cur, nome="Nome Original", logradouro="Rua Velha", numero="1")
    recibo = emitir(cur, emitente, cliente)

    cliente = clientes.obter(cur, cliente.id)
    cliente.nome, cliente.logradouro = "Nome Novo", "Rua Nova"
    clientes.atualizar(cur, cliente)
    clientes.definir_ativo(cur, cliente.id, False)

    lido = recibos.obter(cur, recibo.id)
    assert lido.cliente_nome == "Nome Original"
    assert "Rua Velha" in lido.cliente_endereco and "Rua Nova" not in lido.cliente_endereco
    assert lido.cliente_id == cliente.id  # o vínculo para relatórios continua


def test_cancelar_recibo(cur):
    emitente, cliente = novo_emitente(cur), novo_cliente(cur)
    recibo = emitir(cur, emitente, cliente)
    assert recibos.cancelar(cur, recibo.id, "Emitido por engano") is True
    assert recibos.cancelar(cur, recibo.id, "Outra vez") is False  # já cancelado
    lido = recibos.obter(cur, recibo.id)
    assert lido.cancelado and lido.motivo_cancelamento == "Emitido por engano"
    assert lido.cancelado_em is not None
    assert recibos.cancelar(cur, 999999999, "x") is False


def test_pesquisa_de_recibos_por_numero_cliente_e_periodo(cur):
    emitente = novo_emitente(cur)
    ana = novo_cliente(cur, nome="Ana Histórico Zz")
    bia = novo_cliente(cur, nome="Bia Histórico Zz")
    r1 = emitir(cur, emitente, ana, data=date(2026, 1, 15))
    r2 = emitir(cur, emitente, bia, data=date(2026, 2, 20))
    r3 = emitir(cur, emitente, ana, data=date(2026, 3, 25))
    recibos.cancelar(cur, r3.id, "teste")

    por_cliente = recibos.pesquisar(cur, FiltroRecibos(cliente="Histórico Zz"))
    assert [r.id for r in por_cliente] == [r3.id, r2.id, r1.id]  # mais recentes primeiro

    por_nome = recibos.pesquisar(cur, FiltroRecibos(cliente="ana histórico"))
    assert {r.id for r in por_nome} == {r1.id, r3.id}

    por_doc = recibos.pesquisar(cur, FiltroRecibos(cliente=ana.documento[:8]))
    assert {r.id for r in por_doc} == {r1.id, r3.id}

    periodo = FiltroRecibos(cliente="Histórico Zz", data_inicio=date(2026, 2, 1), data_fim=date(2026, 3, 31))
    assert {r.id for r in recibos.pesquisar(cur, periodo)} == {r2.id, r3.id}

    por_numero = recibos.pesquisar(cur, FiltroRecibos(numero=2, ano=2026, cliente_id=bia.id))
    assert [r.id for r in por_numero] == [r2.id]

    cancelados = recibos.pesquisar(cur, FiltroRecibos(cliente="Histórico Zz", situacao="CANCELADO"))
    assert [r.id for r in cancelados] == [r3.id]
    assert recibos.contar(cur, FiltroRecibos(cliente="Histórico Zz")) == 3
    assert recibos.pesquisar(cur, FiltroRecibos(cliente="Histórico Zz"), limite=2, deslocamento=2)[0].id == r1.id


def test_pagamentos_recebido_e_pendente(cur):
    emitente, cliente = novo_emitente(cur), novo_cliente(cur)
    recibo = emitir(cur, emitente, cliente)  # total 100,00
    pix = next(f for f in formas.listar(cur) if f.descricao == "PIX")
    dinheiro = next(f for f in formas.listar(cur) if f.descricao == "Dinheiro")
    pagamentos.inserir(cur, Pagamento(recibo_id=recibo.id, forma_pagamento_id=pix.id,
                                      valor=Decimal("30.00"), data_pagamento=date(2026, 3, 11)))
    pagamentos.inserir(cur, Pagamento(recibo_id=recibo.id, forma_pagamento_id=dinheiro.id,
                                      valor=Decimal("20.50"), data_pagamento=date(2026, 3, 12), observacoes="troco"))
    assert pagamentos.total_recebido(cur, recibo.id) == Decimal("50.50")
    lista = pagamentos.listar_por_recibo(cur, recibo.id)
    assert [p.forma_descricao for p in lista] == ["PIX", "Dinheiro"]

    resumo = recibos.pesquisar(cur, FiltroRecibos(cliente_id=cliente.id))[0]
    assert resumo.recebido == Decimal("50.50") and resumo.pendente == Decimal("49.50")


def test_ultimos_recibos_ignora_cancelados(cur):
    emitente, cliente = novo_emitente(cur), novo_cliente(cur)
    r1 = emitir(cur, emitente, cliente)
    r2 = emitir(cur, emitente, cliente)
    recibos.cancelar(cur, r2.id, "x")
    ids = [r.id for r in recibos.ultimos(cur, limite=50)]
    assert r1.id in ids and r2.id not in ids


# --------------------------------------------------------------------------
# Relatórios e dashboard
# --------------------------------------------------------------------------
def test_dashboard_e_relatorios(cur):
    hoje = date(2026, 3, 20)
    antes = relatorios.resumo_dashboard(cur, hoje)

    emitente, cliente = novo_emitente(cur), novo_cliente(cur, nome="Cliente Relatório Qq")
    emitir(cur, emitente, cliente, data=date(2026, 3, 5))        # 100,00 no mês
    emitir(cur, emitente, cliente, data=date(2026, 2, 5))        # 100,00 mês anterior
    cancelado = emitir(cur, emitente, cliente, data=date(2026, 3, 6))
    recibos.cancelar(cur, cancelado.id, "x")

    depois = relatorios.resumo_dashboard(cur, hoje)
    assert depois["total_recibos"] - antes["total_recibos"] == 2
    assert depois["valor_emitido"] - antes["valor_emitido"] == Decimal("200.00")
    assert depois["recibos_mes"] - antes["recibos_mes"] == 1
    assert depois["valor_mes"] - antes["valor_mes"] == Decimal("100.00")
    assert depois["recibos_cancelados"] - antes["recibos_cancelados"] == 1
    assert depois["valor_pendente"] - antes["valor_pendente"] == Decimal("200.00")

    lista = relatorios.clientes_com_total_recibos(cur, "Relatório Qq")
    assert len(lista) == 1
    assert lista[0]["qtd_recibos"] == 3 and lista[0]["total_emitido"] == Decimal("200.00")

    por_cliente = relatorios.total_por_cliente(cur, date(2026, 1, 1), date(2026, 12, 31))
    linha = next(x for x in por_cliente if x["cliente_id"] == cliente.id)
    assert linha["quantidade"] == 2 and linha["total_emitido"] == Decimal("200.00")

    meses = {m["mes"] for m in relatorios.total_por_mes(cur, 2026)}
    assert {"2026-02", "2026-03"} <= meses
    assert cancelado.id in [c["id"] for c in relatorios.recibos_cancelados(cur)]


def test_total_por_forma_de_pagamento(cur):
    emitente, cliente = novo_emitente(cur), novo_cliente(cur)
    recibo = emitir(cur, emitente, cliente, data=date(2031, 6, 1))
    pix = next(f for f in formas.listar(cur) if f.descricao == "PIX")
    pagamentos.inserir(cur, Pagamento(recibo_id=recibo.id, forma_pagamento_id=pix.id,
                                      valor=Decimal("40.00"), data_pagamento=date(2031, 6, 2)))
    linhas = relatorios.total_por_forma_pagamento(cur, date(2031, 6, 1), date(2031, 6, 30))
    assert linhas == [{"forma_pagamento": "PIX", "quantidade": 1, "total_recebido": Decimal("40.00")}]


# --------------------------------------------------------------------------
# Concorrência (precisa de COMMIT real; limpa os dados no final)
# --------------------------------------------------------------------------
def test_emissoes_simultaneas_geram_numeros_unicos_e_sequenciais():
    db = Database()
    with db.transaction() as cur:
        emitente, cliente = novo_emitente(cur), novo_cliente(cur)

    erros: list[Exception] = []

    def emitir_em_thread() -> None:
        try:
            with db.transaction() as cur:
                emitir(cur, emitente, cliente)
        except Exception as exc:  # noqa: BLE001 - o teste precisa registrar qualquer falha
            erros.append(exc)

    threads = [threading.Thread(target=emitir_em_thread) for _ in range(20)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    try:
        assert not erros, erros
        with db.cursor() as cur:
            cur.execute("SELECT numero FROM recibos WHERE emitente_id = %s ORDER BY numero", (emitente.id,))
            assert [linha["numero"] for linha in cur.fetchall()] == list(range(1, 21))
    finally:
        with db.transaction() as cur:
            cur.execute("DELETE FROM recibos WHERE emitente_id = %s", (emitente.id,))
            cur.execute("DELETE FROM contadores_recibo WHERE emitente_id = %s", (emitente.id,))
            cur.execute("DELETE FROM clientes WHERE id = %s", (cliente.id,))
            cur.execute("DELETE FROM emitentes WHERE id = %s", (emitente.id,))


def test_falha_na_emissao_desfaz_contador_e_recibo():
    """Erro no meio da emissão: ROLLBACK desfaz tudo e o número é reaproveitado."""
    db = Database()
    with db.transaction() as cur:
        emitente, cliente = novo_emitente(cur), novo_cliente(cur)
    try:
        with pytest.raises(Exception):
            with db.transaction() as cur:
                emitir(cur, emitente, cliente)
                raise RuntimeError("falha depois de gravar")
        with db.transaction() as cur:
            assert emitir(cur, emitente, cliente).numero == 1  # sem buraco na sequência
    finally:
        with db.transaction() as cur:
            cur.execute("DELETE FROM recibos WHERE emitente_id = %s", (emitente.id,))
            cur.execute("DELETE FROM contadores_recibo WHERE emitente_id = %s", (emitente.id,))
            cur.execute("DELETE FROM clientes WHERE id = %s", (cliente.id,))
            cur.execute("DELETE FROM emitentes WHERE id = %s", (emitente.id,))
