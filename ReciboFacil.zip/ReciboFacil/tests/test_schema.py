"""Testes do banco de dados do ReciboFácil (Etapa 1).

Exigem o banco criado com `python database/setup_db.py`.
Executar:  pytest tests/test_schema.py -v
"""

from __future__ import annotations

import threading
import uuid
from decimal import Decimal

import pymysql
import pytest

from app.config.settings import load_database_settings

CFG = load_database_settings()

# Violação de UNIQUE/FOREIGN KEY -> IntegrityError; violação de CHECK no MariaDB -> OperationalError (4025).
ERRO_RESTRICAO = (pymysql.err.IntegrityError, pymysql.err.OperationalError)


def _conectar(autocommit: bool = False) -> pymysql.connections.Connection:
    return pymysql.connect(
        host=CFG.host,
        port=CFG.port,
        user=CFG.user,
        password=CFG.password,
        database=CFG.name,
        charset="utf8mb4",
        autocommit=autocommit,
    )


@pytest.fixture()
def conexao():
    """Conexão sem autocommit; tudo o que o teste fizer é desfeito no final."""
    con = _conectar()
    yield con
    con.rollback()
    con.close()


def _doc_unico(tamanho: int) -> str:
    """Gera um documento numérico único (apenas para testes de estrutura)."""
    return str(uuid.uuid4().int)[:tamanho].zfill(tamanho)


def _criar_emitente_cliente(cur) -> tuple[int, int]:
    cur.execute(
        "INSERT INTO emitentes (nome, tipo_pessoa, documento) VALUES (%s, 'J', %s)",
        ("Emitente Teste", _doc_unico(14)),
    )
    emitente_id = cur.lastrowid
    cur.execute(
        "INSERT INTO clientes (nome, tipo_pessoa, documento) VALUES (%s, 'F', %s)",
        ("Cliente Teste", _doc_unico(11)),
    )
    return emitente_id, cur.lastrowid


_SQL_RECIBO = """
    INSERT INTO recibos
        (emitente_id, ano, numero, cliente_id, data_emissao, subtotal, desconto, total,
         cliente_nome, cliente_tipo_pessoa, cliente_documento,
         emitente_nome, emitente_tipo_pessoa, emitente_documento)
    VALUES (%s, 2026, %s, %s, '2026-01-10', %s, %s, %s,
            'Cliente Teste', 'F', '00000000000', 'Emitente Teste', 'J', '00000000000000')
"""


def test_todas_as_tabelas_sao_innodb_utf8mb4(conexao):
    with conexao.cursor() as cur:
        cur.execute(
            "SELECT TABLE_NAME, ENGINE, TABLE_COLLATION FROM information_schema.TABLES "
            "WHERE TABLE_SCHEMA = %s AND TABLE_TYPE = 'BASE TABLE'",
            (CFG.name,),
        )
        linhas = cur.fetchall()
    assert len(linhas) == 9
    for nome, engine, collation in linhas:
        assert engine == "InnoDB", nome
        assert collation.startswith("utf8mb4"), nome


def test_valores_monetarios_sao_decimal(conexao):
    with conexao.cursor() as cur:
        cur.execute(
            "SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE FROM information_schema.COLUMNS "
            "WHERE TABLE_SCHEMA = %s AND TABLE_NAME IN ('recibos','itens_recibo','pagamentos') "
            "AND COLUMN_NAME IN ('subtotal','desconto','total','valor','valor_unitario','quantidade')",
            (CFG.name,),
        )
        linhas = cur.fetchall()
        assert len(linhas) == 7  # 3 em recibos + 3 em itens_recibo + 1 em pagamentos
        for tabela, coluna, tipo in linhas:
            assert tipo == "decimal", f"{tabela}.{coluna} é {tipo}"


def test_seed_carregado(conexao):
    with conexao.cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM formas_pagamento")
        assert cur.fetchone()[0] >= 7
        cur.execute("SELECT COUNT(*) FROM emitentes")
        assert cur.fetchone()[0] >= 1


def test_recibo_valido_e_view_de_resumo(conexao):
    with conexao.cursor() as cur:
        emitente, cliente = _criar_emitente_cliente(cur)
        cur.execute(_SQL_RECIBO, (emitente, 1, cliente, "100.00", "10.00", "90.00"))
        recibo = cur.lastrowid
        cur.execute(
            "INSERT INTO itens_recibo (recibo_id, ordem, descricao, quantidade, valor_unitario, subtotal) "
            "VALUES (%s, 1, 'Serviço', 2.000, 50.00, 100.00)",
            (recibo,),
        )
        cur.execute("SELECT id FROM formas_pagamento LIMIT 1")
        forma = cur.fetchone()[0]
        cur.execute(
            "INSERT INTO pagamentos (recibo_id, forma_pagamento_id, valor, data_pagamento) "
            "VALUES (%s, %s, 30.00, '2026-01-11')",
            (recibo, forma),
        )
        cur.execute("SELECT recebido, pendente, numero_formatado FROM vw_recibos_resumo WHERE id = %s", (recibo,))
        recebido, pendente, formatado = cur.fetchone()
    assert recebido == Decimal("30.00")
    assert pendente == Decimal("60.00")
    assert formatado == "2026/000001"


@pytest.mark.parametrize(
    "subtotal, desconto, total",
    [
        ("-1.00", "0.00", "-1.00"),   # valor negativo
        ("100.00", "150.00", "-50.00"),  # desconto maior que o subtotal
        ("100.00", "10.00", "100.00"),   # total inconsistente
    ],
)
def test_recibo_com_valores_invalidos_e_rejeitado(conexao, subtotal, desconto, total):
    with conexao.cursor() as cur:
        emitente, cliente = _criar_emitente_cliente(cur)
        with pytest.raises(ERRO_RESTRICAO):
            cur.execute(_SQL_RECIBO, (emitente, 1, cliente, subtotal, desconto, total))


def test_numero_de_recibo_duplicado_e_rejeitado(conexao):
    with conexao.cursor() as cur:
        emitente, cliente = _criar_emitente_cliente(cur)
        cur.execute(_SQL_RECIBO, (emitente, 1, cliente, "10.00", "0.00", "10.00"))
        with pytest.raises(pymysql.err.IntegrityError):
            cur.execute(_SQL_RECIBO, (emitente, 1, cliente, "20.00", "0.00", "20.00"))


def test_item_com_quantidade_zero_e_rejeitado(conexao):
    with conexao.cursor() as cur:
        emitente, cliente = _criar_emitente_cliente(cur)
        cur.execute(_SQL_RECIBO, (emitente, 1, cliente, "10.00", "0.00", "10.00"))
        recibo = cur.lastrowid
        with pytest.raises(ERRO_RESTRICAO):
            cur.execute(
                "INSERT INTO itens_recibo (recibo_id, ordem, descricao, quantidade, valor_unitario, subtotal) "
                "VALUES (%s, 1, 'X', 0, 10.00, 0.00)",
                (recibo,),
            )


def test_cliente_com_recibo_nao_pode_ser_apagado(conexao):
    with conexao.cursor() as cur:
        emitente, cliente = _criar_emitente_cliente(cur)
        cur.execute(_SQL_RECIBO, (emitente, 1, cliente, "10.00", "0.00", "10.00"))
        with pytest.raises(pymysql.err.IntegrityError):
            cur.execute("DELETE FROM clientes WHERE id = %s", (cliente,))


def test_documento_de_cliente_duplicado_e_rejeitado(conexao):
    with conexao.cursor() as cur:
        doc = _doc_unico(11)
        cur.execute("INSERT INTO clientes (nome, tipo_pessoa, documento) VALUES ('A', 'F', %s)", (doc,))
        with pytest.raises(pymysql.err.IntegrityError):
            cur.execute("INSERT INTO clientes (nome, tipo_pessoa, documento) VALUES ('B', 'F', %s)", (doc,))


def test_tamanho_do_documento_deve_combinar_com_o_tipo(conexao):
    with conexao.cursor() as cur:
        with pytest.raises(ERRO_RESTRICAO):
            cur.execute(
                "INSERT INTO clientes (nome, tipo_pessoa, documento) VALUES ('A', 'F', %s)",
                (_doc_unico(14),),
            )


def test_cancelamento_exige_data(conexao):
    with conexao.cursor() as cur:
        emitente, cliente = _criar_emitente_cliente(cur)
        cur.execute(_SQL_RECIBO, (emitente, 1, cliente, "10.00", "0.00", "10.00"))
        recibo = cur.lastrowid
        with pytest.raises(ERRO_RESTRICAO):
            cur.execute("UPDATE recibos SET situacao = 'CANCELADO' WHERE id = %s", (recibo,))


def test_rollback_desfaz_contador_e_recibo():
    """Se a emissão falhar, o contador volta atrás: não há buracos na numeração."""
    con = _conectar()
    try:
        with con.cursor() as cur:
            emitente, cliente = _criar_emitente_cliente(cur)
        con.commit()

        with con.cursor() as cur:
            cur.execute(
                "INSERT INTO contadores_recibo (emitente_id, ano, ultimo_numero) VALUES (%s, 2026, 1) "
                "ON DUPLICATE KEY UPDATE ultimo_numero = ultimo_numero + 1",
                (emitente,),
            )
        con.rollback()

        with con.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM contadores_recibo WHERE emitente_id = %s", (emitente,))
            assert cur.fetchone()[0] == 0
    finally:
        _limpar(con, emitente, cliente)
        con.close()


def _proximo_numero(cur, emitente_id: int, ano: int) -> int:
    """Padrão de numeração segura: cria a linha se preciso e trava com FOR UPDATE."""
    cur.execute(
        "INSERT INTO contadores_recibo (emitente_id, ano, ultimo_numero) VALUES (%s, %s, 0) "
        "ON DUPLICATE KEY UPDATE ultimo_numero = ultimo_numero",
        (emitente_id, ano),
    )
    cur.execute(
        "SELECT ultimo_numero FROM contadores_recibo WHERE emitente_id = %s AND ano = %s FOR UPDATE",
        (emitente_id, ano),
    )
    novo = cur.fetchone()[0] + 1
    cur.execute(
        "UPDATE contadores_recibo SET ultimo_numero = %s WHERE emitente_id = %s AND ano = %s",
        (novo, emitente_id, ano),
    )
    return novo


def _limpar(con, emitente_id: int, cliente_id: int) -> None:
    """Remove os dados criados pelos testes que precisaram de COMMIT."""
    with con.cursor() as cur:
        cur.execute("DELETE FROM recibos WHERE emitente_id = %s", (emitente_id,))
        cur.execute("DELETE FROM contadores_recibo WHERE emitente_id = %s", (emitente_id,))
        cur.execute("DELETE FROM clientes WHERE id = %s", (cliente_id,))
        cur.execute("DELETE FROM emitentes WHERE id = %s", (emitente_id,))
    con.commit()


def test_emissoes_simultaneas_nao_geram_numeros_duplicados():
    """20 emissões em paralelo devem produzir os números 1..20, sem repetição."""
    base = _conectar()
    with base.cursor() as cur:
        emitente, cliente = _criar_emitente_cliente(cur)
    base.commit()

    erros: list[Exception] = []

    def emitir() -> None:
        con = _conectar()
        try:
            with con.cursor() as cur:
                numero = _proximo_numero(cur, emitente, 2026)
                cur.execute(_SQL_RECIBO, (emitente, numero, cliente, "10.00", "0.00", "10.00"))
            con.commit()
        except Exception as exc:  # noqa: BLE001 - o teste precisa registrar qualquer falha
            con.rollback()
            erros.append(exc)
        finally:
            con.close()

    threads = [threading.Thread(target=emitir) for _ in range(20)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    try:
        assert not erros, erros
        with base.cursor() as cur:
            cur.execute("SELECT numero FROM recibos WHERE emitente_id = %s ORDER BY numero", (emitente,))
            numeros = [linha[0] for linha in cur.fetchall()]
        assert numeros == list(range(1, 21))
    finally:
        _limpar(base, emitente, cliente)
        base.close()
