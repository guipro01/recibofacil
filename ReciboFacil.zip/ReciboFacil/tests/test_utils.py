"""Testes das funções utilitárias (não precisam do banco)."""

from datetime import date
from decimal import Decimal

import pytest

from app.utils.dinheiro import arredondar, formatar_moeda, interpretar_valor
from app.utils.formatadores import (
    formatar_cpf_cnpj,
    formatar_data,
    formatar_numero_recibo,
    formatar_telefone,
    interpretar_data,
    interpretar_numero_recibo,
    somente_digitos,
)


@pytest.mark.parametrize(
    "texto, esperado",
    [
        ("1.234,56", Decimal("1234.56")),
        ("1234,56", Decimal("1234.56")),
        ("R$ 10,50", Decimal("10.50")),
        ("10.50", Decimal("10.50")),
        ("100", Decimal("100")),
    ],
)
def test_interpretar_valor(texto, esperado):
    assert interpretar_valor(texto) == esperado


@pytest.mark.parametrize("texto", ["", "abc", "1,2,3x", "NaN", "Infinity"])
def test_interpretar_valor_invalido(texto):
    with pytest.raises(ValueError):
        interpretar_valor(texto)


def test_arredondamento_meio_para_cima():
    assert arredondar("10.005") == Decimal("10.01")
    assert arredondar(Decimal("2.675")) == Decimal("2.68")  # float daria 2.67
    assert arredondar(0.1 + 0.2) == Decimal("0.30")


def test_formatar_moeda():
    assert formatar_moeda(Decimal("1234.5")) == "R$ 1.234,50"
    assert formatar_moeda(0) == "R$ 0,00"
    assert formatar_moeda(Decimal("1234567.891")) == "R$ 1.234.567,89"


def test_formatadores():
    assert somente_digitos("123.456.789-09") == "12345678909"
    assert formatar_cpf_cnpj("52998224725") == "529.982.247-25"
    assert formatar_cpf_cnpj("11222333000181") == "11.222.333/0001-81"
    assert formatar_telefone("17999990001") == "(17) 99999-0001"
    assert formatar_telefone("1733334444") == "(17) 3333-4444"
    assert formatar_data(date(2026, 3, 5)) == "05/03/2026"
    assert interpretar_data("05/03/2026") == date(2026, 3, 5)
    with pytest.raises(ValueError):
        interpretar_data("2026-03-05")


def test_numero_de_recibo():
    assert formatar_numero_recibo(2026, 12) == "2026/000012"
    assert interpretar_numero_recibo("2026/000012") == (2026, 12)
    assert interpretar_numero_recibo(" 12 ") == (None, 12)
    with pytest.raises(ValueError):
        interpretar_numero_recibo("abc")
