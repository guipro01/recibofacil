"""Testes da interface (CustomTkinter). São ignorados automaticamente se não houver ambiente gráfico.

A janela é criada oculta; os diálogos de mensagem (messagebox) são substituídos por
registros para o teste poder conferir o que seria exibido ao usuário.
"""

from __future__ import annotations

import tkinter as tk
from datetime import date
from decimal import Decimal

import pytest

from app.models.cliente import Cliente
from app.services.recibo_service import NovoRecibo
from tests.conftest import gerar_cpf

try:  # sem display (ex.: servidor sem interface gráfica) os testes são pulados
    _raiz = tk.Tk()
    _raiz.destroy()
except tk.TclError:
    pytest.skip("Sem ambiente gráfico disponível", allow_module_level=True)

from tkinter import messagebox

from app.ui import theme
from app.ui.components import dialogos
from app.ui.main_window import App
from app.ui.views.cliente_dialog import NOVO, ClienteDialog


@pytest.fixture()
def mensagens(monkeypatch):
    """Registra as mensagens que seriam mostradas; confirmações respondem 'não'."""
    registro: list[tuple[str, str, str]] = []

    def espiao(tipo, retorno=None):
        def funcao(titulo=None, mensagem=None, **_opcoes):
            registro.append((tipo, titulo, mensagem))
            return retorno
        return funcao

    monkeypatch.setattr(messagebox, "showinfo", espiao("info"))
    monkeypatch.setattr(messagebox, "showwarning", espiao("aviso"))
    monkeypatch.setattr(messagebox, "showerror", espiao("erro"))
    monkeypatch.setattr(messagebox, "askyesno", espiao("confirmar", False))
    return registro


@pytest.fixture()
def app(ambiente, mensagens):
    theme.aplicar_tema()
    janela = App(ambiente.servicos, "teste")
    janela.withdraw()
    janela.update()
    yield janela
    janela.destroy()


def test_navega_por_todas_as_telas(app):
    for chave in ["dashboard", "clientes", "novo_recibo", "historico", "configuracoes", "dashboard"]:
        app.navegar(chave)
        app.update()
        assert app._atual == chave


def test_cadastro_de_cliente_pela_janela(app, ambiente, mensagens):
    tela = app._telas["clientes"]
    salvos = []
    dialogo = ClienteDialog(tela, ambiente.servicos, NOVO, ao_salvar=salvos.append)
    app.update()
    form = dialogo._formulario

    dialogo._salvar()  # vazio: deve avisar, sem fechar nem gravar
    assert mensagens[-1][0] == "aviso" and "Informe o nome" in mensagens[-1][2] and not salvos

    form.nome.definir("Cliente Pela Interface")
    form.documento.definir(gerar_cpf())
    form.telefone.definir("17999990001")
    assert form.telefone.obter() == "(17) 99999-0001"  # máscara aplicada
    form.uf.definir("SP")
    dialogo._salvar()
    assert len(salvos) == 1
    ambiente.ids_extras.setdefault("cliente", []).append(salvos[0].id)
    assert ambiente.servicos.clientes.obter(salvos[0].id).telefone == "17999990001"


def test_tela_de_clientes_pesquisa_e_lista(app, ambiente):
    tela = app._telas["clientes"]
    app.navegar("clientes")
    tela._busca.insert(0, "Cliente de Teste")
    tela._pesquisar(1)
    assert tela._tabela.total_linhas() == 1
    tela._tabela._arvore.selection_set(str(ambiente.cliente.id))
    app.update()
    assert str(tela._btn_situacao.cget("text")) == "Desativar"


def test_formulario_de_recibo_monta_os_dados_certos(app, ambiente, mensagens, monkeypatch):
    tela = app._telas["novo_recibo"]
    app.navegar("novo_recibo")
    capturados: list[NovoRecibo] = []

    def falso_emitir(dados, hoje=None):
        capturados.append(dados)
        raise RuntimeError("não gravar nada no banco")  # evita queimar número do emitente real

    monkeypatch.setattr(ambiente.servicos.recibos, "emitir", falso_emitir)

    tela._emitir()  # sem cliente
    assert "Selecione o cliente" in mensagens[-1][2] and not capturados

    tela._definir_cliente(Cliente(id=ambiente.cliente.id, nome="X", tipo_pessoa="F", documento=ambiente.cliente.documento))
    tela._adicionar_item()  # sem descrição
    assert mensagens[-1][0] == "aviso" and tela._itens == []

    for descricao, qtd, valor in [("Consultoria", "2,5", "350,00"), ("Deslocamento", "1", "85,90")]:
        tela._descricao.definir(descricao)
        tela._quantidade.definir(qtd)
        tela._valor_unitario.definir(valor)
        tela._adicionar_item()
    assert len(tela._itens) == 2 and tela._subtotal.cget("text") == "R$ 960,90"

    tela._desconto.insert(0, "60,90")
    tela._atualizar_totais()
    assert tela._total.cget("text") == "R$ 900,00"
    tela._desconto.delete(0, "end")
    tela._desconto.insert(0, "abc")
    tela._atualizar_totais()
    assert "inválido" in tela._total.cget("text")
    tela._desconto.delete(0, "end")
    tela._desconto.insert(0, "60,90")
    tela._atualizar_totais()

    tela._pagar.select()
    tela._alternar_pagamento()
    assert tela._valor_pago.obter() == "900,00"  # sugere o total
    tela._observacoes.insert("1.0", "Obrigado!")
    tela._emitir()

    assert len(capturados) == 1
    dados = capturados[0]
    assert dados.cliente_id == ambiente.cliente.id and dados.data_emissao == date.today()
    assert dados.desconto == Decimal("60.90") and dados.observacoes == "Obrigado!"
    assert [(i.descricao, i.quantidade, i.valor_unitario) for i in dados.itens] == [
        ("Consultoria", Decimal("2.500"), Decimal("350.00")), ("Deslocamento", Decimal("1.000"), Decimal("85.90"))]
    assert dados.pagamento.valor == Decimal("900.00") and dados.pagamento.data_pagamento == date.today()
    assert mensagens[-1][0] == "erro"  # a falha simulada vira mensagem amigável, sem derrubar a tela


def test_editar_e_remover_servico(app, ambiente):
    tela = app._telas["novo_recibo"]
    tela._descricao.definir("Serviço A")
    tela._valor_unitario.definir("10")
    tela._adicionar_item()
    tela._tabela._arvore.selection_set("0")
    tela._editar_item()
    assert tela._itens == [] and tela._descricao.obter() == "Serviço A" and tela._valor_unitario.obter() == "10,00"
    tela._adicionar_item()
    tela._tabela._arvore.selection_set("0")
    tela._remover_item()
    assert tela._itens == []


def test_historico_valida_filtros_e_pesquisa(app, ambiente, mensagens):
    tela = app._telas["historico"]
    app.navegar("historico")
    tela._numero.definir("abc")
    tela._pesquisar(True)
    assert mensagens[-1][0] == "aviso" and "Número de recibo inválido" in mensagens[-1][2]
    tela._numero.limpar()
    tela._inicio.definir("01/12/2026")
    tela._fim.definir("01/11/2026")
    tela._pesquisar(True)
    assert "data inicial" in mensagens[-1][2]
    tela._limpar()
    app.update()
    assert tela._paginador._pagina == 1


def test_tela_de_configuracoes_carrega_o_emitente(app, ambiente):
    tela = app._telas["configuracoes"]
    app.navegar("configuracoes")
    app.update()
    assert tela._form_emitente.nome.obter()  # emitente padrão do banco preenchido
    assert tela._pasta.get()


def test_excecoes_inesperadas_nao_expoem_detalhes_tecnicos(app, mensagens):
    ok, _ = dialogos.executar(app, lambda: 1 / 0)
    assert not ok and mensagens[-1][0] == "erro" and "ZeroDivision" not in mensagens[-1][2]
