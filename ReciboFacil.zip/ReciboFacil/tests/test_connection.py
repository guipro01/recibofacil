"""Testes da conexão, das transações e da tradução de erros do banco."""

import uuid

import pymysql
import pytest

from app.config.settings import DatabaseSettings, load_database_settings
from app.core.connection import Database
from app.core.exceptions import (
    ConexaoBancoError,
    IntegridadeError,
    RegistroDuplicadoError,
    RestricaoError,
)
from tests.conftest import documento_unico


def test_conexao_devolve_versao(db):
    assert db.testar_conexao()


def test_senha_errada_vira_conexao_banco_error():
    base = load_database_settings()
    errada = DatabaseSettings(**{**base.__dict__, "password": "senha-errada-xyz"})
    with pytest.raises(ConexaoBancoError) as erro:
        Database(errada).conectar()
    assert "DB_PASSWORD" in erro.value.mensagem


def test_transacao_faz_commit_e_rollback(db):
    chave = f"teste_{uuid.uuid4().hex[:12]}"

    # Erro dentro do bloco -> ROLLBACK: nada é gravado
    with pytest.raises(RuntimeError):
        with db.transaction() as cur:
            cur.execute("INSERT INTO configuracoes (chave, valor) VALUES (%s, 'x')", (chave,))
            raise RuntimeError("falha simulada")
    with db.cursor() as cur:
        cur.execute("SELECT COUNT(*) AS n FROM configuracoes WHERE chave = %s", (chave,))
        assert cur.fetchone()["n"] == 0

    # Bloco concluído -> COMMIT
    with db.transaction() as cur:
        cur.execute("INSERT INTO configuracoes (chave, valor) VALUES (%s, 'x')", (chave,))
    try:
        with db.cursor() as cur:
            cur.execute("SELECT COUNT(*) AS n FROM configuracoes WHERE chave = %s", (chave,))
            assert cur.fetchone()["n"] == 1
    finally:
        with db.transaction() as cur:
            cur.execute("DELETE FROM configuracoes WHERE chave = %s", (chave,))


def test_documento_duplicado_vira_mensagem_clara(db):
    doc = documento_unico(11)
    with pytest.raises(RegistroDuplicadoError) as erro:
        with db.transaction() as cur:
            sql = "INSERT INTO clientes (nome, tipo_pessoa, documento) VALUES ('A', 'F', %s)"
            cur.execute(sql, (doc,))
            cur.execute(sql, (doc,))
    assert "CPF/CNPJ" in erro.value.mensagem
    assert erro.value.detalhe  # detalhe técnico preservado para o log


def test_check_violado_vira_restricao_error(db):
    with pytest.raises(RestricaoError) as erro:
        with db.transaction() as cur:
            cur.execute("INSERT INTO clientes (nome, tipo_pessoa, documento) VALUES ('A', 'F', '123')")
    assert "CPF/CNPJ" in erro.value.mensagem


def test_fk_violada_vira_integridade_error(db):
    with pytest.raises(IntegridadeError):
        with db.transaction() as cur:
            cur.execute(
                "INSERT INTO pagamentos (recibo_id, forma_pagamento_id, valor, data_pagamento) "
                "VALUES (999999999, 1, 10.00, '2026-01-01')"
            )


def test_erro_do_pymysql_nao_vaza_para_a_interface(db):
    with pytest.raises(Exception) as erro:
        with db.cursor() as cur:
            cur.execute("SELECT * FROM tabela_que_nao_existe")
    assert not isinstance(erro.value, pymysql.MySQLError)
