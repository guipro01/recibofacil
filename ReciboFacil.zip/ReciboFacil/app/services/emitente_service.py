"""Regras de negócio do emitente (quem emite os recibos)."""

from __future__ import annotations

from app.core.connection import Database
from app.core.exceptions import RegistroNaoEncontradoError, ValidacaoError
from app.models.emitente import Emitente
from app.repositories.emitente_repository import EmitenteRepository
from app.repositories.historico_repository import HistoricoRepository
from app.services.cliente_service import _alteracoes
from app.validators.pessoa import validar_e_normalizar_pessoa


class EmitenteService:
    def __init__(self, db: Database) -> None:
        self._db = db
        self._emitentes = EmitenteRepository()
        self._historico = HistoricoRepository()

    def obter_padrao(self) -> Emitente | None:
        with self._db.cursor() as cur:
            return self._emitentes.obter_padrao(cur)

    def salvar(self, emitente: Emitente) -> Emitente:
        """Cria o emitente (sem id) ou atualiza o existente. Recibos antigos não mudam."""
        erros = validar_e_normalizar_pessoa(emitente)
        if erros:
            raise ValidacaoError(erros)
        with self._db.transaction() as cur:
            outro = self._emitentes.obter_por_documento(cur, emitente.documento)
            if outro and outro.id != emitente.id:
                raise ValidacaoError(f"Já existe outro emitente com este CPF/CNPJ: {outro.nome}.")
            if emitente.id is None:
                emitente.ativo = True
                self._emitentes.inserir(cur, emitente)
                self._historico.registrar(
                    cur, "emitente", emitente.id, "CADASTRO", f"Emitente cadastrado: {emitente.nome}",
                    dados_novos=emitente.dados_auditoria(),
                )
            else:
                atual = self._emitentes.obter(cur, emitente.id, bloquear=True)
                if atual is None:
                    raise RegistroNaoEncontradoError("Emitente não encontrado.")
                emitente.ativo = atual.ativo
                antes, depois = _alteracoes(atual.dados_auditoria(), emitente.dados_auditoria())
                self._emitentes.atualizar(cur, emitente)
                if depois:
                    self._historico.registrar(
                        cur, "emitente", emitente.id, "ALTERACAO", f"Emitente alterado: {emitente.nome}",
                        dados_anteriores=antes, dados_novos=depois,
                    )
        return emitente
