"""Geração dos PDFs dos recibos e entrega ao visualizador."""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from app.core.exceptions import ErroDocumento
from app.core.logger import get_logger
from app.documents.recibo_pdf import gerar_pdf_recibo
from app.documents.visualizador import abrir_pdf, imprimir_pdf
from app.services.configuracao_service import ConfiguracaoService
from app.services.recibo_service import ReciboService

log = get_logger(__name__)


class PdfService:
    def __init__(self, recibos: ReciboService, configuracoes: ConfiguracaoService) -> None:
        self._recibos = recibos
        self._config = configuracoes

    def gerar(self, recibo_id: int) -> Path:
        """Gera (ou regera) o PDF do recibo a partir dos dados gravados no banco."""
        detalhes = self._recibos.obter_detalhes(recibo_id)
        nome = "Recibo_" + re.sub(r"[^0-9A-Za-z]+", "-", detalhes.recibo.numero_formatado) + ".pdf"
        destino = self._config.pasta_pdf() / nome
        rodape = self._config.rodape_recibo()
        try:
            try:
                return gerar_pdf_recibo(detalhes, rodape, destino)
            except PermissionError:
                # Arquivo aberto em outro programa (Windows bloqueia): grava uma cópia nova.
                alternativo = destino.with_name(f"{destino.stem}_{datetime.now():%H%M%S}.pdf")
                return gerar_pdf_recibo(detalhes, rodape, alternativo)
        except OSError as exc:
            log.exception("Falha ao gravar o PDF")
            raise ErroDocumento(
                "Não foi possível salvar o PDF. Verifique a pasta configurada e as permissões.", detalhe=str(exc)
            ) from exc

    def abrir(self, recibo_id: int) -> Path:
        caminho = self.gerar(recibo_id)
        abrir_pdf(caminho)
        return caminho

    def imprimir(self, recibo_id: int) -> Path:
        caminho = self.gerar(recibo_id)
        imprimir_pdf(caminho)
        return caminho
