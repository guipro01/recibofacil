"""Regras de negócio de recibos: emissão, pagamentos, cancelamento e consultas."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal

from app.core.connection import Database
from app.core.exceptions import RegistroNaoEncontradoError, RegraNegocioError, ValidacaoError
from app.models.filtros import FiltroRecibos
from app.models.paginacao import Pagina
from app.models.recibo import ItemRecibo, Pagamento, Recibo, ResumoRecibo
from app.repositories.cliente_repository import ClienteRepository
from app.repositories.emitente_repository import EmitenteRepository
from app.repositories.forma_pagamento_repository import FormaPagamentoRepository
from app.repositories.historico_repository import HistoricoRepository
from app.repositories.pagamento_repository import PagamentoRepository
from app.repositories.recibo_repository import ReciboRepository
from app.utils.dinheiro import ZERO, arredondar
from app.validators import recibo as validador


@dataclass(kw_only=True)
class NovoPagamento:
    forma_pagamento_id: int
    valor: Decimal
    data_pagamento: date
    observacoes: str | None = None


@dataclass(kw_only=True)
class NovoRecibo:
    """Dados informados pelo usuário para emitir um recibo."""

    cliente_id: int
    itens: list[ItemRecibo]
    data_emissao: date | None = None  # padrão: hoje
    desconto: Decimal = ZERO
    observacoes: str | None = None
    pagamento: NovoPagamento | None = None  # pagamento opcional já na emissão
    emitente_id: int | None = None  # padrão: emitente padrão do sistema


@dataclass(kw_only=True)
class DetalhesRecibo:
    recibo: Recibo
    pagamentos: list[Pagamento] = field(default_factory=list)
    recebido: Decimal = ZERO
    pendente: Decimal = ZERO


def _pendente(recibo: Recibo, recebido: Decimal) -> Decimal:
    return ZERO if recibo.cancelado else arredondar(recibo.total - recebido)


class ReciboService:
    def __init__(self, db: Database) -> None:
        self._db = db
        self._recibos = ReciboRepository()
        self._clientes = ClienteRepository()
        self._emitentes = EmitenteRepository()
        self._formas = FormaPagamentoRepository()
        self._pagamentos = PagamentoRepository()
        self._historico = HistoricoRepository()

    # ------------------------------------------------------------------
    # Emissão
    # ------------------------------------------------------------------
    def emitir(self, dados: NovoRecibo, hoje: date | None = None) -> Recibo:
        """Emite um recibo em UMA transação: número, cabeçalho, itens, pagamento e histórico.

        Qualquer falha desfaz tudo (inclusive o número reservado, sem deixar buracos).
        """
        hoje = hoje or date.today()
        data_emissao = dados.data_emissao or hoje

        # Validações que não dependem do banco
        for item in dados.itens:  # garante valores arredondados e subtotal coerente
            item.subtotal = item.calcular_subtotal()
        erros = validador.validar_data_emissao(data_emissao, hoje)
        erros += validador.validar_itens(dados.itens)
        subtotal = arredondar(sum((i.subtotal for i in dados.itens), ZERO))
        desconto = arredondar(dados.desconto)
        erros += validador.validar_totais(subtotal, desconto)
        if len(dados.observacoes or "") > 1000:
            erros.append("As observações podem ter no máximo 1000 caracteres.")
        if erros:
            raise ValidacaoError(erros)

        with self._db.transaction() as cur:
            # Trava cliente e emitente: o snapshot gravado reflete o cadastro atual e consistente
            cliente = self._clientes.obter(cur, dados.cliente_id, bloquear=True)
            if cliente is None:
                raise ValidacaoError("Selecione um cliente cadastrado.")
            if not cliente.ativo:
                raise ValidacaoError("O cliente selecionado está desativado. Reative-o para emitir recibos.")
            if dados.emitente_id is None:
                emitente = self._emitentes.obter_padrao(cur)
            else:
                emitente = self._emitentes.obter(cur, dados.emitente_id, bloquear=True)
            if emitente is None:
                raise ValidacaoError("Cadastre o emitente em Configurações antes de emitir recibos.")
            if not emitente.ativo:
                raise ValidacaoError("O emitente selecionado está desativado.")

            forma = None
            if dados.pagamento is not None:
                forma = self._formas.obter(cur, dados.pagamento.forma_pagamento_id)
                if forma is None or not forma.ativo:
                    raise ValidacaoError("Forma de pagamento inválida ou desativada.")
                erros = validador.validar_pagamento(
                    arredondar(dados.pagamento.valor), dados.pagamento.data_pagamento, hoje, subtotal - desconto
                )
                if erros:
                    raise ValidacaoError(erros)

            recibo = Recibo(
                emitente_id=emitente.id,
                cliente_id=cliente.id,
                data_emissao=data_emissao,
                ano=data_emissao.year,
                desconto=desconto,
                observacoes=dados.observacoes,
                itens=dados.itens,
                cliente_nome=cliente.nome,
                cliente_tipo_pessoa=cliente.tipo_pessoa,
                cliente_documento=cliente.documento,
                cliente_telefone=cliente.telefone,
                cliente_endereco=cliente.endereco_formatado,
                emitente_nome=emitente.nome,
                emitente_tipo_pessoa=emitente.tipo_pessoa,
                emitente_documento=emitente.documento,
                emitente_telefone=emitente.telefone,
                emitente_endereco=emitente.endereco_formatado,
            )
            recibo.recalcular_totais()
            recibo.numero = self._recibos.proximo_numero(cur, emitente.id, recibo.ano)
            self._recibos.inserir(cur, recibo)
            self._recibos.inserir_itens(cur, recibo.id, recibo.itens)

            if dados.pagamento is not None:
                pagamento = Pagamento(
                    recibo_id=recibo.id,
                    forma_pagamento_id=dados.pagamento.forma_pagamento_id,
                    valor=arredondar(dados.pagamento.valor),
                    data_pagamento=dados.pagamento.data_pagamento,
                    observacoes=dados.pagamento.observacoes,
                )
                self._pagamentos.inserir(cur, pagamento)

            self._historico.registrar(
                cur, "recibo", recibo.id, "EMISSAO",
                f"Recibo {recibo.numero_formatado} emitido para {recibo.cliente_nome}",
                dados_novos={
                    "numero": recibo.numero_formatado, "cliente_id": recibo.cliente_id,
                    "subtotal": recibo.subtotal, "desconto": recibo.desconto, "total": recibo.total,
                    "itens": len(recibo.itens),
                },
            )
        return recibo

    # ------------------------------------------------------------------
    # Pagamentos
    # ------------------------------------------------------------------
    def registrar_pagamento(self, recibo_id: int, dados: NovoPagamento, hoje: date | None = None) -> Pagamento:
        hoje = hoje or date.today()
        valor = arredondar(dados.valor)
        with self._db.transaction() as cur:
            recibo = self._recibos.obter(cur, recibo_id, bloquear=True)  # serializa pagamentos do mesmo recibo
            if recibo is None:
                raise RegistroNaoEncontradoError("Recibo não encontrado.")
            if recibo.cancelado:
                raise RegraNegocioError("Não é possível registrar pagamento em um recibo cancelado.")
            forma = self._formas.obter(cur, dados.forma_pagamento_id)
            if forma is None or not forma.ativo:
                raise ValidacaoError("Forma de pagamento inválida ou desativada.")
            recebido = self._pagamentos.total_recebido(cur, recibo_id)
            erros = validador.validar_pagamento(valor, dados.data_pagamento, hoje, _pendente(recibo, recebido))
            if erros:
                raise ValidacaoError(erros)
            pagamento = Pagamento(
                recibo_id=recibo_id, forma_pagamento_id=forma.id, valor=valor,
                data_pagamento=dados.data_pagamento, observacoes=dados.observacoes, forma_descricao=forma.descricao,
            )
            self._pagamentos.inserir(cur, pagamento)
            self._historico.registrar(
                cur, "recibo", recibo_id, "PAGAMENTO",
                f"Pagamento de {valor} ({forma.descricao}) no recibo {recibo.numero_formatado}",
                dados_novos={"valor": valor, "forma": forma.descricao, "data": dados.data_pagamento},
            )
        return pagamento

    # ------------------------------------------------------------------
    # Cancelamento
    # ------------------------------------------------------------------
    def cancelar(self, recibo_id: int, motivo: str) -> None:
        """Cancelamento lógico: o recibo e o número permanecem registrados."""
        motivo = " ".join((motivo or "").split())
        if len(motivo) < 5:
            raise ValidacaoError("Informe o motivo do cancelamento (mínimo 5 caracteres).")
        if len(motivo) > 255:
            raise ValidacaoError("O motivo pode ter no máximo 255 caracteres.")
        with self._db.transaction() as cur:
            recibo = self._recibos.obter(cur, recibo_id, bloquear=True)
            if recibo is None:
                raise RegistroNaoEncontradoError("Recibo não encontrado.")
            if recibo.cancelado:
                raise RegraNegocioError("Este recibo já está cancelado.")
            self._recibos.cancelar(cur, recibo_id, motivo)
            self._historico.registrar(
                cur, "recibo", recibo_id, "CANCELAMENTO",
                f"Recibo {recibo.numero_formatado} cancelado: {motivo}",
                dados_anteriores={"situacao": "EMITIDO"}, dados_novos={"situacao": "CANCELADO", "motivo": motivo},
            )

    # ------------------------------------------------------------------
    # Consultas
    # ------------------------------------------------------------------
    def obter_detalhes(self, recibo_id: int) -> DetalhesRecibo:
        with self._db.cursor() as cur:
            recibo = self._recibos.obter_com_itens(cur, recibo_id)
            if recibo is None:
                raise RegistroNaoEncontradoError("Recibo não encontrado.")
            pagamentos = self._pagamentos.listar_por_recibo(cur, recibo_id)
        recebido = arredondar(sum((p.valor for p in pagamentos), ZERO))
        return DetalhesRecibo(
            recibo=recibo, pagamentos=pagamentos, recebido=recebido, pendente=_pendente(recibo, recebido)
        )

    def pesquisar(
        self, filtro: FiltroRecibos | None = None, pagina: int = 1, por_pagina: int = 25
    ) -> Pagina[ResumoRecibo]:
        with self._db.cursor() as cur:
            total = self._recibos.contar(cur, filtro)
            itens = self._recibos.pesquisar(cur, filtro, limite=por_pagina, deslocamento=(pagina - 1) * por_pagina)
        return Pagina(itens=itens, total=total, pagina=pagina, por_pagina=por_pagina)

    def historico_do_recibo(self, recibo_id: int) -> list[dict]:
        with self._db.cursor() as cur:
            return self._historico.listar_por_entidade(cur, "recibo", recibo_id)
