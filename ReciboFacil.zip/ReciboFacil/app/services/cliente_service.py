"""Regras de negócio de clientes."""

from __future__ import annotations

from typing import Any

from app.core.connection import Database
from app.core.exceptions import RegistroNaoEncontradoError, ValidacaoError
from app.models.cliente import Cliente
from app.models.paginacao import Pagina
from app.repositories.cliente_repository import ClienteRepository
from app.repositories.historico_repository import HistoricoRepository
from app.repositories.relatorio_repository import RelatorioRepository
from app.validators.pessoa import validar_e_normalizar_pessoa

SITUACOES = {"ativos": True, "inativos": False, "todos": None}


def _alteracoes(antes: dict[str, Any], depois: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    """Mantém apenas os campos que mudaram (para o histórico)."""
    campos = [c for c in depois if antes.get(c) != depois[c]]
    return {c: antes.get(c) for c in campos}, {c: depois[c] for c in campos}


class ClienteService:
    def __init__(self, db: Database) -> None:
        self._db = db
        self._clientes = ClienteRepository()
        self._historico = HistoricoRepository()
        self._relatorios = RelatorioRepository()

    def cadastrar(self, cliente: Cliente) -> Cliente:
        erros = validar_e_normalizar_pessoa(cliente)
        if erros:
            raise ValidacaoError(erros)
        cliente.ativo = True
        with self._db.transaction() as cur:
            existente = self._clientes.obter_por_documento(cur, cliente.documento)
            if existente:
                raise ValidacaoError(f"Já existe um cliente com este CPF/CNPJ: {existente.nome}.")
            self._clientes.inserir(cur, cliente)
            self._historico.registrar(
                cur, "cliente", cliente.id, "CADASTRO", f"Cliente cadastrado: {cliente.nome}",
                dados_novos=cliente.dados_auditoria(),
            )
        return cliente

    def atualizar(self, cliente: Cliente) -> Cliente:
        """Altera o cadastro. Recibos já emitidos NÃO são afetados (guardam cópia dos dados)."""
        if cliente.id is None:
            raise ValidacaoError("Cliente sem identificação.")
        erros = validar_e_normalizar_pessoa(cliente)
        if erros:
            raise ValidacaoError(erros)
        with self._db.transaction() as cur:
            atual = self._clientes.obter(cur, cliente.id, bloquear=True)
            if atual is None:
                raise RegistroNaoEncontradoError("Cliente não encontrado.")
            outro = self._clientes.obter_por_documento(cur, cliente.documento)
            if outro and outro.id != cliente.id:
                raise ValidacaoError(f"Já existe outro cliente com este CPF/CNPJ: {outro.nome}.")
            cliente.ativo = atual.ativo  # situação só muda por desativar/reativar
            antes, depois = _alteracoes(atual.dados_auditoria(), cliente.dados_auditoria())
            self._clientes.atualizar(cur, cliente)
            if depois:
                self._historico.registrar(
                    cur, "cliente", cliente.id, "ALTERACAO", f"Cadastro alterado: {cliente.nome}",
                    dados_anteriores=antes, dados_novos=depois,
                )
        return cliente

    def desativar(self, cliente_id: int) -> None:
        self._alterar_situacao(cliente_id, ativo=False)

    def reativar(self, cliente_id: int) -> None:
        self._alterar_situacao(cliente_id, ativo=True)

    def _alterar_situacao(self, cliente_id: int, ativo: bool) -> None:
        with self._db.transaction() as cur:
            cliente = self._clientes.obter(cur, cliente_id, bloquear=True)
            if cliente is None:
                raise RegistroNaoEncontradoError("Cliente não encontrado.")
            if cliente.ativo == ativo:
                return
            self._clientes.definir_ativo(cur, cliente_id, ativo)
            self._historico.registrar(
                cur, "cliente", cliente_id, "REATIVACAO" if ativo else "DESATIVACAO",
                f"Cliente {'reativado' if ativo else 'desativado'}: {cliente.nome}",
                dados_anteriores={"ativo": not ativo}, dados_novos={"ativo": ativo},
            )

    def obter(self, cliente_id: int) -> Cliente:
        with self._db.cursor() as cur:
            cliente = self._clientes.obter(cur, cliente_id)
        if cliente is None:
            raise RegistroNaoEncontradoError("Cliente não encontrado.")
        return cliente

    def pesquisar(
        self, termo: str | None = None, situacao: str = "ativos", pagina: int = 1, por_pagina: int = 50
    ) -> Pagina[dict[str, Any]]:
        """Lista clientes com a quantidade de recibos e o total emitido de cada um."""
        ativo = SITUACOES[situacao]
        with self._db.cursor() as cur:
            total = self._clientes.contar(cur, termo, ativo)
            itens = self._relatorios.clientes_com_total_recibos(
                cur, termo, ativo, limite=por_pagina, deslocamento=(pagina - 1) * por_pagina
            )
        return Pagina(itens=itens, total=total, pagina=pagina, por_pagina=por_pagina)

    def pesquisar_ativos(self, termo: str | None = None, limite: int = 100) -> list[Cliente]:
        """Clientes ativos para seleção na emissão de recibos."""
        with self._db.cursor() as cur:
            return self._clientes.pesquisar(cur, termo, ativo=True, limite=limite)  # type: ignore[return-value]
