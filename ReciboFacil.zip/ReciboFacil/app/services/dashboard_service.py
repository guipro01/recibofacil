"""Dados do dashboard inicial."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal

from app.core.connection import Database
from app.models.recibo import ResumoRecibo
from app.repositories.recibo_repository import ReciboRepository
from app.repositories.relatorio_repository import RelatorioRepository
from app.utils.dinheiro import ZERO


@dataclass(kw_only=True)
class DadosDashboard:
    total_recibos: int
    valor_emitido: Decimal
    recibos_mes: int
    valor_mes: Decimal
    valor_recebido: Decimal
    valor_pendente: Decimal
    recibos_cancelados: int
    ultimos: list[ResumoRecibo] = field(default_factory=list)
    por_mes: list[tuple[str, int, Decimal]] = field(default_factory=list)  # (AAAA-MM, quantidade, total)


def _ultimos_meses(hoje: date, quantidade: int) -> list[str]:
    """['AAAA-MM', ...] dos últimos meses, do mais antigo para o atual."""
    meses = []
    ano, mes = hoje.year, hoje.month
    for _ in range(quantidade):
        meses.append(f"{ano:04d}-{mes:02d}")
        mes -= 1
        if mes == 0:
            ano, mes = ano - 1, 12
    return meses[::-1]


class DashboardService:
    def __init__(self, db: Database) -> None:
        self._db = db
        self._relatorios = RelatorioRepository()
        self._recibos = ReciboRepository()

    def carregar(self, hoje: date | None = None, ultimos: int = 8, meses: int = 6) -> DadosDashboard:
        hoje = hoje or date.today()
        with self._db.cursor() as cur:
            resumo = self._relatorios.resumo_dashboard(cur, hoje)
            recentes = self._recibos.ultimos(cur, ultimos)
            por_mes = {m["mes"]: (int(m["quantidade"]), Decimal(m["total_emitido"]))
                       for m in self._relatorios.total_por_mes(cur)}
        serie = [(mes, *por_mes.get(mes, (0, ZERO))) for mes in _ultimos_meses(hoje, meses)]
        return DadosDashboard(
            total_recibos=resumo["total_recibos"],
            valor_emitido=resumo["valor_emitido"],
            recibos_mes=resumo["recibos_mes"],
            valor_mes=resumo["valor_mes"],
            valor_recebido=resumo["valor_recebido"],
            valor_pendente=resumo["valor_pendente"],
            recibos_cancelados=resumo["recibos_cancelados"],
            ultimos=recentes,
            por_mes=serie,
        )
