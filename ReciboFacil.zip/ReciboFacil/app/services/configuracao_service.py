"""Configurações gerais e formas de pagamento."""

from __future__ import annotations

from pathlib import Path

from app.config.settings import BASE_DIR
from app.core.connection import Database
from app.core.exceptions import RegistroNaoEncontradoError, ValidacaoError
from app.models.forma_pagamento import FormaPagamento
from app.repositories.configuracao_repository import ConfiguracaoRepository
from app.repositories.forma_pagamento_repository import FormaPagamentoRepository
from app.repositories.historico_repository import HistoricoRepository

CHAVE_RODAPE = "rodape_recibo"
CHAVE_PASTA_PDF = "pasta_pdf"
PASTA_PDF_PADRAO = "output/pdfs"
RODAPE_PADRAO = "Recibo emitido eletronicamente pelo sistema ReciboFácil."


class ConfiguracaoService:
    def __init__(self, db: Database) -> None:
        self._db = db
        self._config = ConfiguracaoRepository()
        self._formas = FormaPagamentoRepository()
        self._historico = HistoricoRepository()

    # --- Configurações -----------------------------------------------------
    def rodape_recibo(self) -> str:
        with self._db.cursor() as cur:
            return self._config.obter(cur, CHAVE_RODAPE, RODAPE_PADRAO) or ""

    def pasta_pdf(self) -> Path:
        """Pasta dos PDFs. Caminho relativo é resolvido a partir da pasta do projeto."""
        with self._db.cursor() as cur:
            texto = self._config.obter(cur, CHAVE_PASTA_PDF, PASTA_PDF_PADRAO) or PASTA_PDF_PADRAO
        pasta = Path(texto)
        return pasta if pasta.is_absolute() else BASE_DIR / pasta

    def pasta_pdf_texto(self) -> str:
        with self._db.cursor() as cur:
            return self._config.obter(cur, CHAVE_PASTA_PDF, PASTA_PDF_PADRAO) or PASTA_PDF_PADRAO

    def salvar(self, rodape: str, pasta_pdf: str) -> None:
        rodape, pasta_pdf = rodape.strip(), pasta_pdf.strip()
        erros = []
        if len(rodape) > 300:
            erros.append("O rodapé pode ter no máximo 300 caracteres.")
        if not pasta_pdf:
            erros.append("Informe a pasta onde os PDFs serão salvos.")
        else:
            try:
                destino = Path(pasta_pdf)
                destino = destino if destino.is_absolute() else BASE_DIR / destino
                destino.mkdir(parents=True, exist_ok=True)
            except OSError:
                erros.append("Não foi possível usar a pasta de PDFs informada. Verifique o caminho e as permissões.")
        if erros:
            raise ValidacaoError(erros)
        with self._db.transaction() as cur:
            self._config.definir(cur, CHAVE_RODAPE, rodape)
            self._config.definir(cur, CHAVE_PASTA_PDF, pasta_pdf)
            self._historico.registrar(cur, "configuracao", None, "ALTERACAO", "Configurações gerais alteradas")

    # --- Formas de pagamento -------------------------------------------------
    def listar_formas(self, somente_ativas: bool = True) -> list[FormaPagamento]:
        with self._db.cursor() as cur:
            return self._formas.listar(cur, somente_ativas)

    def cadastrar_forma(self, descricao: str) -> FormaPagamento:
        descricao = " ".join((descricao or "").split())
        if len(descricao) < 2:
            raise ValidacaoError("Informe a descrição da forma de pagamento (mínimo 2 caracteres).")
        if len(descricao) > 50:
            raise ValidacaoError("A descrição pode ter no máximo 50 caracteres.")
        forma = FormaPagamento(descricao=descricao)
        with self._db.transaction() as cur:
            self._formas.inserir(cur, forma)
            self._historico.registrar(cur, "forma_pagamento", forma.id, "CADASTRO", f"Forma de pagamento: {descricao}")
        return forma

    def alterar_situacao_forma(self, forma_id: int, ativo: bool) -> None:
        with self._db.transaction() as cur:
            if self._formas.obter(cur, forma_id) is None:
                raise RegistroNaoEncontradoError("Forma de pagamento não encontrada.")
            self._formas.definir_ativo(cur, forma_id, ativo)
            self._historico.registrar(
                cur, "forma_pagamento", forma_id, "REATIVACAO" if ativo else "DESATIVACAO",
                "Forma de pagamento " + ("reativada" if ativo else "desativada"),
            )
