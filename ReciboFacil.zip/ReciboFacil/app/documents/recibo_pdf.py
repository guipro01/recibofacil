"""Geração do PDF do recibo (A4) com ReportLab."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import (
    HRFlowable,
    KeepTogether,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from app.services.recibo_service import DetalhesRecibo
from app.utils.dinheiro import ZERO, formatar_moeda
from app.utils.extenso import valor_por_extenso
from app.utils.formatadores import (
    formatar_cpf_cnpj,
    formatar_data,
    formatar_data_hora,
    formatar_quantidade,
    formatar_telefone,
)

# Paleta do documento
AZUL = colors.HexColor("#14213D")
AZUL_CLARO = colors.HexColor("#E8EEF8")
CINZA = colors.HexColor("#6B7280")
CINZA_CLARO = colors.HexColor("#F3F4F6")
LINHA = colors.HexColor("#D1D5DB")
VERMELHO = colors.HexColor("#B91C1C")

MESES = [
    "janeiro", "fevereiro", "março", "abril", "maio", "junho",
    "julho", "agosto", "setembro", "outubro", "novembro", "dezembro",
]

LARGURA_UTIL = A4[0] - 36 * mm  # margens de 18 mm


def _estilos() -> dict[str, ParagraphStyle]:
    base = ParagraphStyle("base", fontName="Helvetica", fontSize=9.5, leading=13, textColor=colors.black)
    return {
        "base": base,
        "emitente": ParagraphStyle("emitente", parent=base, fontName="Helvetica-Bold", fontSize=15, leading=18, textColor=AZUL),
        "pequeno": ParagraphStyle("pequeno", parent=base, fontSize=8.5, leading=11.5, textColor=CINZA),
        "titulo": ParagraphStyle("titulo", parent=base, fontName="Helvetica-Bold", fontSize=22, leading=26, textColor=AZUL, alignment=TA_RIGHT),
        "numero": ParagraphStyle("numero", parent=base, fontName="Helvetica-Bold", fontSize=11, alignment=TA_RIGHT),
        "data": ParagraphStyle("data", parent=base, fontSize=9.5, alignment=TA_RIGHT, textColor=CINZA),
        "valor": ParagraphStyle("valor", parent=base, fontName="Helvetica-Bold", fontSize=17, leading=21, textColor=AZUL, alignment=TA_RIGHT),
        "texto": ParagraphStyle("texto", parent=base, fontSize=10.5, leading=16, alignment=TA_JUSTIFY),
        "secao": ParagraphStyle("secao", parent=base, fontName="Helvetica-Bold", fontSize=9, textColor=AZUL, spaceBefore=10, spaceAfter=4),
        "cab_tabela": ParagraphStyle("cab_tabela", parent=base, fontName="Helvetica-Bold", fontSize=8.5, textColor=colors.white),
        "cab_direita": ParagraphStyle("cab_direita", parent=base, fontName="Helvetica-Bold", fontSize=8.5, textColor=colors.white, alignment=TA_RIGHT),
        "celula": ParagraphStyle("celula", parent=base, fontSize=9.5, leading=12),
        "direita": ParagraphStyle("direita", parent=base, fontSize=9.5, leading=12, alignment=TA_RIGHT),
        "total_rotulo": ParagraphStyle("total_rotulo", parent=base, fontName="Helvetica-Bold", fontSize=11, textColor=AZUL, alignment=TA_RIGHT),
        "total_valor": ParagraphStyle("total_valor", parent=base, fontName="Helvetica-Bold", fontSize=11, textColor=AZUL, alignment=TA_RIGHT),
        "assinatura": ParagraphStyle("assinatura", parent=base, fontSize=9.5, alignment=TA_CENTER, leading=12),
        "cancelado": ParagraphStyle("cancelado", parent=base, fontName="Helvetica-Bold", fontSize=10, textColor=VERMELHO, leading=14),
    }


def _p(texto: str | None, estilo: ParagraphStyle) -> Paragraph:
    """Parágrafo com o texto escapado (nomes e descrições podem conter & ou <)."""
    return Paragraph(escape(texto or "").replace("\n", "<br/>"), estilo)


def _data_por_extenso(data) -> str:
    return f"{data.day} de {MESES[data.month - 1]} de {data.year}"


def _cabecalho(d: DetalhesRecibo, e: dict[str, ParagraphStyle]) -> Table:
    r = d.recibo
    linhas_emitente = [_p(r.emitente_nome, e["emitente"]), _p(f"CPF/CNPJ: {formatar_cpf_cnpj(r.emitente_documento)}", e["pequeno"])]
    if r.emitente_endereco:
        linhas_emitente.append(_p(r.emitente_endereco, e["pequeno"]))
    if r.emitente_telefone:
        linhas_emitente.append(_p(f"Telefone: {formatar_telefone(r.emitente_telefone)}", e["pequeno"]))
    direita = [
        _p("RECIBO", e["titulo"]),
        _p(f"Nº {r.numero_formatado}", e["numero"]),
        _p(f"Emitido em {formatar_data(r.data_emissao)}", e["data"]),
    ]
    tabela = Table([[linhas_emitente, direita]], colWidths=[LARGURA_UTIL * 0.58, LARGURA_UTIL * 0.42])
    tabela.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    return tabela


def _caixa_valor(total: Decimal, e: dict[str, ParagraphStyle]) -> Table:
    tabela = Table(
        [[_p("VALOR", e["pequeno"]), _p(formatar_moeda(total), e["valor"])]],
        colWidths=[LARGURA_UTIL * 0.3, LARGURA_UTIL * 0.7],
    )
    tabela.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), AZUL_CLARO),
        ("BOX", (0, 0), (-1, -1), 0.8, AZUL),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 12),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    return tabela


def _texto_principal(d: DetalhesRecibo, e: dict[str, ParagraphStyle]) -> Paragraph:
    r = d.recibo
    verbo = "Recebi" if r.emitente_tipo_pessoa == "F" else "Recebemos"
    endereco = f", com endereço em {escape(r.cliente_endereco)}" if r.cliente_endereco else ""
    texto = (
        f"{verbo} de <b>{escape(r.cliente_nome)}</b>, inscrito(a) no CPF/CNPJ "
        f"<b>{formatar_cpf_cnpj(r.cliente_documento)}</b>{endereco}, a importância de "
        f"<b>{formatar_moeda(r.total)}</b> (<i>{escape(valor_por_extenso(r.total))}</i>), "
        "referente à prestação dos serviços discriminados abaixo."
    )
    return Paragraph(texto, e["texto"])


def _tabela_itens(d: DetalhesRecibo, e: dict[str, ParagraphStyle]) -> Table:
    dados = [[
        _p("Item", e["cab_tabela"]), _p("Descrição do serviço", e["cab_tabela"]), _p("Qtd.", e["cab_direita"]),
        _p("Valor unit.", e["cab_direita"]), _p("Subtotal", e["cab_direita"]),
    ]]
    for item in d.recibo.itens:
        dados.append([
            _p(str(item.ordem), e["celula"]), _p(item.descricao, e["celula"]),
            _p(formatar_quantidade(item.quantidade), e["direita"]),
            _p(formatar_moeda(item.valor_unitario), e["direita"]),
            _p(formatar_moeda(item.subtotal), e["direita"]),
        ])
    larguras = [12 * mm, LARGURA_UTIL - 12 * mm - 18 * mm - 30 * mm - 32 * mm, 18 * mm, 30 * mm, 32 * mm]
    tabela = Table(dados, colWidths=larguras, repeatRows=1)
    estilo = [
        ("BACKGROUND", (0, 0), (-1, 0), AZUL),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LINEBELOW", (0, 1), (-1, -1), 0.4, LINHA),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ]
    for linha in range(2, len(dados), 2):  # zebra
        estilo.append(("BACKGROUND", (0, linha), (-1, linha), CINZA_CLARO))
    tabela.setStyle(TableStyle(estilo))
    return tabela


def _tabela_totais(d: DetalhesRecibo, e: dict[str, ParagraphStyle]) -> Table:
    r = d.recibo
    linhas = [[_p("Subtotal", e["direita"]), _p(formatar_moeda(r.subtotal), e["direita"])]]
    if r.desconto > ZERO:
        linhas.append([_p("Desconto", e["direita"]), _p("- " + formatar_moeda(r.desconto), e["direita"])])
    linhas.append([_p("TOTAL", e["total_rotulo"]), _p(formatar_moeda(r.total), e["total_valor"])])
    tabela = Table(linhas, colWidths=[38 * mm, 36 * mm], hAlign="RIGHT")
    tabela.setStyle(TableStyle([
        ("LINEABOVE", (0, -1), (-1, -1), 0.8, AZUL),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ]))
    return tabela


def _tabela_pagamentos(d: DetalhesRecibo, e: dict[str, ParagraphStyle]) -> list:
    dados = [[_p("Data", e["cab_tabela"]), _p("Forma de pagamento", e["cab_tabela"]),
              _p("Observações", e["cab_tabela"]), _p("Valor", e["cab_direita"])]]
    for pg in d.pagamentos:
        dados.append([
            _p(formatar_data(pg.data_pagamento), e["celula"]), _p(pg.forma_descricao, e["celula"]),
            _p(pg.observacoes or "", e["celula"]), _p(formatar_moeda(pg.valor), e["direita"]),
        ])
    tabela = Table(dados, colWidths=[24 * mm, 48 * mm, LARGURA_UTIL - 24 * mm - 48 * mm - 32 * mm, 32 * mm], repeatRows=1)
    tabela.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), AZUL),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LINEBELOW", (0, 1), (-1, -1), 0.4, LINHA),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ]))
    situacao = (
        f"Recebido: <b>{formatar_moeda(d.recebido)}</b> &nbsp;&nbsp;|&nbsp;&nbsp; "
        f"Pendente: <b>{formatar_moeda(d.pendente)}</b>"
    )
    return [Paragraph("PAGAMENTOS", e["secao"]), tabela, Spacer(1, 4), Paragraph(situacao, e["direita"])]


def _assinatura(d: DetalhesRecibo, e: dict[str, ParagraphStyle]) -> KeepTogether:
    r = d.recibo
    linha = HRFlowable(width=85 * mm, thickness=0.7, color=colors.black, hAlign="CENTER", spaceBefore=34, spaceAfter=3)
    return KeepTogether([
        Spacer(1, 10),
        _p(f"Emitido em {_data_por_extenso(r.data_emissao)}.", e["base"]),
        linha,
        _p(r.emitente_nome, e["assinatura"]),
        _p(f"CPF/CNPJ: {formatar_cpf_cnpj(r.emitente_documento)}", e["assinatura"]),
    ])


def _desenhar_pagina(rodape: str, cancelado: bool):
    """Rodapé em todas as páginas e marca d'água 'CANCELADO' quando for o caso."""

    def desenhar(canvas: Canvas, doc: SimpleDocTemplate) -> None:
        canvas.saveState()
        largura, _ = A4
        if cancelado:
            canvas.saveState()
            canvas.setFillColor(VERMELHO)
            canvas.setFillAlpha(0.13)
            canvas.setFont("Helvetica-Bold", 96)
            canvas.translate(largura / 2, A4[1] / 2)
            canvas.rotate(35)
            canvas.drawCentredString(0, 0, "CANCELADO")
            canvas.restoreState()
        canvas.setStrokeColor(LINHA)
        canvas.setLineWidth(0.5)
        canvas.line(18 * mm, 16 * mm, largura - 18 * mm, 16 * mm)
        canvas.setFillColor(CINZA)
        canvas.setFont("Helvetica", 8)
        if rodape:
            canvas.drawCentredString(largura / 2, 11.5 * mm, rodape[:130])
        canvas.drawString(18 * mm, 7 * mm, f"Gerado em {formatar_data_hora(datetime.now())}")
        canvas.drawRightString(largura - 18 * mm, 7 * mm, f"Página {doc.page}")
        canvas.restoreState()

    return desenhar


def gerar_pdf_recibo(detalhes: DetalhesRecibo, rodape: str, destino: Path) -> Path:
    """Gera o PDF do recibo em `destino` e devolve o caminho."""
    r = detalhes.recibo
    e = _estilos()
    destino.parent.mkdir(parents=True, exist_ok=True)

    documento = SimpleDocTemplate(
        str(destino), pagesize=A4,
        leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm, bottomMargin=22 * mm,
        title=f"Recibo {r.numero_formatado}", author=r.emitente_nome, subject="Recibo de prestação de serviços",
    )

    historia: list = [_cabecalho(detalhes, e), HRFlowable(width="100%", thickness=2, color=AZUL, spaceAfter=10)]
    if r.cancelado:
        motivo = escape(r.motivo_cancelamento or "")
        historia += [
            Paragraph(f"RECIBO CANCELADO em {formatar_data(r.cancelado_em)} — Motivo: {motivo}", e["cancelado"]),
            Spacer(1, 6),
        ]
    historia += [
        _caixa_valor(r.total, e), Spacer(1, 10), _texto_principal(detalhes, e), Spacer(1, 10),
        _tabela_itens(detalhes, e), Spacer(1, 6), _tabela_totais(detalhes, e),
    ]
    if detalhes.pagamentos:
        historia += _tabela_pagamentos(detalhes, e)
    if r.observacoes:
        historia += [Paragraph("OBSERVAÇÕES", e["secao"]), _p(r.observacoes, e["base"])]
    historia.append(_assinatura(detalhes, e))

    desenho = _desenhar_pagina(rodape, r.cancelado)
    documento.build(historia, onFirstPage=desenho, onLaterPages=desenho)
    return destino
