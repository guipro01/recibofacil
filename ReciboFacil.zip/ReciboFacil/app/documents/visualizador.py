"""Abertura e impressão de PDFs pelo visualizador padrão do sistema (Windows)."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from app.core.exceptions import ErroDocumento
from app.core.logger import get_logger

log = get_logger(__name__)


def abrir_pdf(caminho: Path) -> None:
    """Abre o PDF no visualizador padrão (de onde o usuário também pode imprimir)."""
    if not caminho.is_file():
        raise ErroDocumento("O arquivo PDF não foi encontrado.")
    try:
        if sys.platform == "win32":
            os.startfile(str(caminho))  # noqa: S606 - abre com o programa padrão do Windows
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(caminho)])
        else:
            subprocess.Popen(["xdg-open", str(caminho)])
    except OSError as exc:
        log.exception("Falha ao abrir o PDF")
        raise ErroDocumento(
            "Não foi possível abrir o PDF. Verifique se há um programa padrão para arquivos PDF.",
            detalhe=str(exc),
        ) from exc


def imprimir_pdf(caminho: Path) -> None:
    """Envia o PDF para impressão pelo visualizador padrão do Windows.

    Alguns visualizadores não aceitam o comando de impressão direta; nesse caso o
    PDF é aberto normalmente, e o usuário imprime com Ctrl+P.
    """
    if not caminho.is_file():
        raise ErroDocumento("O arquivo PDF não foi encontrado.")
    if sys.platform == "win32":
        try:
            os.startfile(str(caminho), "print")  # noqa: S606
            return
        except OSError:
            log.warning("Impressão direta indisponível; abrindo o PDF no visualizador.")
    abrir_pdf(caminho)
