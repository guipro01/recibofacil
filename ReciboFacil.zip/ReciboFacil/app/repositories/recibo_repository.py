"""Repositório de recibos e itens.

Todas as consultas são parametrizadas. Os métodos recebem o cursor da
transação aberta pelo serviço e não fazem COMMIT.
"""

from __future__ import annotations

from typing import Any

from pymysql.cursors import DictCursor

from app.models.filtros import FiltroRecibos
from app.models.recibo import SITUACAO_CANCELADO, SITUACAO_EMITIDO, ItemRecibo, Recibo, ResumoRecibo
from app.repositories._sql import condicao_nome_ou_documento, texto_ou_nulo

_COLUNAS_RECIBO = (
    "id, emitente_id, ano, numero, cliente_id, data_emissao, subtotal, desconto, total, "
    "observacoes, situacao, motivo_cancelamento, cancelado_em, "
    "cliente_nome, cliente_tipo_pessoa, cliente_documento, cliente_telefone, cliente_endereco, "
    "emitente_nome, emitente_tipo_pessoa, emitente_documento, emitente_telefone, emitente_endereco, "
    "criado_em"
)

_COLUNAS_RESUMO = (
    "id, numero_formatado, emitente_id, ano, numero, cliente_id, cliente_nome, cliente_documento, "
    "data_emissao, subtotal, desconto, total, situacao, recebido, pendente"
)


class ReciboRepository:
    # ------------------------------------------------------------------
    # Numeração segura
    # ------------------------------------------------------------------
    def proximo_numero(self, cur: DictCursor, emitente_id: int, ano: int) -> int:
        """Reserva e devolve o próximo número do emitente no ano.

        DEVE ser chamado dentro da MESMA transação que grava o recibo:
        o SELECT ... FOR UPDATE trava a linha do contador até o COMMIT,
        então emissões simultâneas ficam em fila e nunca repetem número.
        Se a transação sofrer ROLLBACK, o incremento também é desfeito.
        """
        cur.execute(
            "INSERT INTO contadores_recibo (emitente_id, ano, ultimo_numero) VALUES (%s, %s, 0) "
            "ON DUPLICATE KEY UPDATE ultimo_numero = ultimo_numero",
            (emitente_id, ano),
        )
        cur.execute(
            "SELECT ultimo_numero FROM contadores_recibo WHERE emitente_id = %s AND ano = %s FOR UPDATE",
            (emitente_id, ano),
        )
        novo = int(cur.fetchone()["ultimo_numero"]) + 1
        cur.execute(
            "UPDATE contadores_recibo SET ultimo_numero = %s WHERE emitente_id = %s AND ano = %s",
            (novo, emitente_id, ano),
        )
        return novo

    # ------------------------------------------------------------------
    # Gravação
    # ------------------------------------------------------------------
    def inserir(self, cur: DictCursor, recibo: Recibo) -> int:
        """Grava o cabeçalho do recibo (o número já deve ter sido reservado)."""
        cur.execute(
            """
            INSERT INTO recibos
                (emitente_id, ano, numero, cliente_id, data_emissao, subtotal, desconto, total,
                 observacoes, situacao,
                 cliente_nome, cliente_tipo_pessoa, cliente_documento, cliente_telefone, cliente_endereco,
                 emitente_nome, emitente_tipo_pessoa, emitente_documento, emitente_telefone, emitente_endereco)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s,
                    %s, %s,
                    %s, %s, %s, %s, %s,
                    %s, %s, %s, %s, %s)
            """,
            (
                recibo.emitente_id, recibo.ano, recibo.numero, recibo.cliente_id, recibo.data_emissao,
                recibo.subtotal, recibo.desconto, recibo.total,
                texto_ou_nulo(recibo.observacoes), recibo.situacao,
                recibo.cliente_nome, recibo.cliente_tipo_pessoa, recibo.cliente_documento,
                texto_ou_nulo(recibo.cliente_telefone), texto_ou_nulo(recibo.cliente_endereco),
                recibo.emitente_nome, recibo.emitente_tipo_pessoa, recibo.emitente_documento,
                texto_ou_nulo(recibo.emitente_telefone), texto_ou_nulo(recibo.emitente_endereco),
            ),
        )
        recibo.id = cur.lastrowid
        return recibo.id

    def inserir_itens(self, cur: DictCursor, recibo_id: int, itens: list[ItemRecibo]) -> None:
        """Grava os serviços do recibo, numerando a ordem a partir de 1."""
        linhas = []
        for posicao, item in enumerate(itens, start=1):
            item.recibo_id = recibo_id
            item.ordem = posicao
            linhas.append(
                (recibo_id, posicao, item.descricao.strip(), item.quantidade, item.valor_unitario, item.subtotal)
            )
        cur.executemany(
            "INSERT INTO itens_recibo (recibo_id, ordem, descricao, quantidade, valor_unitario, subtotal) "
            "VALUES (%s, %s, %s, %s, %s, %s)",
            linhas,
        )

    def cancelar(self, cur: DictCursor, recibo_id: int, motivo: str) -> bool:
        """Cancelamento lógico. Devolve False se o recibo não existe ou já estava cancelado."""
        cur.execute(
            "UPDATE recibos SET situacao = %s, motivo_cancelamento = %s, cancelado_em = NOW() "
            "WHERE id = %s AND situacao = %s",
            (SITUACAO_CANCELADO, motivo.strip(), recibo_id, SITUACAO_EMITIDO),
        )
        return cur.rowcount > 0

    # ------------------------------------------------------------------
    # Consultas de um recibo
    # ------------------------------------------------------------------
    def obter(self, cur: DictCursor, recibo_id: int, bloquear: bool = False) -> Recibo | None:
        """Cabeçalho do recibo, sem os itens. bloquear=True usa FOR UPDATE."""
        sufixo = " FOR UPDATE" if bloquear else ""
        cur.execute(f"SELECT {_COLUNAS_RECIBO} FROM recibos WHERE id = %s{sufixo}", (recibo_id,))
        linha = cur.fetchone()
        return Recibo.from_row(linha) if linha else None

    def obter_com_itens(self, cur: DictCursor, recibo_id: int) -> Recibo | None:
        recibo = self.obter(cur, recibo_id)
        if recibo is not None:
            recibo.itens = self.listar_itens(cur, recibo_id)
        return recibo

    def obter_por_numero(self, cur: DictCursor, emitente_id: int, ano: int, numero: int) -> Recibo | None:
        cur.execute(
            f"SELECT {_COLUNAS_RECIBO} FROM recibos WHERE emitente_id = %s AND ano = %s AND numero = %s",
            (emitente_id, ano, numero),
        )
        linha = cur.fetchone()
        return Recibo.from_row(linha) if linha else None

    def listar_itens(self, cur: DictCursor, recibo_id: int) -> list[ItemRecibo]:
        cur.execute(
            "SELECT id, recibo_id, ordem, descricao, quantidade, valor_unitario, subtotal "
            "FROM itens_recibo WHERE recibo_id = %s ORDER BY ordem",
            (recibo_id,),
        )
        return [ItemRecibo.from_row(linha) for linha in cur.fetchall()]

    # ------------------------------------------------------------------
    # Listagens e pesquisa (usam a view vw_recibos_resumo)
    # ------------------------------------------------------------------
    @staticmethod
    def _filtro(filtro: FiltroRecibos) -> tuple[str, list[Any]]:
        condicoes: list[str] = []
        parametros: list[Any] = []
        if filtro.numero is not None:
            condicoes.append("numero = %s")
            parametros.append(filtro.numero)
        if filtro.ano is not None:
            condicoes.append("ano = %s")
            parametros.append(filtro.ano)
        cond_cliente, params_cliente = condicao_nome_ou_documento(
            filtro.cliente, "cliente_nome", "cliente_documento"
        )
        if cond_cliente:
            condicoes.append(cond_cliente)
            parametros.extend(params_cliente)
        if filtro.cliente_id is not None:
            condicoes.append("cliente_id = %s")
            parametros.append(filtro.cliente_id)
        if filtro.data_inicio is not None:
            condicoes.append("data_emissao >= %s")
            parametros.append(filtro.data_inicio)
        if filtro.data_fim is not None:
            condicoes.append("data_emissao <= %s")
            parametros.append(filtro.data_fim)
        if filtro.situacao:
            condicoes.append("situacao = %s")
            parametros.append(filtro.situacao)
        where = " WHERE " + " AND ".join(condicoes) if condicoes else ""
        return where, parametros

    def pesquisar(
        self, cur: DictCursor, filtro: FiltroRecibos | None = None, limite: int = 50, deslocamento: int = 0
    ) -> list[ResumoRecibo]:
        """Histórico: mais recentes primeiro."""
        where, parametros = self._filtro(filtro or FiltroRecibos())
        cur.execute(
            f"SELECT {_COLUNAS_RESUMO} FROM vw_recibos_resumo{where} "
            "ORDER BY data_emissao DESC, id DESC LIMIT %s OFFSET %s",
            (*parametros, limite, deslocamento),
        )
        return [ResumoRecibo.from_row(linha) for linha in cur.fetchall()]

    def contar(self, cur: DictCursor, filtro: FiltroRecibos | None = None) -> int:
        where, parametros = self._filtro(filtro or FiltroRecibos())
        cur.execute(f"SELECT COUNT(*) AS total FROM vw_recibos_resumo{where}", parametros)
        return int(cur.fetchone()["total"])

    def ultimos(self, cur: DictCursor, limite: int = 10) -> list[ResumoRecibo]:
        """Últimos recibos emitidos (não cancelados), para o dashboard."""
        cur.execute(
            f"SELECT {_COLUNAS_RESUMO} FROM vw_recibos_resumo WHERE situacao = %s "
            "ORDER BY id DESC LIMIT %s",
            (SITUACAO_EMITIDO, limite),
        )
        return [ResumoRecibo.from_row(linha) for linha in cur.fetchall()]
