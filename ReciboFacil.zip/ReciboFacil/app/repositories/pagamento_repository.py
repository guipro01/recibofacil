"""Repositório de pagamentos dos recibos."""

from __future__ import annotations

from decimal import Decimal

from pymysql.cursors import DictCursor

from app.models.recibo import Pagamento
from app.repositories._sql import texto_ou_nulo


class PagamentoRepository:
    def inserir(self, cur: DictCursor, pagamento: Pagamento) -> int:
        cur.execute(
            "INSERT INTO pagamentos (recibo_id, forma_pagamento_id, valor, data_pagamento, observacoes) "
            "VALUES (%s, %s, %s, %s, %s)",
            (
                pagamento.recibo_id,
                pagamento.forma_pagamento_id,
                pagamento.valor,
                pagamento.data_pagamento,
                texto_ou_nulo(pagamento.observacoes),
            ),
        )
        pagamento.id = cur.lastrowid
        return pagamento.id

    def listar_por_recibo(self, cur: DictCursor, recibo_id: int) -> list[Pagamento]:
        cur.execute(
            "SELECT p.id, p.recibo_id, p.forma_pagamento_id, p.valor, p.data_pagamento, "
            "       p.observacoes, p.criado_em, f.descricao AS forma_descricao "
            "FROM pagamentos p JOIN formas_pagamento f ON f.id = p.forma_pagamento_id "
            "WHERE p.recibo_id = %s ORDER BY p.data_pagamento, p.id",
            (recibo_id,),
        )
        return [Pagamento.from_row(linha) for linha in cur.fetchall()]

    def total_recebido(self, cur: DictCursor, recibo_id: int) -> Decimal:
        cur.execute("SELECT COALESCE(SUM(valor), 0) AS total FROM pagamentos WHERE recibo_id = %s", (recibo_id,))
        return Decimal(cur.fetchone()["total"])
