"""Repositório de configurações gerais (chave/valor)."""

from __future__ import annotations

from pymysql.cursors import DictCursor


class ConfiguracaoRepository:
    def obter(self, cur: DictCursor, chave: str, padrao: str | None = None) -> str | None:
        cur.execute("SELECT valor FROM configuracoes WHERE chave = %s", (chave,))
        linha = cur.fetchone()
        if linha is None or linha["valor"] is None:
            return padrao
        return str(linha["valor"])

    def definir(self, cur: DictCursor, chave: str, valor: str | None, descricao: str | None = None) -> None:
        """Cria ou atualiza a configuração (a descrição existente é mantida se não informada)."""
        cur.execute(
            "INSERT INTO configuracoes (chave, valor, descricao) VALUES (%s, %s, %s) "
            "ON DUPLICATE KEY UPDATE valor = VALUES(valor), descricao = COALESCE(VALUES(descricao), descricao)",
            (chave, valor, descricao),
        )

    def listar(self, cur: DictCursor) -> dict[str, str | None]:
        cur.execute("SELECT chave, valor FROM configuracoes ORDER BY chave")
        return {linha["chave"]: linha["valor"] for linha in cur.fetchall()}
