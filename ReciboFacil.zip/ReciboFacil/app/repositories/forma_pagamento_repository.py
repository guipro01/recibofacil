"""Repositório de formas de pagamento."""

from __future__ import annotations

from pymysql.cursors import DictCursor

from app.models.forma_pagamento import FormaPagamento


class FormaPagamentoRepository:
    def listar(self, cur: DictCursor, somente_ativas: bool = True) -> list[FormaPagamento]:
        where = " WHERE ativo = 1" if somente_ativas else ""
        cur.execute(f"SELECT id, descricao, ativo FROM formas_pagamento{where} ORDER BY descricao")
        return [FormaPagamento.from_row(linha) for linha in cur.fetchall()]

    def obter(self, cur: DictCursor, forma_id: int) -> FormaPagamento | None:
        cur.execute("SELECT id, descricao, ativo FROM formas_pagamento WHERE id = %s", (forma_id,))
        linha = cur.fetchone()
        return FormaPagamento.from_row(linha) if linha else None

    def inserir(self, cur: DictCursor, forma: FormaPagamento) -> int:
        cur.execute(
            "INSERT INTO formas_pagamento (descricao, ativo) VALUES (%s, %s)",
            (forma.descricao.strip(), int(forma.ativo)),
        )
        forma.id = cur.lastrowid
        return forma.id

    def definir_ativo(self, cur: DictCursor, forma_id: int, ativo: bool) -> bool:
        cur.execute("UPDATE formas_pagamento SET ativo = %s WHERE id = %s", (int(ativo), forma_id))
        return cur.rowcount > 0
