"""Repositório de clientes."""

from __future__ import annotations

from typing import ClassVar

from pymysql.cursors import DictCursor

from app.models.cliente import Cliente
from app.repositories.pessoa_repository import PessoaRepository


class ClienteRepository(PessoaRepository):
    TABELA: ClassVar[str] = "clientes"
    MODELO: ClassVar[type[Cliente]] = Cliente

    def obter(self, cur: DictCursor, pessoa_id: int, bloquear: bool = False) -> Cliente | None:  # type: ignore[override]
        return super().obter(cur, pessoa_id, bloquear)  # type: ignore[return-value]

    def obter_por_documento(self, cur: DictCursor, documento: str) -> Cliente | None:  # type: ignore[override]
        return super().obter_por_documento(cur, documento)  # type: ignore[return-value]
