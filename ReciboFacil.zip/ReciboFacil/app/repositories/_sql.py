"""Auxiliares de SQL compartilhados pelos repositórios."""

from __future__ import annotations

from app.utils.formatadores import normalizar_documento


def padrao_like(termo: str) -> str:
    """Monta um padrão LIKE 'contém', tratando %, _ e \\ digitados como texto comum."""
    escapado = termo.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escapado}%"


def condicao_nome_ou_documento(
    termo: str | None, coluna_nome: str, coluna_documento: str
) -> tuple[str, list[str]]:
    """Condição de pesquisa por nome ou CPF/CNPJ. Devolve ('', []) quando não há termo.

    As colunas vêm sempre do código (nunca do usuário); o termo vai por parâmetro.
    """
    texto = (termo or "").strip()
    if not texto:
        return "", []
    condicao = f"({coluna_nome} LIKE %s"
    parametros = [padrao_like(texto)]
    # Só pesquisa por documento quando o termo tem algum dígito (evita casar nomes com letras de CNPJ).
    documento = normalizar_documento(texto)
    if documento and any(c.isdigit() for c in documento):
        condicao += f" OR {coluna_documento} LIKE %s"
        parametros.append(padrao_like(documento))
    return condicao + ")", parametros


def texto_ou_nulo(valor: str | None) -> str | None:
    """Converte texto vazio em NULL e remove espaços das pontas."""
    if valor is None:
        return None
    limpo = valor.strip()
    return limpo or None
