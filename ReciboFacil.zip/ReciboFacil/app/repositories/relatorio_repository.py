"""Consultas de relatórios e do dashboard (somente leitura)."""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Any

from pymysql.cursors import DictCursor

from app.repositories._sql import condicao_nome_ou_documento


def _periodo(inicio: date | None, fim: date | None, coluna: str) -> tuple[list[str], list[Any]]:
    condicoes: list[str] = []
    parametros: list[Any] = []
    if inicio is not None:
        condicoes.append(f"{coluna} >= %s")
        parametros.append(inicio)
    if fim is not None:
        condicoes.append(f"{coluna} <= %s")
        parametros.append(fim)
    return condicoes, parametros


def _primeiro_e_ultimo_dia(referencia: date) -> tuple[date, date]:
    primeiro = referencia.replace(day=1)
    proximo = date(primeiro.year + (primeiro.month == 12), primeiro.month % 12 + 1, 1)
    return primeiro, proximo.fromordinal(proximo.toordinal() - 1)


class RelatorioRepository:
    # ------------------------------------------------------------------
    # Dashboard
    # ------------------------------------------------------------------
    def resumo_dashboard(self, cur: DictCursor, hoje: date) -> dict[str, Any]:
        """Totais gerais e do mês de `hoje`. Recibos cancelados ficam de fora dos valores."""
        primeiro, ultimo = _primeiro_e_ultimo_dia(hoje)
        cur.execute(
            """
            SELECT COUNT(*)                                                      AS total_recibos,
                   COALESCE(SUM(total), 0)                                       AS valor_emitido,
                   COALESCE(SUM(data_emissao BETWEEN %s AND %s), 0)              AS recibos_mes,
                   COALESCE(SUM(CASE WHEN data_emissao BETWEEN %s AND %s
                                     THEN total ELSE 0 END), 0)                  AS valor_mes
            FROM recibos
            WHERE situacao = 'EMITIDO'
            """,
            (primeiro, ultimo, primeiro, ultimo),
        )
        resumo = cur.fetchone()
        cur.execute("SELECT COUNT(*) AS cancelados FROM recibos WHERE situacao = 'CANCELADO'")
        cancelados = cur.fetchone()["cancelados"]
        cur.execute(
            "SELECT COALESCE(SUM(recebido), 0) AS recebido, COALESCE(SUM(pendente), 0) AS pendente "
            "FROM vw_recibos_resumo WHERE situacao = 'EMITIDO'"
        )
        valores = cur.fetchone()
        return {
            "total_recibos": int(resumo["total_recibos"]),
            "valor_emitido": Decimal(resumo["valor_emitido"]),
            "recibos_mes": int(resumo["recibos_mes"]),
            "valor_mes": Decimal(resumo["valor_mes"]),
            "recibos_cancelados": int(cancelados),
            "valor_recebido": Decimal(valores["recebido"]),
            "valor_pendente": Decimal(valores["pendente"]),
        }

    # ------------------------------------------------------------------
    # Relatórios
    # ------------------------------------------------------------------
    def total_por_mes(self, cur: DictCursor, ano: int | None = None) -> list[dict[str, Any]]:
        """Quantidade e total emitido por mês (recibos não cancelados)."""
        condicoes = ["situacao = 'EMITIDO'"]
        parametros: list[Any] = []
        if ano is not None:
            condicoes.append("data_emissao >= %s AND data_emissao <= %s")
            parametros.extend([date(ano, 1, 1), date(ano, 12, 31)])
        cur.execute(
            "SELECT DATE_FORMAT(data_emissao, '%%Y-%%m') AS mes, COUNT(*) AS quantidade, "
            "       SUM(total) AS total_emitido "
            f"FROM recibos WHERE {' AND '.join(condicoes)} "
            "GROUP BY DATE_FORMAT(data_emissao, '%%Y-%%m') ORDER BY mes DESC",
            parametros,
        )
        return list(cur.fetchall())

    def clientes_com_total_recibos(
        self,
        cur: DictCursor,
        termo: str | None = None,
        ativo: bool | None = None,
        limite: int = 50,
        deslocamento: int = 0,
    ) -> list[dict[str, Any]]:
        """Clientes com a quantidade de recibos emitidos e o total (não cancelados)."""
        condicoes: list[str] = []
        parametros: list[Any] = []
        cond_termo, params_termo = condicao_nome_ou_documento(termo, "c.nome", "c.documento")
        if cond_termo:
            condicoes.append(cond_termo)
            parametros.extend(params_termo)
        if ativo is not None:
            condicoes.append("c.ativo = %s")
            parametros.append(int(ativo))
        where = " WHERE " + " AND ".join(condicoes) if condicoes else ""
        cur.execute(
            "SELECT c.id, c.nome, c.documento, c.telefone, c.cidade, c.uf, c.ativo, "
            "       COUNT(r.id) AS qtd_recibos, "
            "       COALESCE(SUM(CASE WHEN r.situacao = 'EMITIDO' THEN r.total END), 0) AS total_emitido "
            f"FROM clientes c LEFT JOIN recibos r ON r.cliente_id = c.id{where} "
            "GROUP BY c.id, c.nome, c.documento, c.telefone, c.cidade, c.uf, c.ativo "
            "ORDER BY c.nome, c.id LIMIT %s OFFSET %s",
            (*parametros, limite, deslocamento),
        )
        return list(cur.fetchall())

    def total_por_cliente(
        self, cur: DictCursor, inicio: date | None = None, fim: date | None = None
    ) -> list[dict[str, Any]]:
        condicoes, parametros = _periodo(inicio, fim, "data_emissao")
        condicoes.insert(0, "situacao = 'EMITIDO'")
        cur.execute(
            "SELECT cliente_id, cliente_nome, COUNT(*) AS quantidade, SUM(total) AS total_emitido "
            f"FROM recibos WHERE {' AND '.join(condicoes)} "
            "GROUP BY cliente_id, cliente_nome ORDER BY total_emitido DESC",
            parametros,
        )
        return list(cur.fetchall())

    def total_por_forma_pagamento(
        self, cur: DictCursor, inicio: date | None = None, fim: date | None = None
    ) -> list[dict[str, Any]]:
        condicoes, parametros = _periodo(inicio, fim, "p.data_pagamento")
        condicoes.insert(0, "r.situacao = 'EMITIDO'")
        cur.execute(
            "SELECT f.descricao AS forma_pagamento, COUNT(p.id) AS quantidade, SUM(p.valor) AS total_recebido "
            "FROM pagamentos p "
            "JOIN formas_pagamento f ON f.id = p.forma_pagamento_id "
            "JOIN recibos r ON r.id = p.recibo_id "
            f"WHERE {' AND '.join(condicoes)} "
            "GROUP BY f.id, f.descricao ORDER BY total_recebido DESC",
            parametros,
        )
        return list(cur.fetchall())

    def recibos_cancelados(
        self, cur: DictCursor, inicio: date | None = None, fim: date | None = None
    ) -> list[dict[str, Any]]:
        condicoes, parametros = _periodo(inicio, fim, "data_emissao")
        condicoes.insert(0, "situacao = 'CANCELADO'")
        cur.execute(
            "SELECT id, ano, numero, cliente_nome, data_emissao, total, cancelado_em, motivo_cancelamento "
            f"FROM recibos WHERE {' AND '.join(condicoes)} ORDER BY cancelado_em DESC",
            parametros,
        )
        return list(cur.fetchall())
