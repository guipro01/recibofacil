"""Repositório base para tabelas de pessoas (clientes e emitentes)."""

from __future__ import annotations

from typing import Any, ClassVar

from pymysql.cursors import DictCursor

from app.models.pessoa import CAMPOS_PESSOA, Pessoa
from app.repositories._sql import condicao_nome_ou_documento, texto_ou_nulo

_OBRIGATORIOS = ("nome", "tipo_pessoa", "documento")


class PessoaRepository:
    """Operações comuns de cadastro. As subclasses definem TABELA e MODELO."""

    TABELA: ClassVar[str]
    MODELO: ClassVar[type[Pessoa]]

    _SELECT = "id, " + ", ".join(CAMPOS_PESSOA) + ", ativo, criado_em, atualizado_em"

    @staticmethod
    def _valores(pessoa: Pessoa) -> list[Any]:
        """Valores na ordem de CAMPOS_PESSOA; textos opcionais vazios viram NULL."""
        valores = []
        for campo in CAMPOS_PESSOA:
            valor = getattr(pessoa, campo)
            valores.append(valor if campo in _OBRIGATORIOS else texto_ou_nulo(valor))
        return valores

    def inserir(self, cur: DictCursor, pessoa: Pessoa) -> int:
        colunas = ", ".join((*CAMPOS_PESSOA, "ativo"))
        marcadores = ", ".join(["%s"] * (len(CAMPOS_PESSOA) + 1))
        cur.execute(
            f"INSERT INTO {self.TABELA} ({colunas}) VALUES ({marcadores})",
            (*self._valores(pessoa), int(pessoa.ativo)),
        )
        pessoa.id = cur.lastrowid
        return pessoa.id

    def atualizar(self, cur: DictCursor, pessoa: Pessoa) -> bool:
        """Atualiza os dados cadastrais. Devolve False se o registro não existe."""
        if pessoa.id is None:
            raise ValueError("Não é possível atualizar um cadastro sem id.")
        atribuicoes = ", ".join(f"{campo} = %s" for campo in CAMPOS_PESSOA)
        cur.execute(
            f"UPDATE {self.TABELA} SET {atribuicoes}, ativo = %s WHERE id = %s",
            (*self._valores(pessoa), int(pessoa.ativo), pessoa.id),
        )
        return cur.rowcount > 0

    def definir_ativo(self, cur: DictCursor, pessoa_id: int, ativo: bool) -> bool:
        """Ativa ou desativa (exclusão lógica). Devolve False se não existe."""
        cur.execute(f"UPDATE {self.TABELA} SET ativo = %s WHERE id = %s", (int(ativo), pessoa_id))
        return cur.rowcount > 0

    def obter(self, cur: DictCursor, pessoa_id: int, bloquear: bool = False) -> Pessoa | None:
        """Busca por id. Com bloquear=True usa FOR UPDATE (dentro de uma transação)."""
        sufixo = " FOR UPDATE" if bloquear else ""
        cur.execute(f"SELECT {self._SELECT} FROM {self.TABELA} WHERE id = %s{sufixo}", (pessoa_id,))
        linha = cur.fetchone()
        return self.MODELO.from_row(linha) if linha else None

    def obter_por_documento(self, cur: DictCursor, documento: str) -> Pessoa | None:
        cur.execute(f"SELECT {self._SELECT} FROM {self.TABELA} WHERE documento = %s", (documento,))
        linha = cur.fetchone()
        return self.MODELO.from_row(linha) if linha else None

    def _filtro(self, termo: str | None, ativo: bool | None) -> tuple[str, list[Any]]:
        condicoes: list[str] = []
        parametros: list[Any] = []
        cond_termo, params_termo = condicao_nome_ou_documento(termo, "nome", "documento")
        if cond_termo:
            condicoes.append(cond_termo)
            parametros.extend(params_termo)
        if ativo is not None:
            condicoes.append("ativo = %s")
            parametros.append(int(ativo))
        where = " WHERE " + " AND ".join(condicoes) if condicoes else ""
        return where, parametros

    def pesquisar(
        self,
        cur: DictCursor,
        termo: str | None = None,
        ativo: bool | None = None,
        limite: int = 50,
        deslocamento: int = 0,
    ) -> list[Pessoa]:
        """Pesquisa por parte do nome ou do CPF/CNPJ, ordenada por nome."""
        where, parametros = self._filtro(termo, ativo)
        cur.execute(
            f"SELECT {self._SELECT} FROM {self.TABELA}{where} ORDER BY nome, id LIMIT %s OFFSET %s",
            (*parametros, limite, deslocamento),
        )
        return [self.MODELO.from_row(linha) for linha in cur.fetchall()]

    def contar(self, cur: DictCursor, termo: str | None = None, ativo: bool | None = None) -> int:
        where, parametros = self._filtro(termo, ativo)
        cur.execute(f"SELECT COUNT(*) AS total FROM {self.TABELA}{where}", parametros)
        return int(cur.fetchone()["total"])
