"""Repositório do histórico (auditoria) de operações."""

from __future__ import annotations

import json
from typing import Any

from pymysql.cursors import DictCursor


def _serializar(dados: dict[str, Any] | None) -> str | None:
    """JSON legível (UTF-8). Decimal, date e datetime viram texto."""
    if dados is None:
        return None
    return json.dumps(dados, ensure_ascii=False, default=str)


class HistoricoRepository:
    def registrar(
        self,
        cur: DictCursor,
        entidade: str,
        entidade_id: int | None,
        operacao: str,
        descricao: str | None = None,
        dados_anteriores: dict[str, Any] | None = None,
        dados_novos: dict[str, Any] | None = None,
    ) -> int:
        """Registra uma operação. Use o mesmo cursor da transação principal."""
        cur.execute(
            "INSERT INTO historico_operacoes "
            "(entidade, entidade_id, operacao, descricao, dados_anteriores, dados_novos) "
            "VALUES (%s, %s, %s, %s, %s, %s)",
            (entidade, entidade_id, operacao, descricao, _serializar(dados_anteriores), _serializar(dados_novos)),
        )
        return cur.lastrowid

    def listar_por_entidade(
        self, cur: DictCursor, entidade: str, entidade_id: int, limite: int = 100
    ) -> list[dict[str, Any]]:
        cur.execute(
            "SELECT id, entidade, entidade_id, operacao, descricao, dados_anteriores, dados_novos, criado_em "
            "FROM historico_operacoes WHERE entidade = %s AND entidade_id = %s "
            "ORDER BY id DESC LIMIT %s",
            (entidade, entidade_id, limite),
        )
        return list(cur.fetchall())
