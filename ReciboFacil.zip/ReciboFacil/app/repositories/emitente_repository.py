"""Repositório de emitentes."""

from __future__ import annotations

from typing import ClassVar

from pymysql.cursors import DictCursor

from app.models.emitente import Emitente
from app.repositories.pessoa_repository import PessoaRepository


class EmitenteRepository(PessoaRepository):
    TABELA: ClassVar[str] = "emitentes"
    MODELO: ClassVar[type[Emitente]] = Emitente

    def obter(self, cur: DictCursor, pessoa_id: int, bloquear: bool = False) -> Emitente | None:  # type: ignore[override]
        return super().obter(cur, pessoa_id, bloquear)  # type: ignore[return-value]

    def obter_padrao(self, cur: DictCursor) -> Emitente | None:
        """Primeiro emitente ativo (o sistema usa um emitente por padrão)."""
        cur.execute(f"SELECT {self._SELECT} FROM emitentes WHERE ativo = 1 ORDER BY id LIMIT 1")
        linha = cur.fetchone()
        return Emitente.from_row(linha) if linha else None
