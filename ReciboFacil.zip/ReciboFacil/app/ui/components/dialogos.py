"""Mensagens, confirmações e tratamento de erros exibidos ao usuário."""

from __future__ import annotations

from collections.abc import Callable
from tkinter import messagebox
from typing import Any

import customtkinter as ctk

from app.core.exceptions import ReciboFacilError, ValidacaoError
from app.core.logger import get_logger
from app.ui import theme

log = get_logger(__name__)


def aviso(pai, mensagem: str, titulo: str = "Atenção") -> None:
    messagebox.showwarning(titulo, mensagem, parent=pai)


def informacao(pai, mensagem: str, titulo: str = "ReciboFácil") -> None:
    messagebox.showinfo(titulo, mensagem, parent=pai)


def confirmar(pai, mensagem: str, titulo: str = "Confirmar") -> bool:
    return messagebox.askyesno(titulo, mensagem, parent=pai)


def tratar_excecao(pai, exc: BaseException) -> None:
    """Mostra uma mensagem clara para o usuário; erros inesperados vão para o log."""
    if isinstance(exc, ValidacaoError):
        if len(exc.erros) == 1:
            aviso(pai, exc.erros[0], "Verifique os dados")
        else:
            aviso(pai, "\n".join(f"• {e}" for e in exc.erros), "Verifique os dados")
    elif isinstance(exc, ReciboFacilError):
        if exc.detalhe:
            log.warning("%s | detalhe: %s", exc.mensagem, exc.detalhe)
        messagebox.showerror("Não foi possível concluir", exc.mensagem, parent=pai)
    else:
        log.error("Erro inesperado", exc_info=exc)
        messagebox.showerror(
            "Erro inesperado",
            "Ocorreu um erro inesperado. Os detalhes foram gravados no arquivo de log (pasta 'logs').",
            parent=pai,
        )


def executar(pai, funcao: Callable[..., Any], *args, **kwargs) -> tuple[bool, Any]:
    """Executa a função tratando qualquer erro. Devolve (sucesso, resultado)."""
    try:
        return True, funcao(*args, **kwargs)
    except Exception as exc:  # noqa: BLE001 - a interface precisa exibir qualquer falha ao usuário
        tratar_excecao(pai, exc)
        return False, None


class Dialogo(ctk.CTkToplevel):
    """Janela modal centralizada sobre a janela que a abriu."""

    def __init__(self, pai, titulo: str, largura: int, altura: int) -> None:
        super().__init__(pai)
        self._pai = pai.winfo_toplevel()
        self.title(titulo)
        self.configure(fg_color=theme.COR_FUNDO)
        self.resizable(False, False)
        self.transient(self._pai)
        self._posicionar(largura, altura)
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.bind("<Escape>", lambda _e: self.destroy())
        self.after(120, self._ativar)

    def _posicionar(self, largura: int, altura: int) -> None:
        self._pai.update_idletasks()
        x = self._pai.winfo_rootx() + max(0, (self._pai.winfo_width() - largura) // 2)
        y = self._pai.winfo_rooty() + max(0, (self._pai.winfo_height() - altura) // 3)
        self.geometry(f"{largura}x{altura}+{x}+{y}")

    def _ativar(self) -> None:
        if not self.winfo_exists():
            return
        try:
            self.grab_set()
            self.focus_force()
        except Exception:  # noqa: BLE001 - janela pode ter sido fechada antes de ficar visível
            pass


class DialogoTexto(Dialogo):
    """Pede um texto (ex.: motivo do cancelamento). `resultado` fica None se cancelado."""

    def __init__(self, pai, titulo: str, mensagem: str, rotulo_confirmar: str = "Confirmar", perigo: bool = False) -> None:
        super().__init__(pai, titulo, 480, 300)
        self.resultado: str | None = None
        corpo = ctk.CTkFrame(self, fg_color=theme.COR_CARTAO, corner_radius=10)
        corpo.pack(fill="both", expand=True, padx=16, pady=16)
        ctk.CTkLabel(corpo, text=mensagem, font=theme.fonte(13), justify="left", wraplength=420,
                     text_color=theme.COR_TEXTO).pack(anchor="w", padx=16, pady=(16, 8))
        self._caixa = ctk.CTkTextbox(corpo, height=100, font=theme.fonte(13), border_width=1,
                                     border_color=theme.COR_BORDA, fg_color="white")
        self._caixa.pack(fill="x", padx=16)
        botoes = ctk.CTkFrame(corpo, fg_color="transparent")
        botoes.pack(fill="x", padx=16, pady=16, side="bottom")
        ctk.CTkButton(botoes, text="Voltar", width=100, command=self.destroy, **theme.estilo_botao("neutro")).pack(side="right", padx=(8, 0))
        ctk.CTkButton(botoes, text=rotulo_confirmar, width=140, command=self._confirmar,
                      **theme.estilo_botao("perigo" if perigo else "primario")).pack(side="right")
        self.after(200, self._caixa.focus_set)

    def _confirmar(self) -> None:
        self.resultado = self._caixa.get("1.0", "end").strip()
        self.destroy()


def pedir_texto(pai, titulo: str, mensagem: str, rotulo_confirmar: str = "Confirmar", perigo: bool = False) -> str | None:
    """Abre o diálogo e espera. Devolve o texto digitado ou None se o usuário voltou."""
    dialogo = DialogoTexto(pai, titulo, mensagem, rotulo_confirmar, perigo)
    pai.winfo_toplevel().wait_window(dialogo)
    return dialogo.resultado
