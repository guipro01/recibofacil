"""Tabela (Treeview) estilizada com barra de rolagem e linhas zebradas."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass
from tkinter import ttk

import customtkinter as ctk

from app.ui import theme

_estilo_aplicado = False


def _aplicar_estilo() -> None:
    global _estilo_aplicado
    if _estilo_aplicado:
        return
    estilo = ttk.Style()
    estilo.theme_use("clam")
    estilo.configure(
        "Recibo.Treeview", background="white", fieldbackground="white", foreground=theme.COR_TEXTO,
        rowheight=30, borderwidth=0, font=(theme.FAMILIA, 10),
    )
    estilo.map("Recibo.Treeview", background=[("selected", theme.COR_PRIMARIA)], foreground=[("selected", "white")])
    estilo.configure(
        "Recibo.Treeview.Heading", background=theme.COR_SIDEBAR, foreground="white", relief="flat",
        font=(theme.FAMILIA, 10, "bold"), padding=(8, 7),
    )
    estilo.map("Recibo.Treeview.Heading", background=[("active", theme.COR_SIDEBAR_HOVER)])
    _estilo_aplicado = True


@dataclass(frozen=True)
class Coluna:
    id: str
    titulo: str
    largura: int = 100
    ancora: str = "w"  # 'w' esquerda, 'e' direita, 'center'
    esticar: bool = False


class Tabela(ctk.CTkFrame):
    """Cada linha tem uma chave (ex.: id do registro) recuperada por `selecionado()`."""

    def __init__(
        self,
        master,
        colunas: Sequence[Coluna],
        altura: int = 10,
        ao_duplo_clique: Callable[[str], None] | None = None,
        ao_selecionar: Callable[[str | None], None] | None = None,
    ) -> None:
        super().__init__(master, fg_color="white", corner_radius=8, border_width=1, border_color=theme.COR_BORDA)
        _aplicar_estilo()
        self._ao_duplo_clique = ao_duplo_clique
        self._ao_selecionar = ao_selecionar

        self._arvore = ttk.Treeview(
            self, columns=[c.id for c in colunas], show="headings", height=altura,
            style="Recibo.Treeview", selectmode="browse",
        )
        for coluna in colunas:
            self._arvore.heading(coluna.id, text=coluna.titulo, anchor="w" if coluna.ancora == "w" else coluna.ancora)
            largura = min(coluna.largura, 120) if coluna.esticar else coluna.largura
            self._arvore.column(coluna.id, width=largura, minwidth=50, anchor=coluna.ancora, stretch=coluna.esticar)
        self._arvore.tag_configure("impar", background=theme.COR_LINHA_ZEBRA)
        self._arvore.tag_configure("inativo", foreground="#9CA3AF")
        self._arvore.tag_configure("cancelado", foreground=theme.COR_PERIGO)

        rolagem = ctk.CTkScrollbar(self, command=self._arvore.yview, height=1)  # height=1: sem altura mínima de 200 px
        self._arvore.configure(yscrollcommand=rolagem.set)
        self._arvore.pack(side="left", fill="both", expand=True, padx=(2, 0), pady=2)
        rolagem.pack(side="right", fill="y", padx=(0, 2), pady=2)

        self._arvore.bind("<Double-1>", self._duplo_clique)
        self._arvore.bind("<<TreeviewSelect>>", lambda _e: self._ao_selecionar and self._ao_selecionar(self.selecionado()))

    def carregar(self, linhas: Sequence[tuple[object, Sequence[object], str | None]]) -> None:
        """Substitui o conteúdo. Cada linha é (chave, valores, tag opcional)."""
        self._arvore.delete(*self._arvore.get_children())
        for posicao, (chave, valores, tag) in enumerate(linhas):
            tags = tuple(t for t in ("impar" if posicao % 2 else None, tag) if t)
            self._arvore.insert("", "end", iid=str(chave), values=list(valores), tags=tags)
        if self._ao_selecionar:
            self._ao_selecionar(None)

    def selecionado(self) -> str | None:
        selecao = self._arvore.selection()
        return selecao[0] if selecao else None

    def total_linhas(self) -> int:
        return len(self._arvore.get_children())

    def _duplo_clique(self, evento) -> None:
        if self._ao_duplo_clique and self._arvore.identify_row(evento.y):
            chave = self.selecionado()
            if chave:
                self._ao_duplo_clique(chave)
