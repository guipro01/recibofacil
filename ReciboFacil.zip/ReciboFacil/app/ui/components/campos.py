"""Campos de formulário reutilizáveis (rótulo + entrada, com máscara opcional)."""

from __future__ import annotations

from collections.abc import Callable, Sequence

import customtkinter as ctk

from app.ui import theme


class Campo(ctk.CTkFrame):
    """Rótulo acima de uma caixa de texto. A máscara é reaplicada a cada tecla."""

    def __init__(
        self,
        master,
        rotulo: str,
        largura: int = 200,
        placeholder: str = "",
        mascara: Callable[[str], str] | None = None,
        obrigatorio: bool = False,
        ao_alterar: Callable[[], None] | None = None,
    ) -> None:
        super().__init__(master, fg_color="transparent")
        texto = f"{rotulo} *" if obrigatorio else rotulo
        ctk.CTkLabel(self, text=texto, font=theme.fonte(12), text_color=theme.COR_TEXTO_SUAVE, anchor="w").pack(anchor="w")
        self.entrada = ctk.CTkEntry(
            self, width=largura, height=34, placeholder_text=placeholder, font=theme.fonte(13),
            border_color=theme.COR_BORDA, fg_color="white", text_color=theme.COR_TEXTO,
        )
        self.entrada.pack(anchor="w", pady=(2, 0), fill="x")
        self._mascara = mascara
        self._ao_alterar = ao_alterar
        if mascara or ao_alterar:
            self.entrada.bind("<KeyRelease>", self._tecla)

    def _tecla(self, _evento=None) -> None:
        if self._mascara:
            atual = self.entrada.get()
            novo = self._mascara(atual)
            if novo != atual:
                self.entrada.delete(0, "end")
                self.entrada.insert(0, novo)
        if self._ao_alterar:
            self._ao_alterar()

    def obter(self) -> str:
        return self.entrada.get().strip()

    def definir(self, texto: str | None) -> None:
        estado = self.entrada.cget("state")
        self.entrada.configure(state="normal")
        self.entrada.delete(0, "end")
        self.entrada.insert(0, texto or "")
        if self._mascara:
            self._tecla()
        self.entrada.configure(state=estado)

    def limpar(self) -> None:
        self.definir("")

    def bloquear(self, bloqueado: bool = True) -> None:
        self.entrada.configure(state="disabled" if bloqueado else "normal")

    def focar(self) -> None:
        self.entrada.focus_set()


class CampoLista(ctk.CTkFrame):
    """Rótulo acima de uma lista de opções (somente escolha)."""

    def __init__(self, master, rotulo: str, valores: Sequence[str], largura: int = 200, ao_alterar: Callable[[str], None] | None = None) -> None:
        super().__init__(master, fg_color="transparent")
        ctk.CTkLabel(self, text=rotulo, font=theme.fonte(12), text_color=theme.COR_TEXTO_SUAVE, anchor="w").pack(anchor="w")
        self.lista = ctk.CTkOptionMenu(
            self, values=list(valores) or [""], width=largura, height=34, font=theme.fonte(13),
            dropdown_font=theme.fonte(13), fg_color="white", button_color=theme.COR_NEUTRA,
            button_hover_color=theme.COR_NEUTRA_HOVER, text_color=theme.COR_TEXTO, command=ao_alterar,
        )
        self.lista.pack(anchor="w", pady=(2, 0), fill="x")

    def obter(self) -> str:
        return self.lista.get()

    def definir(self, valor: str) -> None:
        self.lista.set(valor)

    def definir_opcoes(self, valores: Sequence[str]) -> None:
        self.lista.configure(values=list(valores) or [""])

    def bloquear(self, bloqueado: bool = True) -> None:
        self.lista.configure(state="disabled" if bloqueado else "normal")


class Paginador(ctk.CTkFrame):
    """Controles Anterior/Próxima com o resumo da paginação."""

    def __init__(self, master, ao_mudar: Callable[[int], None]) -> None:
        super().__init__(master, fg_color="transparent")
        self._ao_mudar = ao_mudar
        self._pagina = 1
        self._total_paginas = 1
        self._anterior = ctk.CTkButton(self, text="‹ Anterior", width=90, command=lambda: self._ir(self._pagina - 1), **theme.estilo_botao("neutro"))
        self._proxima = ctk.CTkButton(self, text="Próxima ›", width=90, command=lambda: self._ir(self._pagina + 1), **theme.estilo_botao("neutro"))
        self._rotulo = ctk.CTkLabel(self, text="", font=theme.fonte(12), text_color=theme.COR_TEXTO_SUAVE)
        self._anterior.pack(side="left")
        self._rotulo.pack(side="left", padx=12)
        self._proxima.pack(side="left")

    def _ir(self, pagina: int) -> None:
        if 1 <= pagina <= self._total_paginas:
            self._ao_mudar(pagina)

    def atualizar(self, pagina: int, total_paginas: int, total: int, descricao: str = "registros") -> None:
        self._pagina, self._total_paginas = pagina, total_paginas
        self._rotulo.configure(text=f"Página {pagina} de {total_paginas}  •  {total} {descricao}")
        self._anterior.configure(state="normal" if pagina > 1 else "disabled")
        self._proxima.configure(state="normal" if pagina < total_paginas else "disabled")


class CartaoIndicador(ctk.CTkFrame):
    """Cartão do dashboard: título pequeno, valor grande e detalhe opcional."""

    def __init__(self, master, titulo: str, cor: str = theme.COR_PRIMARIA) -> None:
        super().__init__(master, fg_color=theme.COR_CARTAO, corner_radius=10, border_width=1, border_color=theme.COR_BORDA)
        ctk.CTkFrame(self, width=5, height=1, fg_color=cor, corner_radius=3).pack(side="left", fill="y", padx=(8, 0), pady=10)
        corpo = ctk.CTkFrame(self, fg_color="transparent")
        corpo.pack(side="left", fill="both", expand=True, padx=12, pady=10)
        ctk.CTkLabel(corpo, text=titulo, font=theme.fonte(12), text_color=theme.COR_TEXTO_SUAVE, anchor="w").pack(anchor="w")
        self._valor = ctk.CTkLabel(corpo, text="—", font=theme.fonte(22, True), text_color=theme.COR_TEXTO, anchor="w")
        self._valor.pack(anchor="w")
        self._detalhe = ctk.CTkLabel(corpo, text="", font=theme.fonte(11), text_color=theme.COR_TEXTO_SUAVE, anchor="w")
        self._detalhe.pack(anchor="w")

    def definir(self, valor: str, detalhe: str = "") -> None:
        self._valor.configure(text=valor)
        self._detalhe.configure(text=detalhe)
