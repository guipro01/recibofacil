"""Formulário de cadastro de pessoa (cliente ou emitente) reutilizado em várias telas."""

from __future__ import annotations

from typing import TypeVar

import customtkinter as ctk

from app.models.pessoa import Pessoa
from app.ui import theme
from app.ui.components.campos import Campo, CampoLista
from app.utils.formatadores import formatar_cep, formatar_cpf_cnpj, formatar_telefone, mascara_cep, mascara_documento, mascara_telefone
from app.validators.pessoa import UFS

P = TypeVar("P", bound=Pessoa)


class FormularioPessoa(ctk.CTkFrame):
    def __init__(self, master, rotulo_nome: str = "Nome") -> None:
        super().__init__(master, fg_color="transparent")
        self.columnconfigure((0, 1, 2), weight=1, uniform="col")

        self.nome = Campo(self, rotulo_nome, obrigatorio=True)
        self.documento = Campo(self, "CPF / CNPJ", obrigatorio=True, mascara=mascara_documento, placeholder="000.000.000-00")
        self.telefone = Campo(self, "Telefone", mascara=mascara_telefone, placeholder="(00) 00000-0000")
        self.email = Campo(self, "E-mail")
        self.cep = Campo(self, "CEP", mascara=mascara_cep, placeholder="00000-000")
        self.logradouro = Campo(self, "Logradouro")
        self.numero = Campo(self, "Número")
        self.complemento = Campo(self, "Complemento")
        self.bairro = Campo(self, "Bairro")
        self.cidade = Campo(self, "Cidade")
        self.uf = CampoLista(self, "UF", ["", *sorted(UFS)])

        self.nome.grid(row=0, column=0, columnspan=2, sticky="ew", padx=6, pady=6)
        self.documento.grid(row=0, column=2, sticky="ew", padx=6, pady=6)
        self.telefone.grid(row=1, column=0, sticky="ew", padx=6, pady=6)
        self.email.grid(row=1, column=1, columnspan=2, sticky="ew", padx=6, pady=6)
        self.cep.grid(row=2, column=0, sticky="ew", padx=6, pady=6)
        self.logradouro.grid(row=2, column=1, columnspan=2, sticky="ew", padx=6, pady=6)
        self.numero.grid(row=3, column=0, sticky="ew", padx=6, pady=6)
        self.complemento.grid(row=3, column=1, columnspan=2, sticky="ew", padx=6, pady=6)
        self.bairro.grid(row=4, column=0, sticky="ew", padx=6, pady=6)
        self.cidade.grid(row=4, column=1, sticky="ew", padx=6, pady=6)
        self.uf.grid(row=4, column=2, sticky="ew", padx=6, pady=6)

        self._campos = [self.nome, self.documento, self.telefone, self.email, self.cep,
                        self.logradouro, self.numero, self.complemento, self.bairro, self.cidade]

    def preencher(self, pessoa: Pessoa) -> None:
        self.nome.definir(pessoa.nome)
        self.documento.definir(formatar_cpf_cnpj(pessoa.documento))
        self.telefone.definir(formatar_telefone(pessoa.telefone))
        self.email.definir(pessoa.email)
        self.cep.definir(formatar_cep(pessoa.cep))
        self.logradouro.definir(pessoa.logradouro)
        self.numero.definir(pessoa.numero)
        self.complemento.definir(pessoa.complemento)
        self.bairro.definir(pessoa.bairro)
        self.cidade.definir(pessoa.cidade)
        self.uf.definir(pessoa.uf or "")

    def coletar(self, modelo: type[P], pessoa_id: int | None = None) -> P:
        """Cria o objeto com o texto digitado (a validação e normalização ficam no serviço)."""
        return modelo(
            id=pessoa_id,
            nome=self.nome.obter(),
            tipo_pessoa="F",
            documento=self.documento.obter(),
            telefone=self.telefone.obter() or None,
            email=self.email.obter() or None,
            logradouro=self.logradouro.obter() or None,
            numero=self.numero.obter() or None,
            complemento=self.complemento.obter() or None,
            bairro=self.bairro.obter() or None,
            cidade=self.cidade.obter() or None,
            uf=self.uf.obter() or None,
            cep=self.cep.obter() or None,
        )

    def bloquear(self, bloqueado: bool = True) -> None:
        for campo in self._campos:
            campo.bloquear(bloqueado)
        self.uf.bloquear(bloqueado)

    def limpar(self) -> None:
        for campo in self._campos:
            campo.limpar()
        self.uf.definir("")
