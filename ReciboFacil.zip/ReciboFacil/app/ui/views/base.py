"""Base das telas do sistema."""

from __future__ import annotations

import customtkinter as ctk

from app.bootstrap import Servicos
from app.ui import theme


class Tela(ctk.CTkFrame):
    """Cada tela recebe os serviços e implementa `ao_exibir` para recarregar seus dados."""

    titulo = ""
    subtitulo = ""

    def __init__(self, master, servicos: Servicos) -> None:
        super().__init__(master, fg_color=theme.COR_FUNDO, corner_radius=0)
        self.servicos = servicos

    def cabecalho(self, titulo: str | None = None, subtitulo: str | None = None) -> ctk.CTkFrame:
        """Cria o cabeçalho padrão e devolve o quadro (para acrescentar botões à direita)."""
        quadro = ctk.CTkFrame(self, fg_color="transparent")
        quadro.pack(fill="x", padx=28, pady=(24, 12))
        textos = ctk.CTkFrame(quadro, fg_color="transparent")
        textos.pack(side="left")
        ctk.CTkLabel(textos, text=titulo or self.titulo, font=theme.fonte(24, True), text_color=theme.COR_TEXTO).pack(anchor="w")
        sub = subtitulo if subtitulo is not None else self.subtitulo
        if sub:
            ctk.CTkLabel(textos, text=sub, font=theme.fonte(13), text_color=theme.COR_TEXTO_SUAVE).pack(anchor="w")
        return quadro

    def cartao(self, master=None, **opcoes) -> ctk.CTkFrame:
        return ctk.CTkFrame(master or self, fg_color=theme.COR_CARTAO, corner_radius=10,
                            border_width=1, border_color=theme.COR_BORDA, **opcoes)

    def ao_exibir(self) -> None:
        """Chamado toda vez que a tela é aberta."""
