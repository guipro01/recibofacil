"""Janela para escolher o cliente de um recibo (pesquisa rápida e cadastro)."""

from __future__ import annotations

from collections.abc import Callable

import customtkinter as ctk

from app.bootstrap import Servicos
from app.models.cliente import Cliente
from app.ui import theme
from app.ui.components import dialogos
from app.ui.components.tabela import Coluna, Tabela
from app.ui.views.cliente_dialog import NOVO, ClienteDialog
from app.utils.formatadores import formatar_cpf_cnpj, formatar_telefone


class SelecionarClienteDialog(dialogos.Dialogo):
    def __init__(self, pai, servicos: Servicos, ao_escolher: Callable[[Cliente], None]) -> None:
        super().__init__(pai, "Selecionar cliente", 760, 520)
        self._servicos, self._ao_escolher = servicos, ao_escolher
        self._clientes: dict[str, Cliente] = {}
        self._temporizador = None

        corpo = ctk.CTkFrame(self, fg_color=theme.COR_CARTAO, corner_radius=10)
        corpo.pack(fill="both", expand=True, padx=16, pady=16)
        linha = ctk.CTkFrame(corpo, fg_color="transparent")
        linha.pack(fill="x", padx=16, pady=(16, 8))
        self._busca = ctk.CTkEntry(linha, height=36, placeholder_text="Pesquisar por nome ou CPF/CNPJ...", font=theme.fonte(13))
        self._busca.pack(side="left", fill="x", expand=True)
        self._busca.bind("<KeyRelease>", self._busca_digitada)
        ctk.CTkButton(linha, text="+ Novo cliente", width=130, height=36, command=self._novo, **theme.estilo_botao("neutro")).pack(side="left", padx=(8, 0))

        self._tabela = Tabela(
            corpo, [Coluna("nome", "Nome", 280, esticar=True), Coluna("doc", "CPF / CNPJ", 150), Coluna("tel", "Telefone", 120)],
            altura=10, ao_duplo_clique=lambda _k: self._escolher(),
        )
        self._tabela.pack(fill="both", expand=True, padx=16, pady=4)
        ctk.CTkLabel(corpo, text="Somente clientes ativos são listados. Dê um duplo clique para escolher.",
                     font=theme.fonte(11), text_color=theme.COR_TEXTO_SUAVE).pack(anchor="w", padx=16)

        botoes = ctk.CTkFrame(corpo, fg_color="transparent")
        botoes.pack(fill="x", padx=16, pady=12)
        ctk.CTkButton(botoes, text="Cancelar", width=100, command=self.destroy, **theme.estilo_botao("neutro")).pack(side="right", padx=(8, 0))
        ctk.CTkButton(botoes, text="Selecionar", width=120, command=self._escolher, **theme.estilo_botao("primario")).pack(side="right")
        self.bind("<Return>", lambda _e: self._escolher())
        self._carregar()
        self.after(250, self._busca.focus_set)

    def _busca_digitada(self, _evento=None) -> None:
        if self._temporizador:
            self.after_cancel(self._temporizador)
        self._temporizador = self.after(300, self._carregar)

    def _carregar(self) -> None:
        ok, clientes = dialogos.executar(self, self.servicos_clientes, self._busca.get().strip())
        if not ok:
            return
        self._clientes = {str(c.id): c for c in clientes}
        self._tabela.carregar([(c.id, (c.nome, formatar_cpf_cnpj(c.documento), formatar_telefone(c.telefone)), None) for c in clientes])

    def servicos_clientes(self, termo: str) -> list[Cliente]:
        return self._servicos.clientes.pesquisar_ativos(termo)

    def _escolher(self) -> None:
        chave = self._tabela.selecionado()
        if not chave:
            dialogos.aviso(self, "Selecione um cliente na lista.")
            return
        self._ao_escolher(self._clientes[chave])
        self.destroy()

    def _novo(self) -> None:
        def cadastrado(cliente: Cliente) -> None:
            self._ao_escolher(cliente)
            self.destroy()

        ClienteDialog(self, self._servicos, NOVO, ao_salvar=cadastrado)
