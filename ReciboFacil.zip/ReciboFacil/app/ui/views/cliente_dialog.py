"""Janela de cadastro, edição e consulta de cliente."""

from __future__ import annotations

from collections.abc import Callable

import customtkinter as ctk

from app.bootstrap import Servicos
from app.models.cliente import Cliente
from app.ui import theme
from app.ui.components import dialogos
from app.ui.components.formulario_pessoa import FormularioPessoa
from app.utils.formatadores import formatar_data_hora

NOVO, EDITAR, CONSULTAR = "novo", "editar", "consultar"


class ClienteDialog(dialogos.Dialogo):
    def __init__(self, pai, servicos: Servicos, modo: str, cliente: Cliente | None = None,
                 ao_salvar: Callable[[Cliente], None] | None = None) -> None:
        titulos = {NOVO: "Novo cliente", EDITAR: "Editar cliente", CONSULTAR: "Dados do cliente"}
        super().__init__(pai, titulos[modo], 720, 560 if modo == CONSULTAR else 520)
        self._servicos, self._modo, self._cliente, self._ao_salvar = servicos, modo, cliente, ao_salvar

        corpo = ctk.CTkFrame(self, fg_color=theme.COR_CARTAO, corner_radius=10)
        corpo.pack(fill="both", expand=True, padx=16, pady=16)
        ctk.CTkLabel(corpo, text=titulos[modo], font=theme.fonte(18, True), text_color=theme.COR_TEXTO).pack(anchor="w", padx=18, pady=(16, 0))
        ctk.CTkLabel(corpo, text="Campos com * são obrigatórios." if modo != CONSULTAR else "",
                     font=theme.fonte(12), text_color=theme.COR_TEXTO_SUAVE).pack(anchor="w", padx=18)

        self._formulario = FormularioPessoa(corpo, rotulo_nome="Nome / Razão social")
        self._formulario.pack(fill="x", padx=12, pady=8)
        if cliente:
            self._formulario.preencher(cliente)

        if modo == CONSULTAR and cliente:
            situacao = "Ativo" if cliente.ativo else "Desativado"
            info = (f"Situação: {situacao}    •    Cadastrado em {formatar_data_hora(cliente.criado_em)}"
                    f"    •    Atualizado em {formatar_data_hora(cliente.atualizado_em)}")
            ctk.CTkLabel(corpo, text=info, font=theme.fonte(12), text_color=theme.COR_TEXTO_SUAVE).pack(anchor="w", padx=18, pady=(4, 0))
            self._formulario.bloquear(True)

        botoes = ctk.CTkFrame(corpo, fg_color="transparent")
        botoes.pack(fill="x", padx=18, pady=16, side="bottom")
        if modo == CONSULTAR:
            ctk.CTkButton(botoes, text="Fechar", width=110, command=self.destroy, **theme.estilo_botao("neutro")).pack(side="right")
        else:
            ctk.CTkButton(botoes, text="Cancelar", width=110, command=self.destroy, **theme.estilo_botao("neutro")).pack(side="right", padx=(8, 0))
            ctk.CTkButton(botoes, text="Salvar", width=130, command=self._salvar, **theme.estilo_botao("primario")).pack(side="right")
            self.bind("<Return>", lambda _e: self._salvar())
        self.after(250, self._formulario.nome.focar)

    def _salvar(self) -> None:
        cliente = self._formulario.coletar(Cliente, self._cliente.id if self._cliente else None)
        servico = self._servicos.clientes
        ok, resultado = dialogos.executar(self, servico.cadastrar if self._modo == NOVO else servico.atualizar, cliente)
        if not ok:
            return
        if self._ao_salvar:
            self._ao_salvar(resultado)
        self.destroy()
