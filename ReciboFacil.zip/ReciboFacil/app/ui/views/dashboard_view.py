"""Dashboard inicial: indicadores, últimos recibos e evolução mensal."""

from __future__ import annotations

import customtkinter as ctk

from app.ui import theme
from app.ui.components import dialogos
from app.ui.components.campos import CartaoIndicador
from app.ui.components.tabela import Coluna, Tabela
from app.ui.views.base import Tela
from app.utils.dinheiro import ZERO, formatar_moeda
from app.utils.formatadores import formatar_data

_MESES = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"]


def _rotulo_mes(chave: str) -> str:
    ano, mes = chave.split("-")
    return f"{_MESES[int(mes) - 1]}/{ano}"


class DashboardView(Tela):
    titulo = "Dashboard"
    subtitulo = "Visão geral dos recibos emitidos."

    def __init__(self, master, servicos, ao_novo_recibo=None) -> None:
        super().__init__(master, servicos)
        topo = self.cabecalho()
        if ao_novo_recibo:
            ctk.CTkButton(topo, text="+  Novo recibo", height=38, font=theme.fonte(13, True), command=ao_novo_recibo,
                          **theme.estilo_botao("primario")).pack(side="right")

        grade = ctk.CTkFrame(self, fg_color="transparent")
        grade.pack(fill="x", padx=22)
        grade.columnconfigure((0, 1, 2), weight=1, uniform="cartao")
        self._cartoes = {
            "total": CartaoIndicador(grade, "Total de recibos", theme.COR_PRIMARIA),
            "emitido": CartaoIndicador(grade, "Valor total emitido", theme.COR_SUCESSO),
            "mes": CartaoIndicador(grade, "Recibos no mês", "#7C3AED"),
            "valor_mes": CartaoIndicador(grade, "Valor emitido no mês", "#0891B2"),
            "recebido": CartaoIndicador(grade, "Valor recebido", theme.COR_SUCESSO),
            "pendente": CartaoIndicador(grade, "Valor pendente", theme.COR_ALERTA),
        }
        for posicao, cartao in enumerate(self._cartoes.values()):
            cartao.grid(row=posicao // 3, column=posicao % 3, sticky="ew", padx=6, pady=6)

        inferior = ctk.CTkFrame(self, fg_color="transparent")
        inferior.pack(fill="both", expand=True, padx=22, pady=(6, 20))
        inferior.columnconfigure(0, weight=3)
        inferior.columnconfigure(1, weight=2, minsize=330)
        inferior.rowconfigure(0, weight=1)

        esquerda = self.cartao(inferior)
        esquerda.grid(row=0, column=0, sticky="nsew", padx=6)
        ctk.CTkLabel(esquerda, text="Últimos recibos emitidos", font=theme.fonte(15, True), text_color=theme.COR_TEXTO).pack(anchor="w", padx=16, pady=(12, 6))
        self._tabela = Tabela(
            esquerda,
            [Coluna("numero", "Nº", 100), Coluna("data", "Data", 90), Coluna("cliente", "Cliente", 200, esticar=True), Coluna("total", "Total", 105, "e")],
            altura=8,
        )
        self._tabela.pack(fill="both", expand=True, padx=14, pady=(0, 14))

        direita = self.cartao(inferior)
        direita.grid(row=0, column=1, sticky="nsew", padx=6)
        ctk.CTkLabel(direita, text="Emitido nos últimos 6 meses", font=theme.fonte(15, True), text_color=theme.COR_TEXTO).pack(anchor="w", padx=16, pady=(12, 6))
        self._grafico = ctk.CTkFrame(direita, fg_color="transparent")
        self._grafico.pack(fill="both", expand=True, padx=16, pady=(0, 14))

    def ao_exibir(self) -> None:
        ok, dados = dialogos.executar(self, self.servicos.dashboard.carregar)
        if not ok:
            return
        c = self._cartoes
        c["total"].definir(str(dados.total_recibos), f"{dados.recibos_cancelados} cancelado(s)")
        c["emitido"].definir(formatar_moeda(dados.valor_emitido), "recibos não cancelados")
        c["mes"].definir(str(dados.recibos_mes), "no mês atual")
        c["valor_mes"].definir(formatar_moeda(dados.valor_mes), "no mês atual")
        c["recebido"].definir(formatar_moeda(dados.valor_recebido), "pagamentos registrados")
        c["pendente"].definir(formatar_moeda(dados.valor_pendente), "a receber")

        self._tabela.carregar([
            (r.id, (r.numero_formatado, formatar_data(r.data_emissao), r.cliente_nome, formatar_moeda(r.total)), None)
            for r in dados.ultimos
        ])

        for filho in self._grafico.winfo_children():
            filho.destroy()
        maximo = max((total for _m, _q, total in dados.por_mes), default=ZERO)
        for mes, quantidade, total in dados.por_mes:
            linha = ctk.CTkFrame(self._grafico, fg_color="transparent")
            linha.pack(fill="x", pady=5)
            ctk.CTkLabel(linha, text=_rotulo_mes(mes), width=62, anchor="w", font=theme.fonte(12), text_color=theme.COR_TEXTO_SUAVE).pack(side="left")
            barra = ctk.CTkProgressBar(linha, height=14, progress_color=theme.COR_PRIMARIA, fg_color=theme.COR_NEUTRA)
            barra.set(float(total / maximo) if maximo > 0 else 0)
            barra.pack(side="left", fill="x", expand=True, padx=8)
            ctk.CTkLabel(linha, text=f"{formatar_moeda(total)}  ({quantidade})", width=130, anchor="e", font=theme.fonte(12), text_color=theme.COR_TEXTO).pack(side="left")
