"""Janela com os detalhes de um recibo emitido."""

from __future__ import annotations

from collections.abc import Callable

import customtkinter as ctk

from app.bootstrap import Servicos
from app.ui import theme
from app.ui.components import dialogos
from app.ui.components.tabela import Coluna, Tabela
from app.ui.views.pagamento_dialog import PagamentoDialog
from app.utils.dinheiro import ZERO, formatar_moeda
from app.utils.formatadores import formatar_cpf_cnpj, formatar_data, formatar_data_hora, formatar_quantidade


class ReciboDetalheDialog(dialogos.Dialogo):
    def __init__(self, pai, servicos: Servicos, recibo_id: int, ao_alterar: Callable[[], None] | None = None) -> None:
        super().__init__(pai, "Detalhes do recibo", 820, 760)
        self._servicos, self._recibo_id, self._ao_alterar = servicos, recibo_id, ao_alterar
        self._corpo = ctk.CTkScrollableFrame(self, fg_color=theme.COR_CARTAO, corner_radius=10)
        self._corpo.pack(fill="both", expand=True, padx=16, pady=(16, 8))
        self._rodape = ctk.CTkFrame(self, fg_color="transparent")
        self._rodape.pack(fill="x", padx=16, pady=(0, 16))
        self._carregar()

    def _linha_info(self, rotulo: str, valor: str, cor: str = theme.COR_TEXTO) -> None:
        linha = ctk.CTkFrame(self._corpo, fg_color="transparent")
        linha.pack(fill="x", padx=8, pady=1)
        ctk.CTkLabel(linha, text=rotulo, width=110, anchor="w", font=theme.fonte(12), text_color=theme.COR_TEXTO_SUAVE).pack(side="left", anchor="n")
        ctk.CTkLabel(linha, text=valor, anchor="w", justify="left", wraplength=600, font=theme.fonte(13), text_color=cor).pack(side="left", fill="x", expand=True)

    def _secao(self, titulo: str) -> None:
        ctk.CTkLabel(self._corpo, text=titulo, font=theme.fonte(14, True), text_color=theme.COR_TEXTO).pack(anchor="w", padx=8, pady=(14, 4))

    def _carregar(self) -> None:
        ok, detalhes = dialogos.executar(self, self._servicos.recibos.obter_detalhes, self._recibo_id)
        if not ok:
            self.destroy()
            return
        self._detalhes = detalhes
        r = detalhes.recibo
        for filho in (*self._corpo.winfo_children(), *self._rodape.winfo_children()):
            filho.destroy()

        ctk.CTkLabel(self._corpo, text=f"Recibo {r.numero_formatado}", font=theme.fonte(22, True), text_color=theme.COR_TEXTO).pack(anchor="w", padx=8, pady=(8, 0))
        situacao = "CANCELADO" if r.cancelado else "EMITIDO"
        self._linha_info("Situação", situacao, theme.COR_PERIGO if r.cancelado else theme.COR_SUCESSO)
        self._linha_info("Data de emissão", formatar_data(r.data_emissao))
        if r.cancelado:
            self._linha_info("Cancelado em", formatar_data_hora(r.cancelado_em), theme.COR_PERIGO)
            self._linha_info("Motivo", r.motivo_cancelamento or "", theme.COR_PERIGO)

        self._secao("Cliente (dados na data da emissão)")
        self._linha_info("Nome", r.cliente_nome)
        self._linha_info("CPF / CNPJ", formatar_cpf_cnpj(r.cliente_documento))
        if r.cliente_endereco:
            self._linha_info("Endereço", r.cliente_endereco)
        self._secao("Emitente")
        self._linha_info("Nome", r.emitente_nome)
        self._linha_info("CPF / CNPJ", formatar_cpf_cnpj(r.emitente_documento))

        self._secao("Serviços")
        itens = Tabela(
            self._corpo,
            [Coluna("n", "#", 40, "center"), Coluna("desc", "Descrição", 320, esticar=True), Coluna("qtd", "Qtd.", 70, "e"),
             Coluna("unit", "Valor unit.", 110, "e"), Coluna("sub", "Subtotal", 110, "e")],
            altura=min(max(len(r.itens), 2), 6),
        )
        itens.pack(fill="x", padx=8)
        itens.carregar([(i.ordem, (i.ordem, i.descricao, formatar_quantidade(i.quantidade), formatar_moeda(i.valor_unitario), formatar_moeda(i.subtotal)), None) for i in r.itens])

        self._secao("Valores")
        self._linha_info("Subtotal", formatar_moeda(r.subtotal))
        if r.desconto > ZERO:
            self._linha_info("Desconto", "- " + formatar_moeda(r.desconto))
        self._linha_info("Total", formatar_moeda(r.total), theme.COR_PRIMARIA)
        self._linha_info("Recebido", formatar_moeda(detalhes.recebido), theme.COR_SUCESSO)
        self._linha_info("Pendente", formatar_moeda(detalhes.pendente), theme.COR_ALERTA if detalhes.pendente > ZERO else theme.COR_TEXTO)

        if detalhes.pagamentos:
            self._secao("Pagamentos")
            pagamentos = Tabela(
                self._corpo,
                [Coluna("data", "Data", 90), Coluna("forma", "Forma", 160), Coluna("obs", "Observações", 220, esticar=True), Coluna("valor", "Valor", 110, "e")],
                altura=min(len(detalhes.pagamentos), 4),
            )
            pagamentos.pack(fill="x", padx=8)
            pagamentos.carregar([(p.id, (formatar_data(p.data_pagamento), p.forma_descricao, p.observacoes or "", formatar_moeda(p.valor)), None) for p in detalhes.pagamentos])
        if r.observacoes:
            self._secao("Observações")
            self._linha_info("", r.observacoes)

        ctk.CTkButton(self._rodape, text="Fechar", width=100, command=self.destroy, **theme.estilo_botao("neutro")).pack(side="right")
        if not r.cancelado:
            ctk.CTkButton(self._rodape, text="Cancelar recibo", width=140, command=self._cancelar, **theme.estilo_botao("perigo")).pack(side="right", padx=8)
            if detalhes.pendente > ZERO:
                ctk.CTkButton(self._rodape, text="Registrar pagamento", width=160, command=self._pagamento, **theme.estilo_botao("sucesso")).pack(side="right")
        ctk.CTkButton(self._rodape, text="Imprimir", width=100, command=self._imprimir, **theme.estilo_botao("neutro")).pack(side="left")
        ctk.CTkButton(self._rodape, text="Abrir PDF", width=110, command=self._abrir_pdf, **theme.estilo_botao("primario")).pack(side="left", padx=8)

    def _notificar(self) -> None:
        if self._ao_alterar:
            self._ao_alterar()

    def _abrir_pdf(self) -> None:
        dialogos.executar(self, self._servicos.pdf.abrir, self._recibo_id)

    def _imprimir(self) -> None:
        dialogos.executar(self, self._servicos.pdf.imprimir, self._recibo_id)

    def _pagamento(self) -> None:
        d = self._detalhes
        PagamentoDialog(self, self._servicos, self._recibo_id, d.recibo.numero_formatado, d.pendente,
                        ao_salvar=lambda: (self._carregar(), self._notificar()))

    def _cancelar(self) -> None:
        r = self._detalhes.recibo
        motivo = dialogos.pedir_texto(
            self, "Cancelar recibo",
            f"Informe o motivo do cancelamento do recibo {r.numero_formatado}.\n"
            "O recibo continuará registrado, marcado como cancelado.",
            "Cancelar recibo", perigo=True,
        )
        if motivo is None:
            return
        ok, _ = dialogos.executar(self, self._servicos.recibos.cancelar, self._recibo_id, motivo)
        if ok:
            self._carregar()
            self._notificar()
