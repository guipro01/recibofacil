"""Tela de clientes: pesquisa, cadastro, edição, consulta e desativação."""

from __future__ import annotations

import customtkinter as ctk

from app.models.cliente import Cliente
from app.ui import theme
from app.ui.components import dialogos
from app.ui.components.campos import Paginador
from app.ui.components.tabela import Coluna, Tabela
from app.ui.views.base import Tela
from app.ui.views.cliente_dialog import CONSULTAR, EDITAR, NOVO, ClienteDialog
from app.utils.dinheiro import formatar_moeda
from app.utils.formatadores import formatar_cpf_cnpj, formatar_telefone

_POR_PAGINA = 20
_SITUACOES = {"Ativos": "ativos", "Inativos": "inativos", "Todos": "todos"}


class ClientesView(Tela):
    titulo = "Clientes"
    subtitulo = "Cadastre, pesquise e mantenha os clientes que recebem recibos."

    def __init__(self, master, servicos) -> None:
        super().__init__(master, servicos)
        self._pagina = 1
        self._ativo_selecionado: bool | None = None
        self._temporizador = None

        topo = self.cabecalho()
        ctk.CTkButton(topo, text="+  Novo cliente", height=38, font=theme.fonte(13, True),
                      command=self._novo, **theme.estilo_botao("primario")).pack(side="right")

        filtros = self.cartao()
        filtros.pack(fill="x", padx=28, pady=(0, 12))
        linha = ctk.CTkFrame(filtros, fg_color="transparent")
        linha.pack(fill="x", padx=14, pady=12)
        self._busca = ctk.CTkEntry(linha, height=36, placeholder_text="Pesquisar por nome ou CPF/CNPJ...", font=theme.fonte(13))
        self._busca.pack(side="left", fill="x", expand=True)
        self._busca.bind("<KeyRelease>", self._busca_digitada)
        self._situacao = ctk.CTkSegmentedButton(linha, values=list(_SITUACOES), command=lambda _v: self._pesquisar(1), font=theme.fonte(12),
                                                selected_color=theme.COR_PRIMARIA, selected_hover_color=theme.COR_PRIMARIA_HOVER,
                                                unselected_color=theme.COR_NEUTRA, unselected_hover_color=theme.COR_NEUTRA_HOVER, text_color=theme.COR_TEXTO)
        self._situacao.set("Ativos")
        self._situacao.pack(side="left", padx=(12, 0))

        self._tabela = Tabela(
            self,
            [
                Coluna("nome", "Nome", 260, esticar=True), Coluna("documento", "CPF / CNPJ", 150),
                Coluna("telefone", "Telefone", 120), Coluna("cidade", "Cidade/UF", 140),
                Coluna("recibos", "Recibos", 70, "center"), Coluna("total", "Total emitido", 120, "e"),
                Coluna("situacao", "Situação", 90, "center"),
            ],
            altura=14, ao_duplo_clique=lambda _k: self._consultar(), ao_selecionar=self._selecao_mudou,
        )
        self._tabela.pack(fill="both", expand=True, padx=28)

        rodape = ctk.CTkFrame(self, fg_color="transparent")
        rodape.pack(fill="x", padx=28, pady=12)
        self._paginador = Paginador(rodape, self._pesquisar)
        self._paginador.pack(side="left")
        self._btn_situacao = ctk.CTkButton(rodape, text="Desativar", width=110, state="disabled", command=self._alternar_situacao, **theme.estilo_botao("perigo"))
        self._btn_editar = ctk.CTkButton(rodape, text="Editar", width=100, state="disabled", command=self._editar, **theme.estilo_botao("primario"))
        self._btn_consultar = ctk.CTkButton(rodape, text="Consultar", width=100, state="disabled", command=self._consultar, **theme.estilo_botao("neutro"))
        for botao in (self._btn_situacao, self._btn_editar, self._btn_consultar):
            botao.pack(side="right", padx=(8, 0))

    def ao_exibir(self) -> None:
        self._pesquisar(self._pagina)
        self._busca.focus_set()

    # --- pesquisa -------------------------------------------------------
    def _busca_digitada(self, _evento=None) -> None:
        if self._temporizador:
            self.after_cancel(self._temporizador)
        self._temporizador = self.after(350, lambda: self._pesquisar(1))

    def _pesquisar(self, pagina: int = 1) -> None:
        self._pagina = pagina
        situacao = _SITUACOES[self._situacao.get()]
        ok, resultado = dialogos.executar(self, self.servicos.clientes.pesquisar, self._busca.get().strip(), situacao, pagina, _POR_PAGINA)
        if not ok:
            return
        linhas = []
        for c in resultado.itens:
            cidade = "/".join(p for p in (c["cidade"], c["uf"]) if p)
            linhas.append((c["id"], (c["nome"], formatar_cpf_cnpj(c["documento"]), formatar_telefone(c["telefone"]), cidade,
                                     c["qtd_recibos"], formatar_moeda(c["total_emitido"]), "Ativo" if c["ativo"] else "Inativo"),
                           None if c["ativo"] else "inativo"))
        self._tabela.carregar(linhas)
        self._paginador.atualizar(resultado.pagina, resultado.total_paginas, resultado.total, "clientes")
        self._ativo_selecionado = None

    def _selecao_mudou(self, chave: str | None) -> None:
        estado = "normal" if chave else "disabled"
        for botao in (self._btn_editar, self._btn_consultar, self._btn_situacao):
            botao.configure(state=estado)
        if chave:
            ok, cliente = dialogos.executar(self, self.servicos.clientes.obter, int(chave))
            if ok:
                self._ativo_selecionado = cliente.ativo
                self._btn_situacao.configure(
                    text="Desativar" if cliente.ativo else "Reativar",
                    **theme.estilo_botao("perigo" if cliente.ativo else "sucesso"),
                )

    # --- ações --------------------------------------------------------------
    def _cliente_selecionado(self) -> Cliente | None:
        chave = self._tabela.selecionado()
        if not chave:
            return None
        ok, cliente = dialogos.executar(self, self.servicos.clientes.obter, int(chave))
        return cliente if ok else None

    def _novo(self) -> None:
        ClienteDialog(self, self.servicos, NOVO, ao_salvar=lambda _c: self._pesquisar(1))

    def _editar(self) -> None:
        cliente = self._cliente_selecionado()
        if cliente:
            ClienteDialog(self, self.servicos, EDITAR, cliente, ao_salvar=lambda _c: self._pesquisar(self._pagina))

    def _consultar(self) -> None:
        cliente = self._cliente_selecionado()
        if cliente:
            ClienteDialog(self, self.servicos, CONSULTAR, cliente)

    def _alternar_situacao(self) -> None:
        cliente = self._cliente_selecionado()
        if not cliente:
            return
        if cliente.ativo:
            if not dialogos.confirmar(
                self,
                f"Desativar o cliente '{cliente.nome}'?\n\nOs recibos já emitidos continuam preservados. "
                "O cliente deixa de aparecer na emissão de novos recibos e pode ser reativado depois.",
                "Desativar cliente",
            ):
                return
            ok, _ = dialogos.executar(self, self.servicos.clientes.desativar, cliente.id)
        else:
            ok, _ = dialogos.executar(self, self.servicos.clientes.reativar, cliente.id)
        if ok:
            self._pesquisar(self._pagina)
