"""Janela para registrar um pagamento em um recibo."""

from __future__ import annotations

from collections.abc import Callable
from datetime import date
from decimal import Decimal

import customtkinter as ctk

from app.bootstrap import Servicos
from app.services.recibo_service import NovoPagamento
from app.ui import theme
from app.ui.components import dialogos
from app.ui.components.campos import Campo, CampoLista
from app.utils.dinheiro import formatar_moeda, interpretar_valor
from app.utils.formatadores import formatar_data, interpretar_data, mascara_data


class PagamentoDialog(dialogos.Dialogo):
    def __init__(self, pai, servicos: Servicos, recibo_id: int, numero: str, pendente: Decimal,
                 ao_salvar: Callable[[], None]) -> None:
        super().__init__(pai, "Registrar pagamento", 460, 400)
        self._servicos, self._recibo_id, self._ao_salvar = servicos, recibo_id, ao_salvar
        ok, formas = dialogos.executar(self, servicos.configuracoes.listar_formas, True)
        self._formas = {f.descricao: f.id for f in formas} if ok else {}

        corpo = ctk.CTkFrame(self, fg_color=theme.COR_CARTAO, corner_radius=10)
        corpo.pack(fill="both", expand=True, padx=16, pady=16)
        ctk.CTkLabel(corpo, text=f"Pagamento do recibo {numero}", font=theme.fonte(16, True), text_color=theme.COR_TEXTO).pack(anchor="w", padx=18, pady=(16, 0))
        ctk.CTkLabel(corpo, text=f"Valor pendente: {formatar_moeda(pendente)}", font=theme.fonte(13), text_color=theme.COR_TEXTO_SUAVE).pack(anchor="w", padx=18, pady=(0, 8))

        self._forma = CampoLista(corpo, "Forma de pagamento", list(self._formas), largura=300)
        self._forma.pack(fill="x", padx=18, pady=4)
        linha = ctk.CTkFrame(corpo, fg_color="transparent")
        linha.pack(fill="x", padx=12)
        self._valor = Campo(linha, "Valor (R$)", largura=140, obrigatorio=True)
        self._valor.pack(side="left", padx=6, pady=4)
        self._data = Campo(linha, "Data do pagamento", largura=140, mascara=mascara_data, obrigatorio=True)
        self._data.pack(side="left", padx=6, pady=4)
        self._observacoes = Campo(corpo, "Observações", largura=300)
        self._observacoes.pack(fill="x", padx=18, pady=4)
        self._valor.definir(f"{pendente:.2f}".replace(".", ","))
        self._data.definir(formatar_data(date.today()))

        botoes = ctk.CTkFrame(corpo, fg_color="transparent")
        botoes.pack(fill="x", padx=18, pady=16, side="bottom")
        ctk.CTkButton(botoes, text="Cancelar", width=100, command=self.destroy, **theme.estilo_botao("neutro")).pack(side="right", padx=(8, 0))
        ctk.CTkButton(botoes, text="Registrar", width=120, command=self._salvar, **theme.estilo_botao("primario")).pack(side="right")
        self.bind("<Return>", lambda _e: self._salvar())

    def _salvar(self) -> None:
        forma_id = self._formas.get(self._forma.obter())
        if forma_id is None:
            dialogos.aviso(self, "Selecione a forma de pagamento.", "Verifique os dados")
            return
        try:
            dados = NovoPagamento(
                forma_pagamento_id=forma_id, valor=interpretar_valor(self._valor.obter()),
                data_pagamento=interpretar_data(self._data.obter()), observacoes=self._observacoes.obter() or None,
            )
        except ValueError as exc:
            dialogos.aviso(self, str(exc), "Verifique os dados")
            return
        ok, _ = dialogos.executar(self, self._servicos.recibos.registrar_pagamento, self._recibo_id, dados)
        if ok:
            self._ao_salvar()
            self.destroy()
