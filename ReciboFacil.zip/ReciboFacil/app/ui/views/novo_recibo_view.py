"""Tela de emissão de recibos."""

from __future__ import annotations

from datetime import date
from decimal import Decimal

import customtkinter as ctk

from app.models.cliente import Cliente
from app.models.recibo import ItemRecibo
from app.services.recibo_service import NovoPagamento, NovoRecibo
from app.ui import theme
from app.ui.components import dialogos
from app.ui.components.campos import Campo, CampoLista
from app.ui.components.tabela import Coluna, Tabela
from app.ui.views.base import Tela
from app.ui.views.selecionar_cliente_dialog import SelecionarClienteDialog
from app.utils.dinheiro import ZERO, arredondar, formatar_moeda, interpretar_valor
from app.utils.formatadores import formatar_cpf_cnpj, formatar_data, formatar_quantidade, interpretar_data, mascara_data
from app.validators.recibo import validar_itens


class NovoReciboView(Tela):
    titulo = "Novo recibo"
    subtitulo = "Selecione o cliente, adicione os serviços e emita o recibo."

    def __init__(self, master, servicos) -> None:
        super().__init__(master, servicos)
        self._cliente: Cliente | None = None
        self._itens: list[ItemRecibo] = []
        self._formas: dict[str, int] = {}
        self._valor_pagamento_editado = False

        self.cabecalho()
        colunas = ctk.CTkFrame(self, fg_color="transparent")
        colunas.pack(fill="both", expand=True, padx=28, pady=(0, 20))
        colunas.columnconfigure(0, weight=3)
        colunas.columnconfigure(1, weight=2, minsize=360)
        colunas.rowconfigure(0, weight=1)

        esquerda = ctk.CTkFrame(colunas, fg_color="transparent")
        esquerda.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        direita = self.cartao(colunas)
        direita.grid(row=0, column=1, sticky="nsew")
        self._montar_dados(esquerda)
        self._montar_servicos(esquerda)
        self._montar_resumo(direita)

    # ------------------------------------------------------------------
    # Montagem da tela
    # ------------------------------------------------------------------
    def _montar_dados(self, pai) -> None:
        cartao = self.cartao(pai)
        cartao.pack(fill="x", pady=(0, 12))
        ctk.CTkLabel(cartao, text="Cliente e data", font=theme.fonte(15, True), text_color=theme.COR_TEXTO).pack(anchor="w", padx=16, pady=(12, 4))
        linha = ctk.CTkFrame(cartao, fg_color="transparent")
        linha.pack(fill="x", padx=16, pady=(0, 6))
        self._rotulo_cliente = ctk.CTkLabel(linha, text="Nenhum cliente selecionado", font=theme.fonte(13), text_color=theme.COR_TEXTO_SUAVE, anchor="w", justify="left")
        self._rotulo_cliente.pack(side="left", fill="x", expand=True)
        ctk.CTkButton(linha, text="Selecionar cliente...", width=170, height=34, command=self._selecionar_cliente, **theme.estilo_botao("primario")).pack(side="right")
        linha2 = ctk.CTkFrame(cartao, fg_color="transparent")
        linha2.pack(fill="x", padx=10, pady=(0, 12))
        self._data = Campo(linha2, "Data de emissão", largura=140, mascara=mascara_data, obrigatorio=True)
        self._data.pack(side="left", padx=6)
        self._rotulo_emitente = ctk.CTkLabel(linha2, text="", font=theme.fonte(12), text_color=theme.COR_TEXTO_SUAVE)
        self._rotulo_emitente.pack(side="left", padx=18, pady=(18, 0))

    def _montar_servicos(self, pai) -> None:
        cartao = self.cartao(pai)
        cartao.pack(fill="both", expand=True)
        ctk.CTkLabel(cartao, text="Serviços", font=theme.fonte(15, True), text_color=theme.COR_TEXTO).pack(anchor="w", padx=16, pady=(12, 4))
        entrada = ctk.CTkFrame(cartao, fg_color="transparent")
        entrada.pack(fill="x", padx=10)
        self._descricao = Campo(entrada, "Descrição do serviço", largura=260)
        self._descricao.pack(side="left", fill="x", expand=True, padx=6)
        self._quantidade = Campo(entrada, "Qtd.", largura=70)
        self._quantidade.pack(side="left", padx=6)
        self._valor_unitario = Campo(entrada, "Valor unitário (R$)", largura=120)
        self._valor_unitario.pack(side="left", padx=6)
        ctk.CTkButton(entrada, text="Adicionar", width=100, height=34, command=self._adicionar_item, **theme.estilo_botao("sucesso")).pack(side="left", padx=(6, 6), pady=(18, 0))
        for campo in (self._descricao, self._quantidade, self._valor_unitario):
            campo.entrada.bind("<Return>", lambda _e: self._adicionar_item())
        self._quantidade.definir("1")

        self._tabela = Tabela(
            cartao,
            [Coluna("n", "#", 40, "center"), Coluna("desc", "Descrição", 300, esticar=True), Coluna("qtd", "Qtd.", 70, "e"),
             Coluna("unit", "Valor unit.", 110, "e"), Coluna("sub", "Subtotal", 110, "e")],
            altura=8,
        )
        self._tabela.pack(fill="both", expand=True, padx=16, pady=10)
        acoes = ctk.CTkFrame(cartao, fg_color="transparent")
        acoes.pack(fill="x", padx=16, pady=(0, 12))
        ctk.CTkButton(acoes, text="Remover selecionado", width=170, command=self._remover_item, **theme.estilo_botao("neutro")).pack(side="left")
        ctk.CTkButton(acoes, text="Editar selecionado", width=160, command=self._editar_item, **theme.estilo_botao("neutro")).pack(side="left", padx=8)

    def _montar_resumo(self, cartao) -> None:
        ctk.CTkLabel(cartao, text="Resumo", font=theme.fonte(15, True), text_color=theme.COR_TEXTO).pack(anchor="w", padx=16, pady=(12, 4))
        quadro = ctk.CTkFrame(cartao, fg_color="transparent")
        quadro.pack(fill="x", padx=16)
        quadro.columnconfigure(1, weight=1)
        ctk.CTkLabel(quadro, text="Subtotal", font=theme.fonte(13), text_color=theme.COR_TEXTO_SUAVE).grid(row=0, column=0, sticky="w", pady=3)
        self._subtotal = ctk.CTkLabel(quadro, text=formatar_moeda(0), font=theme.fonte(13), text_color=theme.COR_TEXTO)
        self._subtotal.grid(row=0, column=1, sticky="e")
        ctk.CTkLabel(quadro, text="Desconto (R$)", font=theme.fonte(13), text_color=theme.COR_TEXTO_SUAVE).grid(row=1, column=0, sticky="w", pady=3)
        self._desconto = ctk.CTkEntry(quadro, width=120, height=32, justify="right", placeholder_text="0,00", font=theme.fonte(13))
        self._desconto.grid(row=1, column=1, sticky="e")
        self._desconto.bind("<KeyRelease>", lambda _e: self._atualizar_totais())
        ctk.CTkLabel(quadro, text="TOTAL", font=theme.fonte(15, True), text_color=theme.COR_TEXTO).grid(row=2, column=0, sticky="w", pady=(8, 0))
        self._total = ctk.CTkLabel(quadro, text=formatar_moeda(0), font=theme.fonte(24, True), text_color=theme.COR_PRIMARIA)
        self._total.grid(row=2, column=1, sticky="e", pady=(8, 0))

        self._pagar = ctk.CTkCheckBox(cartao, text="Registrar pagamento agora", font=theme.fonte(13), command=self._alternar_pagamento)
        self._pagar.pack(anchor="w", padx=16, pady=(14, 4))
        self._quadro_pagamento = ctk.CTkFrame(cartao, fg_color="transparent")
        self._quadro_pagamento.columnconfigure((0, 1), weight=1, uniform="pg")
        self._forma = CampoLista(self._quadro_pagamento, "Forma de pagamento", [""], largura=160)
        self._forma.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        self._valor_pago = Campo(self._quadro_pagamento, "Valor pago (R$)", largura=120, ao_alterar=self._pagamento_editado)
        self._valor_pago.grid(row=1, column=0, sticky="ew", padx=(0, 6))
        self._data_pagamento = Campo(self._quadro_pagamento, "Data do pagamento", largura=120, mascara=mascara_data)
        self._data_pagamento.grid(row=1, column=1, sticky="ew", padx=(6, 0))

        ctk.CTkLabel(cartao, text="Observações", font=theme.fonte(12), text_color=theme.COR_TEXTO_SUAVE).pack(anchor="w", padx=16, pady=(12, 2))
        self._observacoes = ctk.CTkTextbox(cartao, height=80, font=theme.fonte(13), border_width=1, border_color=theme.COR_BORDA, fg_color="white")
        self._observacoes.pack(fill="x", padx=16)

        # Empacotados de baixo para cima: "Limpar" fica na base e "Emitir" logo acima.
        ctk.CTkButton(cartao, text="Limpar formulário", height=34, command=self._limpar_com_confirmacao, **theme.estilo_botao("neutro")).pack(fill="x", padx=16, pady=(0, 14), side="bottom")
        ctk.CTkButton(cartao, text="Emitir recibo", height=44, font=theme.fonte(15, True), command=self._emitir, **theme.estilo_botao("primario")).pack(fill="x", padx=16, pady=(16, 8), side="bottom")

    # ------------------------------------------------------------------
    # Comportamento
    # ------------------------------------------------------------------
    def ao_exibir(self) -> None:
        ok, emitente = dialogos.executar(self, self.servicos.emitentes.obter_padrao)
        if ok:
            self._rotulo_emitente.configure(
                text=f"Emitente: {emitente.nome}" if emitente else "⚠ Cadastre o emitente em Configurações antes de emitir.",
                text_color=theme.COR_TEXTO_SUAVE if emitente else theme.COR_ALERTA,
            )
        ok, formas = dialogos.executar(self, self.servicos.configuracoes.listar_formas, True)
        if ok:
            self._formas = {f.descricao: f.id for f in formas}
            self._forma.definir_opcoes(list(self._formas))
            if self._formas and self._forma.obter() not in self._formas:
                self._forma.definir("Dinheiro" if "Dinheiro" in self._formas else next(iter(self._formas)))
        if not self._data.obter():
            self._data.definir(formatar_data(date.today()))
        if self._cliente:  # o cliente pode ter sido desativado em outra tela
            ok, atual = dialogos.executar(self, self.servicos.clientes.obter, self._cliente.id)
            if ok and not atual.ativo:
                self._definir_cliente(None)

    def _selecionar_cliente(self) -> None:
        SelecionarClienteDialog(self, self.servicos, self._definir_cliente)

    def _definir_cliente(self, cliente: Cliente | None) -> None:
        self._cliente = cliente
        if cliente:
            self._rotulo_cliente.configure(
                text=f"{cliente.nome}\n{formatar_cpf_cnpj(cliente.documento)}", text_color=theme.COR_TEXTO, font=theme.fonte(14, True))
        else:
            self._rotulo_cliente.configure(text="Nenhum cliente selecionado", text_color=theme.COR_TEXTO_SUAVE, font=theme.fonte(13))

    # --- serviços ------------------------------------------------------------
    def _adicionar_item(self) -> None:
        try:
            item = ItemRecibo(
                descricao=self._descricao.obter(),
                quantidade=interpretar_valor(self._quantidade.obter() or "0"),
                valor_unitario=interpretar_valor(self._valor_unitario.obter() or "0"),
            )
        except ValueError:
            dialogos.aviso(self, "Quantidade ou valor unitário inválido. Use números, por exemplo 2 e 150,00.", "Verifique os dados")
            return
        erros = validar_itens([item])
        if erros:
            dialogos.aviso(self, "\n".join(f"• {e.split(': ', 1)[-1].capitalize()}" for e in erros), "Verifique os dados")
            return
        self._itens.append(item)
        self._descricao.limpar()
        self._quantidade.definir("1")
        self._valor_unitario.limpar()
        self._descricao.focar()
        self._atualizar_itens()

    def _remover_item(self) -> None:
        chave = self._tabela.selecionado()
        if chave is None:
            dialogos.aviso(self, "Selecione um serviço na lista.")
            return
        del self._itens[int(chave)]
        self._atualizar_itens()

    def _editar_item(self) -> None:
        chave = self._tabela.selecionado()
        if chave is None:
            dialogos.aviso(self, "Selecione um serviço na lista.")
            return
        item = self._itens.pop(int(chave))
        self._descricao.definir(item.descricao)
        self._quantidade.definir(formatar_quantidade(item.quantidade))
        self._valor_unitario.definir(f"{item.valor_unitario:.2f}".replace(".", ","))
        self._atualizar_itens()
        self._descricao.focar()

    def _atualizar_itens(self) -> None:
        self._tabela.carregar([
            (i, (i + 1, item.descricao, formatar_quantidade(item.quantidade), formatar_moeda(item.valor_unitario), formatar_moeda(item.subtotal)), None)
            for i, item in enumerate(self._itens)
        ])
        self._atualizar_totais()

    # --- totais e pagamento ---------------------------------------------------
    def _desconto_digitado(self) -> Decimal | None:
        """Desconto informado, ZERO se vazio, ou None se o texto for inválido."""
        texto = self._desconto.get().strip()
        if not texto:
            return ZERO
        try:
            return arredondar(interpretar_valor(texto))
        except ValueError:
            return None

    def _atualizar_totais(self) -> None:
        subtotal = arredondar(sum((i.subtotal for i in self._itens), ZERO))
        self._subtotal.configure(text=formatar_moeda(subtotal))
        desconto = self._desconto_digitado()
        if desconto is None:
            self._total.configure(text="Desconto inválido", text_color=theme.COR_PERIGO, font=theme.fonte(16, True))
            return
        total = subtotal - desconto
        invalido = total < 0
        self._total.configure(
            text="Desconto maior que o subtotal" if invalido else formatar_moeda(total),
            text_color=theme.COR_PERIGO if invalido else theme.COR_PRIMARIA,
            font=theme.fonte(16 if invalido else 24, True),
        )
        if self._pagar.get() and not self._valor_pagamento_editado and not invalido:
            self._valor_pago.definir(f"{total:.2f}".replace(".", ","))

    def _alternar_pagamento(self) -> None:
        if self._pagar.get():
            self._quadro_pagamento.pack(fill="x", padx=16, pady=(0, 4), after=self._pagar)
            self._valor_pagamento_editado = False
            self._data_pagamento.definir(self._data.obter() or formatar_data(date.today()))
            self._atualizar_totais()
        else:
            self._quadro_pagamento.pack_forget()

    def _pagamento_editado(self) -> None:
        self._valor_pagamento_editado = True

    # --- emissão -------------------------------------------------------------
    def _coletar(self) -> NovoRecibo | None:
        if self._cliente is None:
            dialogos.aviso(self, "Selecione o cliente do recibo.", "Verifique os dados")
            return None
        try:
            data_emissao = interpretar_data(self._data.obter())
        except ValueError as exc:
            dialogos.aviso(self, str(exc), "Verifique os dados")
            return None
        desconto = self._desconto_digitado()
        if desconto is None:
            dialogos.aviso(self, "O desconto informado é inválido.", "Verifique os dados")
            return None
        pagamento = None
        if self._pagar.get():
            forma_id = self._formas.get(self._forma.obter())
            try:
                valor = interpretar_valor(self._valor_pago.obter())
                data_pagamento = interpretar_data(self._data_pagamento.obter())
            except ValueError as exc:
                dialogos.aviso(self, f"Pagamento: {exc}", "Verifique os dados")
                return None
            if forma_id is None:
                dialogos.aviso(self, "Selecione a forma de pagamento.", "Verifique os dados")
                return None
            pagamento = NovoPagamento(forma_pagamento_id=forma_id, valor=valor, data_pagamento=data_pagamento)
        return NovoRecibo(
            cliente_id=self._cliente.id, itens=list(self._itens), data_emissao=data_emissao, desconto=desconto,
            observacoes=self._observacoes.get("1.0", "end").strip() or None, pagamento=pagamento,
        )

    def _emitir(self) -> None:
        dados = self._coletar()
        if dados is None:
            return
        ok, recibo = dialogos.executar(self, self.servicos.recibos.emitir, dados)
        if not ok:
            return
        self._limpar()
        if dialogos.confirmar(self, f"Recibo {recibo.numero_formatado} emitido com sucesso!\n\nDeseja abrir o PDF agora?", "Recibo emitido"):
            dialogos.executar(self, self.servicos.pdf.abrir, recibo.id)

    # --- limpeza ---------------------------------------------------------------
    def _limpar_com_confirmacao(self) -> None:
        if (self._itens or self._cliente) and not dialogos.confirmar(self, "Descartar os dados digitados?", "Limpar formulário"):
            return
        self._limpar()

    def _limpar(self) -> None:
        self._definir_cliente(None)
        self._itens.clear()
        self._descricao.limpar()
        self._quantidade.definir("1")
        self._valor_unitario.limpar()
        self._desconto.delete(0, "end")
        self._observacoes.delete("1.0", "end")
        self._data.definir(formatar_data(date.today()))
        if self._pagar.get():
            self._pagar.deselect()
            self._alternar_pagamento()
        self._valor_pago.limpar()
        self._atualizar_itens()
