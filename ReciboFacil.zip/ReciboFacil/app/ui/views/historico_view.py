"""Histórico de recibos: pesquisa por número, cliente e período; detalhes, PDF e cancelamento."""

from __future__ import annotations

import customtkinter as ctk

from app.models.filtros import FiltroRecibos
from app.models.recibo import SITUACAO_CANCELADO, SITUACAO_EMITIDO
from app.ui import theme
from app.ui.components import dialogos
from app.ui.components.campos import Campo, CampoLista, Paginador
from app.ui.components.tabela import Coluna, Tabela
from app.ui.views.base import Tela
from app.ui.views.recibo_detalhe_dialog import ReciboDetalheDialog
from app.utils.dinheiro import formatar_moeda
from app.utils.formatadores import formatar_cpf_cnpj, formatar_data, interpretar_data, interpretar_numero_recibo, mascara_data

_POR_PAGINA = 20
_SITUACOES = {"Todas": None, "Emitidos": SITUACAO_EMITIDO, "Cancelados": SITUACAO_CANCELADO}


class HistoricoView(Tela):
    titulo = "Histórico de recibos"
    subtitulo = "Pesquise recibos emitidos, consulte os detalhes, gere o PDF ou cancele."

    def __init__(self, master, servicos) -> None:
        super().__init__(master, servicos)
        self._pagina = 1
        self._filtro = FiltroRecibos()

        self.cabecalho()
        filtros = self.cartao()
        filtros.pack(fill="x", padx=28, pady=(0, 12))
        linha = ctk.CTkFrame(filtros, fg_color="transparent")
        linha.pack(fill="x", padx=8, pady=(10, 4))
        self._numero = Campo(linha, "Nº do recibo", largura=130, placeholder="12 ou 2026/000012")
        self._numero.pack(side="left", padx=6)
        self._cliente = Campo(linha, "Cliente (nome ou CPF/CNPJ)", largura=240)
        self._cliente.pack(side="left", padx=6, fill="x", expand=True)
        self._inicio = Campo(linha, "Data inicial", largura=105, mascara=mascara_data, placeholder="dd/mm/aaaa")
        self._inicio.pack(side="left", padx=6)
        self._fim = Campo(linha, "Data final", largura=105, mascara=mascara_data, placeholder="dd/mm/aaaa")
        self._fim.pack(side="left", padx=6)
        self._situacao = CampoLista(linha, "Situação", list(_SITUACOES), largura=120)
        self._situacao.pack(side="left", padx=6)
        botoes = ctk.CTkFrame(filtros, fg_color="transparent")
        botoes.pack(fill="x", padx=14, pady=(0, 12))
        ctk.CTkButton(botoes, text="Pesquisar", width=120, command=lambda: self._pesquisar(True), **theme.estilo_botao("primario")).pack(side="left")
        ctk.CTkButton(botoes, text="Limpar filtros", width=120, command=self._limpar, **theme.estilo_botao("neutro")).pack(side="left", padx=8)
        for campo in (self._numero, self._cliente, self._inicio, self._fim):
            campo.entrada.bind("<Return>", lambda _e: self._pesquisar(True))

        self._tabela = Tabela(
            self,
            [Coluna("numero", "Nº", 105), Coluna("data", "Data", 90), Coluna("cliente", "Cliente", 240, esticar=True),
             Coluna("doc", "CPF / CNPJ", 140), Coluna("total", "Total", 105, "e"), Coluna("recebido", "Recebido", 105, "e"),
             Coluna("pendente", "Pendente", 105, "e"), Coluna("situacao", "Situação", 90, "center")],
            altura=13, ao_duplo_clique=lambda _k: self._detalhes(), ao_selecionar=self._selecao_mudou,
        )
        self._tabela.pack(fill="both", expand=True, padx=28)

        rodape = ctk.CTkFrame(self, fg_color="transparent")
        rodape.pack(fill="x", padx=28, pady=12)
        self._paginador = Paginador(rodape, lambda p: self._buscar(p))
        self._paginador.pack(side="left")
        self._btn_cancelar = ctk.CTkButton(rodape, text="Cancelar recibo", width=130, state="disabled", command=self._cancelar, **theme.estilo_botao("perigo"))
        self._btn_imprimir = ctk.CTkButton(rodape, text="Imprimir", width=100, state="disabled", command=self._imprimir, **theme.estilo_botao("neutro"))
        self._btn_pdf = ctk.CTkButton(rodape, text="Abrir PDF", width=100, state="disabled", command=self._abrir_pdf, **theme.estilo_botao("neutro"))
        self._btn_detalhes = ctk.CTkButton(rodape, text="Detalhes", width=100, state="disabled", command=self._detalhes, **theme.estilo_botao("primario"))
        for botao in (self._btn_cancelar, self._btn_imprimir, self._btn_pdf, self._btn_detalhes):
            botao.pack(side="right", padx=(8, 0))

    def ao_exibir(self) -> None:
        self._buscar(self._pagina)

    # --- pesquisa -------------------------------------------------------------
    def _montar_filtro(self) -> FiltroRecibos | None:
        """Lê os campos de filtro. Devolve None (após avisar) se algum for inválido."""
        filtro = FiltroRecibos(cliente=self._cliente.obter() or None, situacao=_SITUACOES[self._situacao.obter()])
        try:
            if self._numero.obter():
                filtro.ano, filtro.numero = interpretar_numero_recibo(self._numero.obter())
            if self._inicio.obter():
                filtro.data_inicio = interpretar_data(self._inicio.obter())
            if self._fim.obter():
                filtro.data_fim = interpretar_data(self._fim.obter())
        except ValueError as exc:
            dialogos.aviso(self, str(exc), "Verifique os filtros")
            return None
        if filtro.data_inicio and filtro.data_fim and filtro.data_inicio > filtro.data_fim:
            dialogos.aviso(self, "A data inicial não pode ser maior que a data final.", "Verifique os filtros")
            return None
        return filtro

    def _pesquisar(self, novo_filtro: bool) -> None:
        if novo_filtro:
            filtro = self._montar_filtro()
            if filtro is None:
                return
            self._filtro = filtro
        self._buscar(1)

    def _buscar(self, pagina: int) -> None:
        self._pagina = pagina
        ok, resultado = dialogos.executar(self, self.servicos.recibos.pesquisar, self._filtro, pagina, _POR_PAGINA)
        if not ok:
            return
        linhas = [
            (r.id, (r.numero_formatado, formatar_data(r.data_emissao), r.cliente_nome, formatar_cpf_cnpj(r.cliente_documento),
                    formatar_moeda(r.total), formatar_moeda(r.recebido), formatar_moeda(r.pendente),
                    "Cancelado" if r.situacao == SITUACAO_CANCELADO else "Emitido"),
             "cancelado" if r.situacao == SITUACAO_CANCELADO else None)
            for r in resultado.itens
        ]
        self._situacoes = {r.id: r.situacao for r in resultado.itens}
        self._tabela.carregar(linhas)
        self._paginador.atualizar(resultado.pagina, resultado.total_paginas, resultado.total, "recibos")

    def _limpar(self) -> None:
        for campo in (self._numero, self._cliente, self._inicio, self._fim):
            campo.limpar()
        self._situacao.definir("Todas")
        self._filtro = FiltroRecibos()
        self._buscar(1)

    # --- ações ------------------------------------------------------------------
    def _selecao_mudou(self, chave: str | None) -> None:
        estado = "normal" if chave else "disabled"
        for botao in (self._btn_detalhes, self._btn_pdf, self._btn_imprimir):
            botao.configure(state=estado)
        cancelavel = bool(chave) and getattr(self, "_situacoes", {}).get(int(chave)) == SITUACAO_EMITIDO
        self._btn_cancelar.configure(state="normal" if cancelavel else "disabled")

    def _recibo_id(self) -> int | None:
        chave = self._tabela.selecionado()
        return int(chave) if chave else None

    def _detalhes(self) -> None:
        recibo_id = self._recibo_id()
        if recibo_id:
            ReciboDetalheDialog(self, self.servicos, recibo_id, ao_alterar=lambda: self._buscar(self._pagina))

    def _abrir_pdf(self) -> None:
        recibo_id = self._recibo_id()
        if recibo_id:
            dialogos.executar(self, self.servicos.pdf.abrir, recibo_id)

    def _imprimir(self) -> None:
        recibo_id = self._recibo_id()
        if recibo_id:
            dialogos.executar(self, self.servicos.pdf.imprimir, recibo_id)

    def _cancelar(self) -> None:
        recibo_id = self._recibo_id()
        if not recibo_id:
            return
        motivo = dialogos.pedir_texto(
            self, "Cancelar recibo",
            "Informe o motivo do cancelamento.\nO recibo continuará registrado, marcado como cancelado.",
            "Cancelar recibo", perigo=True,
        )
        if motivo is None:
            return
        ok, _ = dialogos.executar(self, self.servicos.recibos.cancelar, recibo_id, motivo)
        if ok:
            self._buscar(self._pagina)
