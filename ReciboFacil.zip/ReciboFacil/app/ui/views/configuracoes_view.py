"""Configurações: emitente, documento PDF, formas de pagamento e informações do sistema."""

from __future__ import annotations

import sys
from tkinter import filedialog

import customtkinter as ctk

from app.config.settings import BASE_DIR
from app.models.emitente import Emitente
from app.ui import theme
from app.ui.components import dialogos
from app.ui.components.campos import Campo
from app.ui.components.formulario_pessoa import FormularioPessoa
from app.ui.components.tabela import Coluna, Tabela
from app.ui.views.base import Tela

VERSAO = "1.0.0"


class ConfiguracoesView(Tela):
    titulo = "Configurações"
    subtitulo = "Dados do emitente, aparência do PDF e formas de pagamento."

    def __init__(self, master, servicos, versao_banco: str = "") -> None:
        super().__init__(master, servicos)
        self._emitente: Emitente | None = None
        self._versao_banco = versao_banco
        self.cabecalho()
        self._abas = ctk.CTkTabview(self, fg_color=theme.COR_CARTAO, segmented_button_selected_color=theme.COR_PRIMARIA,
                                    segmented_button_selected_hover_color=theme.COR_PRIMARIA_HOVER, border_width=1, border_color=theme.COR_BORDA)
        self._abas.pack(fill="both", expand=True, padx=28, pady=(0, 24))
        self._montar_emitente(self._abas.add("Emitente"))
        self._montar_documento(self._abas.add("Documento PDF"))
        self._montar_formas(self._abas.add("Formas de pagamento"))
        self._montar_sobre(self._abas.add("Sobre"))

    # --- Emitente -------------------------------------------------------------
    def _montar_emitente(self, aba) -> None:
        ctk.CTkLabel(aba, text="Quem emite os recibos. Estes dados aparecem no cabeçalho e na assinatura do PDF.",
                     font=theme.fonte(13), text_color=theme.COR_TEXTO_SUAVE).pack(anchor="w", padx=8, pady=(4, 0))
        ctk.CTkLabel(aba, text="Alterar o emitente não modifica recibos já emitidos.", font=theme.fonte(12),
                     text_color=theme.COR_TEXTO_SUAVE).pack(anchor="w", padx=8)
        self._form_emitente = FormularioPessoa(aba, rotulo_nome="Nome / Razão social")
        self._form_emitente.pack(fill="x", padx=2, pady=8)
        ctk.CTkButton(aba, text="Salvar emitente", width=160, height=38, command=self._salvar_emitente, **theme.estilo_botao("primario")).pack(anchor="e", padx=10, pady=8)

    def _salvar_emitente(self) -> None:
        emitente = self._form_emitente.coletar(Emitente, self._emitente.id if self._emitente else None)
        ok, salvo = dialogos.executar(self, self.servicos.emitentes.salvar, emitente)
        if ok:
            self._emitente = salvo
            dialogos.informacao(self, "Emitente salvo com sucesso.")

    # --- Documento PDF ---------------------------------------------------------
    def _montar_documento(self, aba) -> None:
        ctk.CTkLabel(aba, text="Rodapé dos recibos", font=theme.fonte(13, True), text_color=theme.COR_TEXTO).pack(anchor="w", padx=8, pady=(8, 2))
        self._rodape = ctk.CTkEntry(aba, height=36, font=theme.fonte(13))
        self._rodape.pack(fill="x", padx=8)
        ctk.CTkLabel(aba, text="Pasta onde os PDFs são salvos", font=theme.fonte(13, True), text_color=theme.COR_TEXTO).pack(anchor="w", padx=8, pady=(16, 2))
        linha = ctk.CTkFrame(aba, fg_color="transparent")
        linha.pack(fill="x", padx=8)
        self._pasta = ctk.CTkEntry(linha, height=36, font=theme.fonte(13))
        self._pasta.pack(side="left", fill="x", expand=True)
        ctk.CTkButton(linha, text="Procurar...", width=110, height=36, command=self._procurar_pasta, **theme.estilo_botao("neutro")).pack(side="left", padx=(8, 0))
        ctk.CTkLabel(aba, text="Caminho relativo é considerado a partir da pasta do projeto.", font=theme.fonte(12), text_color=theme.COR_TEXTO_SUAVE).pack(anchor="w", padx=8, pady=(2, 0))
        ctk.CTkButton(aba, text="Salvar configurações", width=180, height=38, command=self._salvar_documento, **theme.estilo_botao("primario")).pack(anchor="e", padx=10, pady=16)

    def _procurar_pasta(self) -> None:
        pasta = filedialog.askdirectory(parent=self, title="Escolha a pasta dos PDFs")
        if pasta:
            self._pasta.delete(0, "end")
            self._pasta.insert(0, pasta)

    def _salvar_documento(self) -> None:
        ok, _ = dialogos.executar(self, self.servicos.configuracoes.salvar, self._rodape.get(), self._pasta.get())
        if ok:
            dialogos.informacao(self, "Configurações salvas com sucesso.")

    # --- Formas de pagamento ---------------------------------------------------
    def _montar_formas(self, aba) -> None:
        linha = ctk.CTkFrame(aba, fg_color="transparent")
        linha.pack(fill="x", padx=2, pady=(6, 8))
        self._nova_forma = Campo(linha, "Nova forma de pagamento", largura=280)
        self._nova_forma.pack(side="left", padx=6)
        self._nova_forma.entrada.bind("<Return>", lambda _e: self._adicionar_forma())
        ctk.CTkButton(linha, text="Adicionar", width=110, height=34, command=self._adicionar_forma, **theme.estilo_botao("sucesso")).pack(side="left", pady=(18, 0))
        self._tabela_formas = Tabela(aba, [Coluna("desc", "Forma de pagamento", 320, esticar=True), Coluna("sit", "Situação", 100, "center")], altura=9)
        self._tabela_formas.pack(fill="both", expand=True, padx=8)
        ctk.CTkButton(aba, text="Ativar / desativar selecionada", width=230, height=36, command=self._alternar_forma, **theme.estilo_botao("neutro")).pack(anchor="e", padx=8, pady=10)

    def _carregar_formas(self) -> None:
        ok, formas = dialogos.executar(self, self.servicos.configuracoes.listar_formas, False)
        if ok:
            self._formas = {f.id: f for f in formas}
            self._tabela_formas.carregar([(f.id, (f.descricao, "Ativa" if f.ativo else "Inativa"), None if f.ativo else "inativo") for f in formas])

    def _adicionar_forma(self) -> None:
        ok, _ = dialogos.executar(self, self.servicos.configuracoes.cadastrar_forma, self._nova_forma.obter())
        if ok:
            self._nova_forma.limpar()
            self._carregar_formas()

    def _alternar_forma(self) -> None:
        chave = self._tabela_formas.selecionado()
        if not chave:
            dialogos.aviso(self, "Selecione uma forma de pagamento na lista.")
            return
        forma = self._formas[int(chave)]
        ok, _ = dialogos.executar(self, self.servicos.configuracoes.alterar_situacao_forma, forma.id, not forma.ativo)
        if ok:
            self._carregar_formas()

    # --- Sobre -------------------------------------------------------------------
    def _montar_sobre(self, aba) -> None:
        self._texto_sobre = ctk.CTkLabel(aba, text="", font=theme.fonte(13), justify="left", anchor="nw", text_color=theme.COR_TEXTO)
        self._texto_sobre.pack(anchor="w", padx=12, pady=12)

    # --- Exibição ---------------------------------------------------------------
    def ao_exibir(self) -> None:
        ok, emitente = dialogos.executar(self, self.servicos.emitentes.obter_padrao)
        if ok:
            self._emitente = emitente
            if emitente:
                self._form_emitente.preencher(emitente)
        self._rodape.delete(0, "end")
        self._rodape.insert(0, self.servicos.configuracoes.rodape_recibo())
        self._pasta.delete(0, "end")
        self._pasta.insert(0, self.servicos.configuracoes.pasta_pdf_texto())
        self._carregar_formas()
        self._texto_sobre.configure(text=(
            f"ReciboFácil {VERSAO}\n\n"
            "Sistema de emissão de recibos de prestação de serviços.\n\n"
            f"Python {sys.version.split()[0]}  •  CustomTkinter  •  PyMySQL  •  ReportLab\n"
            f"Banco de dados: MariaDB {self._versao_banco}\n"
            f"Pasta do sistema: {BASE_DIR}\n"
            f"Arquivo de log: {BASE_DIR / 'logs' / 'recibofacil.log'}"
        ))
