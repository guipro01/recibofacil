"""Tema visual do ReciboFácil (cores, fontes e estilo das tabelas)."""

from __future__ import annotations

import customtkinter as ctk

COR_SIDEBAR = "#14213D"
COR_SIDEBAR_HOVER = "#22345C"
COR_PRIMARIA = "#2563EB"
COR_PRIMARIA_HOVER = "#1D4ED8"
COR_SUCESSO = "#16A34A"
COR_PERIGO = "#DC2626"
COR_PERIGO_HOVER = "#B91C1C"
COR_ALERTA = "#D97706"
COR_NEUTRA = "#E5E7EB"
COR_NEUTRA_HOVER = "#D1D5DB"
COR_FUNDO = "#F3F4F6"
COR_CARTAO = "#FFFFFF"
COR_BORDA = "#E5E7EB"
COR_TEXTO = "#111827"
COR_TEXTO_SUAVE = "#6B7280"
COR_LINHA_ZEBRA = "#F9FAFB"

FAMILIA = "Segoe UI"


def aplicar_tema() -> None:
    """Modo claro e paleta azul. Chamar antes de criar a janela."""
    ctk.set_appearance_mode("light")
    ctk.set_default_color_theme("blue")


def fonte(tamanho: int = 13, negrito: bool = False) -> ctk.CTkFont:
    return ctk.CTkFont(family=FAMILIA, size=tamanho, weight="bold" if negrito else "normal")


def estilo_botao(tipo: str = "primario") -> dict:
    """Parâmetros de cor para CTkButton: primario, perigo, neutro, sucesso."""
    if tipo == "perigo":
        return dict(fg_color=COR_PERIGO, hover_color=COR_PERIGO_HOVER, text_color="white")
    if tipo == "neutro":
        return dict(fg_color=COR_NEUTRA, hover_color=COR_NEUTRA_HOVER, text_color=COR_TEXTO)
    if tipo == "sucesso":
        return dict(fg_color=COR_SUCESSO, hover_color="#15803D", text_color="white")
    return dict(fg_color=COR_PRIMARIA, hover_color=COR_PRIMARIA_HOVER, text_color="white")
