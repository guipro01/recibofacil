"""Janela principal: menu lateral e área de conteúdo."""

from __future__ import annotations

import tkinter as tk

import customtkinter as ctk

from app.bootstrap import Servicos
from app.core.logger import get_logger
from app.ui import theme
from app.ui.components import dialogos
from app.ui.views.base import Tela
from app.ui.views.clientes_view import ClientesView
from app.ui.views.configuracoes_view import ConfiguracoesView
from app.ui.views.dashboard_view import DashboardView
from app.ui.views.historico_view import HistoricoView
from app.ui.views.novo_recibo_view import NovoReciboView

log = get_logger(__name__)

MENU = [
    ("dashboard", "Dashboard", "▦"),
    ("clientes", "Clientes", "☺"),
    ("novo_recibo", "Novo recibo", "✚"),
    ("historico", "Histórico", "☰"),
    ("configuracoes", "Configurações", "⚙"),
]


class App(ctk.CTk):
    def __init__(self, servicos: Servicos, versao_banco: str = "") -> None:
        super().__init__()
        self.servicos = servicos
        self.title("ReciboFácil")
        self.configure(fg_color=theme.COR_FUNDO)
        self.minsize(1120, 700)
        largura, altura = 1280, 780
        x = max(0, (self.winfo_screenwidth() - largura) // 2)
        y = max(0, (self.winfo_screenheight() - altura) // 2 - 20)
        self.geometry(f"{largura}x{altura}+{x}+{y}")

        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        self._montar_menu()

        direita = ctk.CTkFrame(self, fg_color=theme.COR_FUNDO, corner_radius=0)
        direita.grid(row=0, column=1, sticky="nsew")
        direita.rowconfigure(0, weight=1)
        direita.columnconfigure(0, weight=1)
        self._conteudo = ctk.CTkFrame(direita, fg_color=theme.COR_FUNDO, corner_radius=0)
        self._conteudo.grid(row=0, column=0, sticky="nsew")
        self._conteudo.rowconfigure(0, weight=1)
        self._conteudo.columnconfigure(0, weight=1)
        barra = ctk.CTkFrame(direita, fg_color=theme.COR_CARTAO, corner_radius=0, height=28)
        barra.grid(row=1, column=0, sticky="ew")
        ctk.CTkLabel(barra, text=f"●  MariaDB {versao_banco} conectado" if versao_banco else "", font=theme.fonte(11),
                     text_color=theme.COR_SUCESSO).pack(side="left", padx=14, pady=3)

        self._telas: dict[str, Tela] = {
            "dashboard": DashboardView(self._conteudo, servicos, ao_novo_recibo=lambda: self.navegar("novo_recibo")),
            "clientes": ClientesView(self._conteudo, servicos),
            "novo_recibo": NovoReciboView(self._conteudo, servicos),
            "historico": HistoricoView(self._conteudo, servicos),
            "configuracoes": ConfiguracoesView(self._conteudo, servicos, versao_banco),
        }
        for tela in self._telas.values():
            tela.grid(row=0, column=0, sticky="nsew")
        self._atual: str | None = None
        self.navegar("dashboard")

    def _montar_menu(self) -> None:
        menu = ctk.CTkFrame(self, fg_color=theme.COR_SIDEBAR, corner_radius=0, width=230)
        menu.grid(row=0, column=0, sticky="ns")
        menu.grid_propagate(False)
        ctk.CTkLabel(menu, text="ReciboFácil", font=theme.fonte(24, True), text_color="white").pack(anchor="w", padx=24, pady=(30, 0))
        ctk.CTkLabel(menu, text="Emissão de recibos de serviços", font=theme.fonte(11), text_color="#9CA3AF").pack(anchor="w", padx=24, pady=(0, 28))
        self._botoes: dict[str, ctk.CTkButton] = {}
        for chave, rotulo, icone in MENU:
            botao = ctk.CTkButton(
                menu, text=f"  {icone}   {rotulo}", anchor="w", height=44, corner_radius=8, font=theme.fonte(14),
                fg_color="transparent", hover_color=theme.COR_SIDEBAR_HOVER, text_color="#E5E7EB",
                command=lambda c=chave: self.navegar(c),
            )
            botao.pack(fill="x", padx=14, pady=3)
            self._botoes[chave] = botao
        ctk.CTkButton(
            menu, text="  ⏻   Sair", anchor="w", height=44, corner_radius=8, font=theme.fonte(14),
            fg_color="transparent", hover_color=theme.COR_PERIGO_HOVER, text_color="#E5E7EB", command=self._sair,
        ).pack(side="bottom", fill="x", padx=14, pady=18)

    def navegar(self, chave: str) -> None:
        """Mostra a tela escolhida, destaca o item do menu e recarrega os dados."""
        if chave not in self._telas:
            return
        self._telas[chave].tkraise()
        for nome, botao in self._botoes.items():
            ativo = nome == chave
            botao.configure(fg_color=theme.COR_PRIMARIA if ativo else "transparent",
                            hover_color=theme.COR_PRIMARIA_HOVER if ativo else theme.COR_SIDEBAR_HOVER,
                            text_color="white" if ativo else "#E5E7EB")
        self._atual = chave
        self._telas[chave].ao_exibir()

    def _sair(self) -> None:
        if dialogos.confirmar(self, "Deseja sair do ReciboFácil?", "Sair"):
            self.destroy()

    def report_callback_exception(self, exc, val, tb) -> None:  # noqa: D102 - gancho do Tkinter
        """Exceção não tratada em um evento da interface: registra e avisa sem fechar o programa."""
        dialogos.tratar_excecao(self, val)
        if not isinstance(val, tk.TclError):
            log.error("Exceção na interface", exc_info=(exc, val, tb))
