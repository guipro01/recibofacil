"""Modelo de forma de pagamento."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(kw_only=True)
class FormaPagamento:
    descricao: str
    ativo: bool = True
    id: int | None = None

    @classmethod
    def from_row(cls, linha: dict[str, Any]) -> "FormaPagamento":
        return cls(id=linha["id"], descricao=linha["descricao"], ativo=bool(linha["ativo"]))
