"""Modelo base para cadastros de pessoas (clientes e emitentes)."""

from __future__ import annotations

from dataclasses import dataclass, fields
from datetime import datetime
from typing import Any, Self

from app.utils.formatadores import formatar_cep, somente_digitos

# Campos de texto/endereço gravados no banco (ordem usada nos SQLs dos repositórios)
CAMPOS_PESSOA = (
    "nome",
    "tipo_pessoa",
    "documento",
    "telefone",
    "email",
    "logradouro",
    "numero",
    "complemento",
    "bairro",
    "cidade",
    "uf",
    "cep",
)


@dataclass(kw_only=True)
class Pessoa:
    nome: str
    tipo_pessoa: str  # 'F' (física) ou 'J' (jurídica)
    documento: str  # somente dígitos
    telefone: str | None = None
    email: str | None = None
    logradouro: str | None = None
    numero: str | None = None
    complemento: str | None = None
    bairro: str | None = None
    cidade: str | None = None
    uf: str | None = None
    cep: str | None = None
    ativo: bool = True
    id: int | None = None
    criado_em: datetime | None = None
    atualizado_em: datetime | None = None

    @property
    def endereco_formatado(self) -> str:
        """Ex.: 'Rua A, 100, Sala 2 - Centro - Bebedouro/SP - CEP 14700-000'."""
        rua = ", ".join(p for p in (self.logradouro, self.numero, self.complemento) if p)
        cidade_uf = "/".join(p for p in (self.cidade, self.uf) if p)
        cep = f"CEP {formatar_cep(self.cep)}" if somente_digitos(self.cep) else ""
        return " - ".join(p for p in (rua, self.bairro, cidade_uf, cep) if p)

    def dados_auditoria(self) -> dict[str, Any]:
        """Campos relevantes para o histórico de operações (sem datas de controle)."""
        return {campo: getattr(self, campo) for campo in (*CAMPOS_PESSOA, "ativo")}

    @classmethod
    def from_row(cls, linha: dict[str, Any]) -> Self:
        """Cria o objeto a partir de uma linha (dict) devolvida pelo banco."""
        valores = {f.name: linha[f.name] for f in fields(cls) if f.name in linha}
        valores["ativo"] = bool(valores.get("ativo", 1))
        return cls(**valores)
