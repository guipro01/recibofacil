"""Filtros de pesquisa usados pelos repositórios."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date


@dataclass(kw_only=True)
class FiltroRecibos:
    """Todos os campos são opcionais e combinados com AND."""

    numero: int | None = None
    ano: int | None = None
    cliente: str | None = None  # parte do nome ou do CPF/CNPJ
    cliente_id: int | None = None
    data_inicio: date | None = None
    data_fim: date | None = None
    situacao: str | None = None  # 'EMITIDO' ou 'CANCELADO'
