"""Modelos de recibo, itens, pagamentos e resumo para listagens."""

from __future__ import annotations

from dataclasses import dataclass, field, fields
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Self

from app.utils.dinheiro import ZERO, arredondar, arredondar_quantidade
from app.utils.formatadores import formatar_numero_recibo

SITUACAO_EMITIDO = "EMITIDO"
SITUACAO_CANCELADO = "CANCELADO"


@dataclass(kw_only=True)
class ItemRecibo:
    """Serviço de um recibo. O subtotal é calculado se não for informado."""

    descricao: str
    quantidade: Decimal
    valor_unitario: Decimal
    subtotal: Decimal | None = None
    ordem: int = 0
    id: int | None = None
    recibo_id: int | None = None

    def __post_init__(self) -> None:
        self.quantidade = arredondar_quantidade(self.quantidade)
        self.valor_unitario = arredondar(self.valor_unitario)
        if self.subtotal is None:
            self.subtotal = self.calcular_subtotal()
        else:
            self.subtotal = arredondar(self.subtotal)

    def calcular_subtotal(self) -> Decimal:
        """quantidade × valor unitário, arredondado em centavos."""
        return arredondar(self.quantidade * self.valor_unitario)

    @classmethod
    def from_row(cls, linha: dict[str, Any]) -> Self:
        return cls(**{f.name: linha[f.name] for f in fields(cls) if f.name in linha})


@dataclass(kw_only=True)
class Pagamento:
    recibo_id: int
    forma_pagamento_id: int
    valor: Decimal
    data_pagamento: date
    observacoes: str | None = None
    id: int | None = None
    criado_em: datetime | None = None
    forma_descricao: str | None = None  # preenchido nas consultas com JOIN

    @classmethod
    def from_row(cls, linha: dict[str, Any]) -> Self:
        return cls(**{f.name: linha[f.name] for f in fields(cls) if f.name in linha})


@dataclass(kw_only=True)
class Recibo:
    """Recibo completo, com a cópia (snapshot) dos dados de cliente e emitente."""

    emitente_id: int
    cliente_id: int
    data_emissao: date
    ano: int = 0
    numero: int = 0  # definido na emissão, pelo contador seguro
    subtotal: Decimal = ZERO
    desconto: Decimal = ZERO
    total: Decimal = ZERO
    observacoes: str | None = None
    situacao: str = SITUACAO_EMITIDO
    motivo_cancelamento: str | None = None
    cancelado_em: datetime | None = None

    # Snapshot do cliente na emissão
    cliente_nome: str = ""
    cliente_tipo_pessoa: str = "F"
    cliente_documento: str = ""
    cliente_telefone: str | None = None
    cliente_endereco: str | None = None

    # Snapshot do emitente na emissão
    emitente_nome: str = ""
    emitente_tipo_pessoa: str = "J"
    emitente_documento: str = ""
    emitente_telefone: str | None = None
    emitente_endereco: str | None = None

    itens: list[ItemRecibo] = field(default_factory=list)
    id: int | None = None
    criado_em: datetime | None = None

    @property
    def numero_formatado(self) -> str:
        return formatar_numero_recibo(self.ano, self.numero) if self.numero else ""

    @property
    def cancelado(self) -> bool:
        return self.situacao == SITUACAO_CANCELADO

    def recalcular_totais(self) -> None:
        """subtotal = soma dos itens; total = subtotal − desconto."""
        self.subtotal = arredondar(sum((i.subtotal for i in self.itens), ZERO))
        self.desconto = arredondar(self.desconto)
        self.total = arredondar(self.subtotal - self.desconto)

    @classmethod
    def from_row(cls, linha: dict[str, Any]) -> Self:
        nomes = {f.name for f in fields(cls)} - {"itens"}
        return cls(**{nome: linha[nome] for nome in nomes if nome in linha})


@dataclass(kw_only=True)
class ResumoRecibo:
    """Linha de listagem (histórico, dashboard), vinda da view vw_recibos_resumo."""

    id: int
    numero_formatado: str
    emitente_id: int
    ano: int
    numero: int
    cliente_id: int
    cliente_nome: str
    cliente_documento: str
    data_emissao: date
    subtotal: Decimal
    desconto: Decimal
    total: Decimal
    situacao: str
    recebido: Decimal
    pendente: Decimal

    @classmethod
    def from_row(cls, linha: dict[str, Any]) -> Self:
        return cls(**{f.name: linha[f.name] for f in fields(cls)})
