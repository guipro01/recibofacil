"""Resultado paginado de pesquisas."""

from __future__ import annotations

from dataclasses import dataclass
from math import ceil
from typing import Generic, TypeVar

T = TypeVar("T")


@dataclass(kw_only=True)
class Pagina(Generic[T]):
    itens: list[T]
    total: int
    pagina: int  # começa em 1
    por_pagina: int

    @property
    def total_paginas(self) -> int:
        return max(1, ceil(self.total / self.por_pagina))
