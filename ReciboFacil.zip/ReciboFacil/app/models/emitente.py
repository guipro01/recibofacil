"""Modelo de emitente."""

from __future__ import annotations

from dataclasses import dataclass

from app.models.pessoa import Pessoa


@dataclass(kw_only=True)
class Emitente(Pessoa):
    """Pessoa ou empresa responsável pela emissão dos recibos."""
