"""Modelo de cliente."""

from __future__ import annotations

from dataclasses import dataclass

from app.models.pessoa import Pessoa


@dataclass(kw_only=True)
class Cliente(Pessoa):
    """Cliente que recebe os recibos. Nunca é apagado: usa exclusão lógica (ativo)."""
