"""Funções para valores monetários. Sempre Decimal; nunca float."""

from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

CENTAVOS = Decimal("0.01")
MILESIMOS = Decimal("0.001")
ZERO = Decimal("0.00")


def para_decimal_seguro(valor: Decimal | int | float | str) -> Decimal:
    """Converte para Decimal sem passar por float (float é convertido via texto)."""
    if isinstance(valor, Decimal):
        return valor
    return Decimal(str(valor))


def arredondar(valor: Decimal | int | float | str) -> Decimal:
    """Arredonda para 2 casas (centavos), meio para cima — mesma regra do ROUND do MariaDB."""
    return para_decimal_seguro(valor).quantize(CENTAVOS, rounding=ROUND_HALF_UP)


def arredondar_quantidade(valor: Decimal | int | float | str) -> Decimal:
    """Arredonda quantidades para 3 casas, como a coluna DECIMAL(10,3)."""
    return para_decimal_seguro(valor).quantize(MILESIMOS, rounding=ROUND_HALF_UP)


def interpretar_valor(texto: str) -> Decimal:
    """Converte texto digitado pelo usuário em Decimal.

    Aceita "1.234,56", "1234,56", "R$ 10,50" e "10.50".
    Regra: havendo vírgula, ela é o separador decimal e os pontos são de milhar;
    sem vírgula, o ponto é o separador decimal.
    Levanta ValueError para entradas inválidas.
    """
    limpo = texto.replace("R$", "").replace(" ", "").strip()
    if not limpo:
        raise ValueError("Valor vazio.")
    if "," in limpo:
        limpo = limpo.replace(".", "").replace(",", ".")
    try:
        valor = Decimal(limpo)
    except InvalidOperation as exc:
        raise ValueError(f"Valor inválido: {texto!r}") from exc
    if not valor.is_finite():
        raise ValueError(f"Valor inválido: {texto!r}")
    return valor


def formatar_moeda(valor: Decimal | int | str) -> str:
    """Formata como moeda brasileira: R$ 1.234,56."""
    numero = f"{arredondar(valor):,.2f}"
    return "R$ " + numero.replace(",", "X").replace(".", ",").replace("X", ".")
