"""Funções de formatação e interpretação de dados exibidos ao usuário."""

from __future__ import annotations

import re
from datetime import date, datetime


def somente_digitos(texto: str | None) -> str:
    """Remove tudo que não for dígito."""
    return re.sub(r"\D", "", texto or "")


def normalizar_documento(texto: str | None) -> str:
    """Mantém apenas letras e dígitos, em maiúsculas.

    Necessário porque o CNPJ passou a aceitar letras (CNPJ alfanumérico, 2026).
    """
    return re.sub(r"[^0-9A-Za-z]", "", texto or "").upper()


def formatar_cpf_cnpj(documento: str | None) -> str:
    """000.000.000-00 (CPF) ou 00.000.000/0000-00 (CNPJ). Outros tamanhos ficam como estão."""
    d = normalizar_documento(documento)
    if len(d) == 11 and d.isdigit():
        return f"{d[:3]}.{d[3:6]}.{d[6:9]}-{d[9:]}"
    if len(d) == 14:
        return f"{d[:2]}.{d[2:5]}.{d[5:8]}/{d[8:12]}-{d[12:]}"
    return documento or ""


def formatar_telefone(telefone: str | None) -> str:
    """(00) 0000-0000 ou (00) 00000-0000."""
    d = somente_digitos(telefone)
    if len(d) == 10:
        return f"({d[:2]}) {d[2:6]}-{d[6:]}"
    if len(d) == 11:
        return f"({d[:2]}) {d[2:7]}-{d[7:]}"
    return telefone or ""


def formatar_cep(cep: str | None) -> str:
    """00000-000."""
    d = somente_digitos(cep)
    return f"{d[:5]}-{d[5:]}" if len(d) == 8 else (cep or "")


def formatar_data(valor: date | datetime | None) -> str:
    """dd/mm/aaaa."""
    return valor.strftime("%d/%m/%Y") if valor else ""


def formatar_data_hora(valor: datetime | None) -> str:
    """dd/mm/aaaa hh:mm."""
    return valor.strftime("%d/%m/%Y %H:%M") if valor else ""


def interpretar_data(texto: str) -> date:
    """Converte 'dd/mm/aaaa' em date. Levanta ValueError se inválida."""
    try:
        return datetime.strptime(texto.strip(), "%d/%m/%Y").date()
    except ValueError as exc:
        raise ValueError(f"Data inválida: {texto!r}. Use o formato dd/mm/aaaa.") from exc


def formatar_numero_recibo(ano: int, numero: int) -> str:
    """2026/000012."""
    return f"{ano}/{numero:06d}"


def interpretar_numero_recibo(texto: str) -> tuple[int | None, int]:
    """Interpreta '2026/000012' como (2026, 12) e '12' como (None, 12).

    Levanta ValueError se o texto não for um número de recibo.
    """
    bruto = texto.strip()
    if re.fullmatch(r"\d{4}/\d{1,9}", bruto):
        ano, numero = bruto.split("/")
        return int(ano), int(numero)
    if re.fullmatch(r"\d{1,9}", bruto):
        return None, int(bruto)
    raise ValueError(f"Número de recibo inválido: {texto!r}. Exemplos: 12 ou 2026/000012.")


# --- Máscaras aplicadas enquanto o usuário digita (usadas pela interface) --------
def _aplicar_padrao(valores: str, padrao: str) -> str:
    """Preenche o padrão ('#' = próximo caractere) com os valores, parando quando acabam."""
    resultado: list[str] = []
    posicao = 0
    for simbolo in padrao:
        if posicao >= len(valores):
            break
        if simbolo == "#":
            resultado.append(valores[posicao])
            posicao += 1
        else:
            resultado.append(simbolo)
    return "".join(resultado)


def mascara_documento(texto: str) -> str:
    """Máscara de CPF ou CNPJ conforme o que foi digitado (aceita CNPJ alfanumérico)."""
    d = normalizar_documento(texto)[:14]
    eh_cnpj = len(d) > 11 or any(c.isalpha() for c in d)
    return _aplicar_padrao(d, "##.###.###/####-##" if eh_cnpj else "###.###.###-##")


def mascara_telefone(texto: str) -> str:
    d = somente_digitos(texto)[:11]
    return _aplicar_padrao(d, "(##) #####-####" if len(d) > 10 else "(##) ####-####")


def mascara_cep(texto: str) -> str:
    return _aplicar_padrao(somente_digitos(texto)[:8], "#####-###")


def mascara_data(texto: str) -> str:
    return _aplicar_padrao(somente_digitos(texto)[:8], "##/##/####")


def formatar_quantidade(valor) -> str:
    """Quantidade sem zeros desnecessários, com vírgula: 2 -> '2'; 1.500 -> '1,5'."""
    texto = f"{valor:f}"
    if "." in texto:
        texto = texto.rstrip("0").rstrip(".")
    return texto.replace(".", ",")
