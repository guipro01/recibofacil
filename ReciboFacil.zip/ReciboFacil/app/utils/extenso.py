"""Valor monetário por extenso, em português do Brasil."""

from __future__ import annotations

from decimal import Decimal

from app.utils.dinheiro import arredondar

_UNIDADES = [
    "zero", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove", "dez",
    "onze", "doze", "treze", "quatorze", "quinze", "dezesseis", "dezessete", "dezoito", "dezenove",
]
_DEZENAS = ["", "", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa"]
_CENTENAS = [
    "", "cento", "duzentos", "trezentos", "quatrocentos", "quinhentos",
    "seiscentos", "setecentos", "oitocentos", "novecentos",
]
# (singular, plural) de cada grupo de três dígitos, do menor para o maior
_ESCALAS = [("", ""), ("mil", "mil"), ("milhão", "milhões"), ("bilhão", "bilhões")]


def _ate_999(n: int) -> str:
    """Escreve números de 1 a 999."""
    if n == 100:
        return "cem"
    partes = []
    centena, resto = divmod(n, 100)
    if centena:
        partes.append(_CENTENAS[centena])
    if resto:
        if resto < 20:
            partes.append(_UNIDADES[resto])
        else:
            dezena, unidade = divmod(resto, 10)
            partes.append(_DEZENAS[dezena] + (f" e {_UNIDADES[unidade]}" if unidade else ""))
    return " e ".join(partes)


def _inteiro_por_extenso(n: int) -> str:
    """Escreve inteiros positivos (até 999 bilhões)."""
    grupos: list[tuple[str, int]] = []  # (texto do grupo, valor deste grupo somado ao que resta abaixo)
    for indice in range(3, -1, -1):
        valor = (n // 1000**indice) % 1000
        if not valor:
            continue
        if indice == 1 and valor == 1:
            texto = "mil"
        else:
            singular, plural = _ESCALAS[indice]
            nome = singular if valor == 1 else plural
            texto = f"{_ate_999(valor)} {nome}".strip()
        grupos.append((texto, n % 1000 ** (indice + 1)))

    resultado = grupos[0][0]
    for texto, resto in grupos[1:]:
        # "e" só liga o grupo quando o resto é menor que 100 ou múltiplo de 100
        ligacao = " e " if resto < 100 or resto % 100 == 0 else " "
        resultado += ligacao + texto
    return resultado


def valor_por_extenso(valor: Decimal | int | str) -> str:
    """Ex.: 1234.50 -> 'mil duzentos e trinta e quatro reais e cinquenta centavos'."""
    total = arredondar(valor)
    if total < 0:
        raise ValueError("Valor negativo não possui extenso.")
    if total >= Decimal("1000000000000"):
        raise ValueError("Valor acima do limite suportado.")

    reais = int(total)
    centavos = int((total - reais) * 100)
    partes = []
    if reais:
        texto = _inteiro_por_extenso(reais)
        de = " de" if reais >= 1_000_000 and reais % 1_000_000 == 0 else ""
        partes.append(f"{texto}{de} {'real' if reais == 1 else 'reais'}")
    if centavos:
        partes.append(f"{_inteiro_por_extenso(centavos)} {'centavo' if centavos == 1 else 'centavos'}")
    return " e ".join(partes) if partes else "zero real"
