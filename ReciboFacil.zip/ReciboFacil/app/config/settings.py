"""Configurações do ReciboFácil, lidas do arquivo .env na raiz do projeto."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

# Raiz do projeto: .../ReciboFacil (settings.py está em app/config/)
BASE_DIR: Path = Path(__file__).resolve().parents[2]
DATABASE_DIR: Path = BASE_DIR / "database"
PDF_DIR: Path = BASE_DIR / "output" / "pdfs"

load_dotenv(BASE_DIR / ".env")


@dataclass(frozen=True)
class DatabaseSettings:
    """Parâmetros de conexão com o MariaDB."""

    host: str
    port: int
    name: str
    user: str
    password: str
    admin_user: str
    admin_password: str


def _read_port(raw: str) -> int:
    try:
        port = int(raw)
    except ValueError as exc:
        raise ValueError(f"DB_PORT inválida no .env: {raw!r}") from exc
    if not 1 <= port <= 65535:
        raise ValueError(f"DB_PORT fora do intervalo válido: {port}")
    return port


def load_database_settings() -> DatabaseSettings:
    """Lê as variáveis de ambiente e devolve as configurações do banco."""
    return DatabaseSettings(
        host=os.getenv("DB_HOST", "127.0.0.1"),
        port=_read_port(os.getenv("DB_PORT", "3306")),
        name=os.getenv("DB_NAME", "recibofacil"),
        user=os.getenv("DB_USER", "recibofacil_user"),
        password=os.getenv("DB_PASSWORD", ""),
        admin_user=os.getenv("DB_ADMIN_USER", "root"),
        admin_password=os.getenv("DB_ADMIN_PASSWORD", ""),
    )
