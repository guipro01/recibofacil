"""Validação de CPF e CNPJ (inclusive o CNPJ alfanumérico adotado em 2026)."""

from __future__ import annotations

from app.utils.formatadores import normalizar_documento

_PESOS_CNPJ_1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
_PESOS_CNPJ_2 = [6, *_PESOS_CNPJ_1]


def validar_cpf(texto: str | None) -> bool:
    """CPF válido: 11 dígitos, não repetidos, com os dois dígitos verificadores corretos."""
    cpf = normalizar_documento(texto)
    if len(cpf) != 11 or not cpf.isdigit() or len(set(cpf)) == 1:
        return False
    digitos = [int(c) for c in cpf]
    for posicao in (9, 10):
        soma = sum(digitos[i] * (posicao + 1 - i) for i in range(posicao))
        verificador = (soma * 10 % 11) % 10
        if verificador != digitos[posicao]:
            return False
    return True


def _digito_cnpj(base: str, pesos: list[int]) -> int:
    # Cada caractere vale (código ASCII − 48): dígitos 0–9 e letras A=17 ... Z=42.
    soma = sum((ord(c) - 48) * peso for c, peso in zip(base, pesos))
    resto = soma % 11
    return 0 if resto < 2 else 11 - resto


def validar_cnpj(texto: str | None) -> bool:
    """CNPJ válido (numérico ou alfanumérico): 12 posições-base + 2 dígitos verificadores."""
    cnpj = normalizar_documento(texto)
    if len(cnpj) != 14 or len(set(cnpj)) == 1:
        return False
    base, verificadores = cnpj[:12], cnpj[12:]
    if not verificadores.isdigit():
        return False
    primeiro = _digito_cnpj(base, _PESOS_CNPJ_1)
    segundo = _digito_cnpj(base + str(primeiro), _PESOS_CNPJ_2)
    return verificadores == f"{primeiro}{segundo}"


def identificar_documento(texto: str | None) -> tuple[str, str]:
    """Devolve (tipo_pessoa, documento_normalizado): ('F', cpf) ou ('J', cnpj).

    Levanta ValueError com mensagem clara se o documento for vazio ou inválido.
    """
    documento = normalizar_documento(texto)
    if not documento:
        raise ValueError("Informe o CPF ou CNPJ.")
    if len(documento) == 11:
        if validar_cpf(documento):
            return "F", documento
        raise ValueError("CPF inválido.")
    if len(documento) == 14:
        if validar_cnpj(documento):
            return "J", documento
        raise ValueError("CNPJ inválido.")
    raise ValueError("O documento deve ter 11 dígitos (CPF) ou 14 caracteres (CNPJ).")
