"""Validação dos dados de emissão de recibos e de pagamentos."""

from __future__ import annotations

from datetime import date
from decimal import Decimal

from app.models.recibo import ItemRecibo
from app.utils.dinheiro import ZERO, formatar_moeda

LIMITE_VALOR = Decimal("9999999999.99")  # DECIMAL(12,2)
LIMITE_QUANTIDADE = Decimal("9999999.999")  # DECIMAL(10,3)
DATA_MINIMA = date(2000, 1, 1)


def validar_itens(itens: list[ItemRecibo]) -> list[str]:
    """Todos os serviços do recibo."""
    if not itens:
        return ["Adicione pelo menos um serviço ao recibo."]
    erros: list[str] = []
    for posicao, item in enumerate(itens, start=1):
        prefixo = f"Serviço {posicao}: "
        descricao = (item.descricao or "").strip()
        if not descricao:
            erros.append(prefixo + "informe a descrição.")
        elif len(descricao) > 255:
            erros.append(prefixo + "a descrição pode ter no máximo 255 caracteres.")
        if item.quantidade <= 0:
            erros.append(prefixo + "a quantidade deve ser maior que zero.")
        elif item.quantidade > LIMITE_QUANTIDADE:
            erros.append(prefixo + "quantidade acima do limite permitido.")
        if item.valor_unitario <= 0:
            erros.append(prefixo + "o valor unitário deve ser maior que zero.")
        elif item.valor_unitario > LIMITE_VALOR:
            erros.append(prefixo + "valor unitário acima do limite permitido.")
        if item.subtotal is not None and item.subtotal > LIMITE_VALOR:
            erros.append(prefixo + "subtotal acima do limite permitido.")
    return erros


def validar_totais(subtotal: Decimal, desconto: Decimal) -> list[str]:
    erros: list[str] = []
    if desconto < ZERO:
        erros.append("O desconto não pode ser negativo.")
    elif desconto > subtotal:
        erros.append(f"O desconto ({formatar_moeda(desconto)}) não pode ser maior que o subtotal ({formatar_moeda(subtotal)}).")
    elif subtotal - desconto <= ZERO:
        erros.append("O total do recibo deve ser maior que zero.")
    if subtotal > LIMITE_VALOR:
        erros.append("O subtotal do recibo está acima do limite permitido.")
    return erros


def validar_data_emissao(data: date, hoje: date) -> list[str]:
    if data > hoje:
        return ["A data de emissão não pode ser futura."]
    if data < DATA_MINIMA:
        return ["A data de emissão é inválida."]
    return []


def validar_pagamento(valor: Decimal, data_pagamento: date, hoje: date, maximo: Decimal) -> list[str]:
    """`maximo` é o valor ainda pendente do recibo."""
    erros: list[str] = []
    if valor <= ZERO:
        erros.append("O valor do pagamento deve ser maior que zero.")
    elif valor > maximo:
        erros.append(f"O valor do pagamento ({formatar_moeda(valor)}) é maior que o valor pendente ({formatar_moeda(maximo)}).")
    if data_pagamento > hoje:
        erros.append("A data do pagamento não pode ser futura.")
    elif data_pagamento < DATA_MINIMA:
        erros.append("A data do pagamento é inválida.")
    return erros
