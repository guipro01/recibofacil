"""Validação e normalização de cadastros de pessoas (cliente e emitente)."""

from __future__ import annotations

import re

from app.models.pessoa import Pessoa
from app.utils.formatadores import somente_digitos
from app.validators.documento import identificar_documento

UFS = frozenset(
    "AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO".split()
)
_REGEX_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

_LIMITES = {
    "nome": 150,
    "email": 120,
    "logradouro": 150,
    "numero": 10,
    "complemento": 60,
    "bairro": 80,
    "cidade": 80,
}
_ROTULOS = {
    "nome": "Nome",
    "email": "E-mail",
    "logradouro": "Logradouro",
    "numero": "Número",
    "complemento": "Complemento",
    "bairro": "Bairro",
    "cidade": "Cidade",
}


def validar_e_normalizar_pessoa(pessoa: Pessoa) -> list[str]:
    """Valida o cadastro e NORMALIZA os campos no próprio objeto.

    Normalização: remove espaços das pontas, grava documento/telefone/CEP só com
    caracteres válidos, UF em maiúsculas e define o tipo de pessoa pelo documento.
    Devolve a lista de problemas encontrados (vazia se estiver tudo certo).
    """
    erros: list[str] = []

    for campo in (*_LIMITES, "uf", "cep", "telefone"):
        valor = getattr(pessoa, campo)
        setattr(pessoa, campo, valor.strip() if isinstance(valor, str) and valor.strip() else None)
    pessoa.nome = (pessoa.nome or "").strip()
    pessoa.nome = re.sub(r"\s+", " ", pessoa.nome)

    # Nome
    if not pessoa.nome:
        erros.append("Informe o nome.")
    elif len(pessoa.nome) < 3:
        erros.append("O nome deve ter pelo menos 3 caracteres.")

    # Documento
    try:
        pessoa.tipo_pessoa, pessoa.documento = identificar_documento(pessoa.documento)
    except ValueError as exc:
        erros.append(str(exc))

    # Tamanhos máximos
    for campo, limite in _LIMITES.items():
        valor = getattr(pessoa, campo)
        if valor and len(valor) > limite:
            erros.append(f"{_ROTULOS[campo]}: no máximo {limite} caracteres.")

    # Telefone
    if pessoa.telefone:
        digitos = somente_digitos(pessoa.telefone)
        if len(digitos) not in (10, 11):
            erros.append("Telefone inválido. Informe DDD + número (10 ou 11 dígitos).")
        else:
            pessoa.telefone = digitos

    # E-mail
    if pessoa.email and not _REGEX_EMAIL.match(pessoa.email):
        erros.append("E-mail inválido.")

    # CEP
    if pessoa.cep:
        digitos = somente_digitos(pessoa.cep)
        if len(digitos) != 8:
            erros.append("CEP inválido. Informe 8 dígitos.")
        else:
            pessoa.cep = digitos

    # UF
    if pessoa.uf:
        pessoa.uf = pessoa.uf.upper()
        if pessoa.uf not in UFS:
            erros.append("UF inválida.")

    return erros
