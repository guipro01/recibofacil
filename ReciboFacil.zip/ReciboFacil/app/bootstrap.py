"""Montagem dos serviços da aplicação (um único ponto de configuração)."""

from __future__ import annotations

from dataclasses import dataclass

from app.core.connection import Database
from app.services.cliente_service import ClienteService
from app.services.configuracao_service import ConfiguracaoService
from app.services.dashboard_service import DashboardService
from app.services.emitente_service import EmitenteService
from app.services.pdf_service import PdfService
from app.services.recibo_service import ReciboService


@dataclass
class Servicos:
    db: Database
    clientes: ClienteService
    emitentes: EmitenteService
    recibos: ReciboService
    dashboard: DashboardService
    configuracoes: ConfiguracaoService
    pdf: PdfService


def criar_servicos(db: Database | None = None) -> Servicos:
    db = db or Database()
    recibos = ReciboService(db)
    configuracoes = ConfiguracaoService(db)
    return Servicos(
        db=db,
        clientes=ClienteService(db),
        emitentes=EmitenteService(db),
        recibos=recibos,
        dashboard=DashboardService(db),
        configuracoes=configuracoes,
        pdf=PdfService(recibos, configuracoes),
    )
