"""Conexão com o MariaDB (PyMySQL) e controle de transações.

Uso típico:

    db = Database()

    # Escrita: tudo ou nada (COMMIT ao sair do bloco, ROLLBACK se ocorrer erro)
    with db.transaction() as cur:
        repositorio.inserir(cur, ...)
        outro_repositorio.inserir(cur, ...)

    # Leitura
    with db.cursor() as cur:
        dados = repositorio.listar(cur)

Os repositórios recebem o cursor e nunca abrem conexão nem fazem COMMIT:
quem decide os limites da transação é o serviço.
"""

from __future__ import annotations

import re
from collections.abc import Iterator
from contextlib import contextmanager

import pymysql
from pymysql.connections import Connection
from pymysql.constants import CLIENT
from pymysql.cursors import DictCursor

from app.config.settings import DatabaseSettings, load_database_settings
from app.core.exceptions import (
    ConexaoBancoError,
    ErroBancoDados,
    IntegridadeError,
    RegistroDuplicadoError,
    RestricaoError,
)
from app.core.logger import get_logger

log = get_logger(__name__)

# --- Códigos de erro do MariaDB ------------------------------------------------
_ERROS_CONEXAO = {1045, 1049, 2002, 2003, 2006, 2013}
_ERRO_DUPLICADO = 1062
_ERROS_FK = {1451, 1452}
_ERROS_CHECK = {4025, 3819}
_ERROS_DADO_INVALIDO = {1264, 1265, 1366, 1406}
_ERROS_CONCORRENCIA = {1205, 1213}

_MENSAGEM_DUPLICADO = {
    "uk_clientes_documento": "Já existe um cliente cadastrado com este CPF/CNPJ.",
    "uk_emitentes_documento": "Já existe um emitente cadastrado com este CPF/CNPJ.",
    "uk_recibos_numero": "Número de recibo já utilizado. Tente emitir novamente.",
    "uk_formas_pagamento_descricao": "Já existe uma forma de pagamento com esta descrição.",
}

_MENSAGEM_CHECK = {
    "ck_recibos_valores": "Os valores do recibo não podem ser negativos.",
    "ck_recibos_desconto": "O desconto não pode ser maior que o subtotal.",
    "ck_recibos_total": "O total do recibo não confere com o subtotal menos o desconto.",
    "ck_recibos_cancelamento": "Os dados de cancelamento do recibo estão inconsistentes.",
    "ck_recibos_situacao": "Situação de recibo inválida.",
    "ck_itens_quantidade": "A quantidade do serviço deve ser maior que zero.",
    "ck_itens_valor": "O valor unitário do serviço não pode ser negativo.",
    "ck_itens_subtotal": "O subtotal do serviço não pode ser negativo.",
    "ck_pagamentos_valor": "O valor do pagamento deve ser maior que zero.",
    "ck_clientes_doc": "O tamanho do CPF/CNPJ não corresponde ao tipo de pessoa.",
    "ck_emitentes_doc": "O tamanho do CPF/CNPJ não corresponde ao tipo de pessoa.",
}


def traduzir_erro_mysql(exc: pymysql.MySQLError) -> ErroBancoDados:
    """Converte um erro do PyMySQL em uma exceção do sistema com mensagem clara."""
    codigo = exc.args[0] if exc.args and isinstance(exc.args[0], int) else None
    texto = str(exc.args[1]) if len(exc.args) > 1 else str(exc)
    log.error("Erro de banco (%s): %s", codigo, texto)

    if codigo in _ERROS_CONEXAO:
        if codigo == 1045:
            mensagem = "Acesso negado ao banco de dados. Verifique DB_USER e DB_PASSWORD no arquivo .env."
        elif codigo == 1049:
            mensagem = "O banco de dados não existe. Execute: python database/setup_db.py"
        else:
            mensagem = (
                "Não foi possível conectar ao MariaDB. Verifique se o serviço está iniciado "
                "e se DB_HOST e DB_PORT estão corretos no arquivo .env."
            )
        return ConexaoBancoError(mensagem, detalhe=texto, codigo=codigo)

    if codigo == _ERRO_DUPLICADO:
        encontrado = re.search(r"for key '([^']+)'", texto)
        chave = encontrado.group(1).split(".")[-1] if encontrado else ""
        mensagem = _MENSAGEM_DUPLICADO.get(chave, "Já existe um registro com estes dados.")
        return RegistroDuplicadoError(mensagem, detalhe=texto, codigo=codigo)

    if codigo in _ERROS_FK:
        if codigo == 1451:
            mensagem = "Operação não permitida: existem registros vinculados a este item."
        else:
            mensagem = "O registro relacionado informado não existe."
        return IntegridadeError(mensagem, detalhe=texto, codigo=codigo)

    if codigo in _ERROS_CHECK:
        encontrado = re.search(r"`([^`]+)`", texto)
        nome = encontrado.group(1) if encontrado else ""
        mensagem = _MENSAGEM_CHECK.get(nome, "Os dados informados violam uma regra de integridade do banco.")
        return RestricaoError(mensagem, detalhe=texto, codigo=codigo)

    if codigo in _ERROS_DADO_INVALIDO:
        return ErroBancoDados(
            "Algum campo contém valor inválido ou maior que o tamanho permitido.", detalhe=texto, codigo=codigo
        )

    if codigo in _ERROS_CONCORRENCIA:
        return ErroBancoDados(
            "A operação conflitou com outra em andamento. Tente novamente.", detalhe=texto, codigo=codigo
        )

    return ErroBancoDados("Erro inesperado ao acessar o banco de dados.", detalhe=texto, codigo=codigo)


class Database:
    """Fábrica de conexões e gerenciador de transações do MariaDB."""

    def __init__(self, settings: DatabaseSettings | None = None) -> None:
        self._settings = settings or load_database_settings()

    def conectar(self) -> Connection:
        """Abre uma nova conexão (sem autocommit; utf8mb4; linhas como dicionários)."""
        cfg = self._settings
        try:
            return pymysql.connect(
                host=cfg.host,
                port=cfg.port,
                user=cfg.user,
                password=cfg.password,
                database=cfg.name,
                charset="utf8mb4",
                cursorclass=DictCursor,
                autocommit=False,
                connect_timeout=10,
                # rowcount passa a informar as linhas ENCONTRADAS (não só as alteradas)
                client_flag=CLIENT.FOUND_ROWS,
            )
        except pymysql.MySQLError as exc:
            raise traduzir_erro_mysql(exc) from exc

    @contextmanager
    def transaction(self) -> Iterator[DictCursor]:
        """Bloco transacional: COMMIT ao concluir, ROLLBACK em qualquer exceção."""
        conexao = self.conectar()
        try:
            cursor = conexao.cursor()
            try:
                yield cursor
                conexao.commit()
            finally:
                cursor.close()
        except BaseException as exc:
            try:
                conexao.rollback()
            except pymysql.MySQLError:
                log.exception("Falha ao executar ROLLBACK")
            if isinstance(exc, pymysql.MySQLError):
                raise traduzir_erro_mysql(exc) from exc
            raise
        finally:
            conexao.close()

    @contextmanager
    def cursor(self) -> Iterator[DictCursor]:
        """Cursor para consultas (leitura). Nada é gravado: encerra com ROLLBACK."""
        conexao = self.conectar()
        try:
            cursor = conexao.cursor()
            try:
                yield cursor
            finally:
                cursor.close()
        except pymysql.MySQLError as exc:
            raise traduzir_erro_mysql(exc) from exc
        finally:
            try:
                conexao.rollback()
            except pymysql.MySQLError:
                pass
            conexao.close()

    def testar_conexao(self) -> str:
        """Confere a conexão e devolve a versão do servidor."""
        with self.cursor() as cur:
            cur.execute("SELECT VERSION() AS versao")
            return str(cur.fetchone()["versao"])
