"""Configuração de log do sistema (arquivo rotativo em logs/ e console)."""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler

from app.config.settings import BASE_DIR

_LOG_DIR = BASE_DIR / "logs"
_NOME_RAIZ = "recibofacil"
_configurado = False


def _configurar() -> None:
    global _configurado
    if _configurado:
        return
    logger = logging.getLogger(_NOME_RAIZ)
    logger.setLevel(logging.INFO)
    formato = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")

    try:
        _LOG_DIR.mkdir(exist_ok=True)
        arquivo = RotatingFileHandler(
            _LOG_DIR / "recibofacil.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8"
        )
        arquivo.setFormatter(formato)
        logger.addHandler(arquivo)
    except OSError:
        # Sem permissão de escrita: segue apenas com o console.
        pass

    console = logging.StreamHandler()
    console.setLevel(logging.WARNING)
    console.setFormatter(formato)
    logger.addHandler(console)
    _configurado = True


def get_logger(nome: str) -> logging.Logger:
    """Devolve um logger filho de 'recibofacil' (ex.: get_logger(__name__))."""
    _configurar()
    return logging.getLogger(f"{_NOME_RAIZ}.{nome}")
