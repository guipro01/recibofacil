"""Exceções do ReciboFácil.

Toda exceção do sistema herda de ReciboFacilError e carrega uma mensagem
pronta para ser exibida ao usuário. Detalhes técnicos ficam em `detalhe`
e vão apenas para o log.
"""

from __future__ import annotations


class ReciboFacilError(Exception):
    """Base de todas as exceções do sistema."""

    def __init__(self, mensagem: str, *, detalhe: str | None = None, codigo: int | None = None) -> None:
        super().__init__(mensagem)
        self.mensagem = mensagem
        self.detalhe = detalhe
        self.codigo = codigo

    def __str__(self) -> str:
        return self.mensagem


# --- Erros de banco de dados -------------------------------------------------
class ErroBancoDados(ReciboFacilError):
    """Falha genérica ao acessar o banco de dados."""


class ConexaoBancoError(ErroBancoDados):
    """Não foi possível conectar ao MariaDB."""


class RegistroDuplicadoError(ErroBancoDados):
    """Violação de chave única (ex.: CPF/CNPJ já cadastrado)."""


class IntegridadeError(ErroBancoDados):
    """Violação de chave estrangeira (registro vinculado ou inexistente)."""


class RestricaoError(ErroBancoDados):
    """Violação de uma restrição CHECK (valor negativo, total inconsistente...)."""


# --- Erros de negócio --------------------------------------------------------
class ValidacaoError(ReciboFacilError):
    """Dados inválidos informados pelo usuário. Pode acumular vários problemas."""

    def __init__(self, erros: list[str] | str) -> None:
        self.erros = [erros] if isinstance(erros, str) else list(erros)
        super().__init__("\n".join(self.erros))


class RegraNegocioError(ReciboFacilError):
    """Operação não permitida pelas regras do sistema (ex.: cancelar duas vezes)."""


class RegistroNaoEncontradoError(ReciboFacilError):
    """O registro solicitado não existe."""


class ErroDocumento(ReciboFacilError):
    """Falha ao gerar, abrir ou imprimir um documento PDF."""
