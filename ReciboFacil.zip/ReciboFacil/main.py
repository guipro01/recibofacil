"""ReciboFácil — ponto de entrada.

Execute com:  python main.py
"""

from __future__ import annotations

import sys
import tkinter as tk
from tkinter import messagebox

from app.bootstrap import criar_servicos
from app.core.exceptions import ReciboFacilError
from app.core.logger import get_logger
from app.ui.theme import aplicar_tema

log = get_logger("main")


def _erro_de_inicializacao(mensagem: str) -> None:
    raiz = tk.Tk()
    raiz.withdraw()
    messagebox.showerror("ReciboFácil — não foi possível iniciar", mensagem)
    raiz.destroy()


def main() -> int:
    try:
        servicos = criar_servicos()
        versao = servicos.db.testar_conexao()
    except ReciboFacilError as exc:
        log.error("Falha na inicialização: %s (%s)", exc.mensagem, exc.detalhe)
        _erro_de_inicializacao(f"{exc.mensagem}\n\nSe for a primeira execução, rode:\n    python database/setup_db.py")
        return 1
    except Exception:  # noqa: BLE001 - qualquer outra falha na partida também precisa ser mostrada
        log.exception("Falha inesperada na inicialização")
        _erro_de_inicializacao("Erro inesperado ao iniciar. Consulte o arquivo de log na pasta 'logs'.")
        return 1

    from app.ui.main_window import App  # importado aqui para o erro acima não depender da interface

    aplicar_tema()
    App(servicos, versao).mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
