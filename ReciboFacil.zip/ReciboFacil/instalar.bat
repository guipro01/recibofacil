@echo off
setlocal
cd /d "%~dp0"
echo ==============================================
echo   ReciboFacil - instalacao
echo ==============================================

set "PY=py -3.13"
%PY% --version >nul 2>&1
if errorlevel 1 set "PY=python"
%PY% --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo Python nao encontrado. Instale o Python 3.13 em https://www.python.org/downloads/
    echo e marque a opcao "Add python.exe to PATH" durante a instalacao.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo.
    echo [1/4] Criando o ambiente virtual...
    %PY% -m venv .venv
    if errorlevel 1 goto erro
)

echo.
echo [2/4] Instalando as dependencias...
call ".venv\Scripts\python.exe" -m pip install --upgrade pip
call ".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto erro

if not exist ".env" (
    echo.
    echo [3/4] Criando o arquivo de configuracao .env...
    copy ".env.example" ".env" >nul
    echo.
    echo O Bloco de Notas vai abrir o arquivo .env. Defina:
    echo   - DB_PASSWORD: uma senha para o usuario do sistema ^(recibofacil_user^)
    echo   - DB_PORT: a porta do seu MariaDB ^(normalmente 3306^)
    echo Salve e feche o Bloco de Notas para continuar.
    notepad ".env"
) else (
    echo.
    echo [3/4] Arquivo .env ja existe - mantido.
)

echo.
echo [4/4] Preparando o banco de dados...
call ".venv\Scripts\python.exe" database\setup_db.py
if errorlevel 1 goto erro

echo.
echo Instalacao concluida! Para abrir o sistema, de dois cliques em iniciar.bat
pause
exit /b 0

:erro
echo.
echo A instalacao nao foi concluida. Leia a mensagem acima e consulte a secao
echo "Solucao de problemas" do README.md.
pause
exit /b 1
